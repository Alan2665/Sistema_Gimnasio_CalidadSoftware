package org.example.modules.alertas;

import org.example.modules.alertas.service.AlertasProgramadasService;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.inscripcion.entity.Inscripcion;
import org.example.modules.inscripcion.repository.InscripcionRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.example.modules.producto.repository.ProductoRepository;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/** Las alertas automáticas marcan membresías vencidas y avisan de las que están por vencer. */
class AlertasProgramadasTest {

    private Inscripcion inscripcion(String estado, LocalDate fin) {
        Cliente c = new Cliente();
        c.setIdCliente(1);
        c.setNombre("Ana");
        c.setApellido("Mena");
        Inscripcion i = new Inscripcion();
        i.setCliente(c);
        i.setEstado(estado);
        i.setFechaInicio(LocalDate.now().minusDays(60));
        i.setFechaFin(fin);
        return i;
    }

    @Test
    void membresiaVencidaSeMarcaYSeAvisa() {
        InscripcionRepository repo = mock(InscripcionRepository.class);
        NotificacionService notif = mock(NotificacionService.class);
        Inscripcion vencida = inscripcion("Activa", LocalDate.now().minusDays(2));
        when(repo.findAll()).thenReturn(List.of(vencida));

        new AlertasProgramadasService(repo, mock(ProductoRepository.class), notif).ejecutar();

        assertEquals("Vencida", vencida.getEstado());
        verify(repo).save(vencida);
        verify(notif).notificarUnicaAdmins(eq("INSCRIPCION"), anyString(), anyString());
    }

    @Test
    void membresiaPorVencerAvisaSinCambiarEstado() {
        InscripcionRepository repo = mock(InscripcionRepository.class);
        NotificacionService notif = mock(NotificacionService.class);
        Inscripcion porVencer = inscripcion("Activa", LocalDate.now().plusDays(2));
        when(repo.findAll()).thenReturn(List.of(porVencer));

        new AlertasProgramadasService(repo, mock(ProductoRepository.class), notif).ejecutar();

        assertEquals("Activa", porVencer.getEstado());
        verify(repo, never()).save(any(Inscripcion.class));
        verify(notif).notificarUnicaAdmins(eq("INSCRIPCION"), eq("Membresías por vencer"), anyString());
    }

    @Test
    void membresiaLejanaNoGeneraAvisos() {
        InscripcionRepository repo = mock(InscripcionRepository.class);
        NotificacionService notif = mock(NotificacionService.class);
        when(repo.findAll()).thenReturn(List.of(inscripcion("Activa", LocalDate.now().plusDays(30))));

        new AlertasProgramadasService(repo, mock(ProductoRepository.class), notif).ejecutar();

        verify(notif, never()).notificarUnicaAdmins(anyString(), anyString(), anyString());
    }
}
