package org.example.modules.clase;

import org.example.modules.clase.entity.Clase;
import org.example.modules.clase.service.ClaseService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Conversión de horarios antiguos en texto libre a días + franjas. */
class ClaseAgendaTest {

    @Test
    void deduceDiasDeTextoSinHoras() {
        Clase c = new Clase();
        c.setHorario("Lunes miercoles y sabados");
        assertTrue(ClaseService.completarAgendaDesdeTexto(c));
        assertEquals("LUN,MIE,SAB", c.getDias());
        assertTrue(c.getHoras() == null || c.getHoras().isBlank());
    }

    @Test
    void deduceDiasYHorasDeTextoCompleto() {
        Clase c = new Clase();
        c.setHorario("Lunes y Miércoles 19:00 - 20:00");
        assertTrue(ClaseService.completarAgendaDesdeTexto(c));
        assertEquals("LUN,MIE", c.getDias());
        assertEquals("19:00-20:00", c.getHoras());
    }

    @Test
    void rangoDeDiasSeExpande() {
        Clase c = new Clase();
        c.setHorario("Lunes a viernes 06:00 - 07:00");
        ClaseService.completarAgendaDesdeTexto(c);
        assertEquals("LUN,MAR,MIE,JUE,VIE", c.getDias());
    }

    @Test
    void siYaTieneAgendaNoSeToca() {
        Clase c = new Clase();
        c.setHorario("Lunes 10:00 - 11:00");
        c.setDias("MAR");
        c.setHoras("08:00-09:00");
        assertFalse(ClaseService.completarAgendaDesdeTexto(c));
        assertEquals("MAR", c.getDias());
    }
}
