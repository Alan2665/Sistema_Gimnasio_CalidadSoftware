package org.example.modules.auth;

import org.example.modules.auth.entity.AuthUser;
import org.example.modules.auth.entity.RecuperacionToken;
import org.example.modules.auth.repository.AuthUserRepository;
import org.example.modules.auth.repository.RecuperacionTokenRepository;
import org.example.modules.auth.service.CuentaService;
import org.example.modules.auth.service.RecuperacionService;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.entrenador.repository.EntrenadorRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Cambio de clave y recuperación por token (sin base de datos: repositorios simulados). */
class CuentaYRecuperacionTest {

    private final PasswordEncoder encoder = new BCryptPasswordEncoder();
    private AuthUserRepository authUserRepository;
    private RecuperacionTokenRepository tokenRepository;
    private CuentaService cuentaService;
    private RecuperacionService recuperacionService;
    private AuthUser usuario;

    @SuppressWarnings("unchecked")
    @BeforeEach
    void preparar() {
        authUserRepository = mock(AuthUserRepository.class);
        tokenRepository = mock(RecuperacionTokenRepository.class);
        NotificacionService notificaciones = mock(NotificacionService.class);

        usuario = new AuthUser();
        usuario.setId(7L);
        usuario.setUsername("ana");
        usuario.setRole("CLIENTE");
        usuario.setActivo(true);
        usuario.setPassword(encoder.encode("claveVieja1"));

        when(authUserRepository.findByUsername("ana")).thenReturn(Optional.of(usuario));
        when(authUserRepository.findById(7L)).thenReturn(Optional.of(usuario));

        cuentaService = new CuentaService(authUserRepository, mock(ClienteRepository.class),
                mock(EntrenadorRepository.class), encoder, notificaciones);
        recuperacionService = new RecuperacionService(authUserRepository, mock(ClienteRepository.class),
                mock(EntrenadorRepository.class), tokenRepository, encoder, notificaciones,
                (ObjectProvider<JavaMailSender>) mock(ObjectProvider.class));
    }

    private static String sha256(String texto) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(texto.getBytes(StandardCharsets.UTF_8)));
    }

    private RecuperacionToken tokenValido(String token) throws Exception {
        RecuperacionToken t = new RecuperacionToken();
        t.setAuthUserId(7L);
        t.setTokenHash(sha256(token));
        t.setExpira(LocalDateTime.now().plusMinutes(10));
        t.setUsado(false);
        when(tokenRepository.findByTokenHash(sha256(token))).thenReturn(Optional.of(t));
        return t;
    }

    @Test
    void cambiarClaveConActualIncorrectaFalla() {
        assertThrows(IllegalArgumentException.class, () -> cuentaService.cambiarClave("ana", "otra", "nuevaClave1"));
    }

    @Test
    void cambiarClaveConNuevaIgualFalla() {
        assertThrows(IllegalArgumentException.class, () -> cuentaService.cambiarClave("ana", "claveVieja1", "claveVieja1"));
    }

    @Test
    void cambiarClaveCorrectaActualizaElHash() {
        cuentaService.cambiarClave("ana", "claveVieja1", "claveNueva1");
        assertTrue(encoder.matches("claveNueva1", usuario.getPassword()));
        verify(authUserRepository).save(usuario);
    }

    @Test
    void restablecerConTokenInexistenteFalla() {
        when(tokenRepository.findByTokenHash(any())).thenReturn(Optional.empty());
        assertThrows(IllegalArgumentException.class, () -> recuperacionService.restablecer("falso", "claveNueva1"));
    }

    @Test
    void restablecerConTokenVencidoFalla() throws Exception {
        RecuperacionToken t = tokenValido("abc");
        t.setExpira(LocalDateTime.now().minusMinutes(1));
        assertThrows(IllegalArgumentException.class, () -> recuperacionService.restablecer("abc", "claveNueva1"));
    }

    @Test
    void restablecerConTokenUsadoFalla() throws Exception {
        RecuperacionToken t = tokenValido("abc");
        t.setUsado(true);
        assertThrows(IllegalArgumentException.class, () -> recuperacionService.restablecer("abc", "claveNueva1"));
    }

    @Test
    void restablecerValidoCambiaLaClaveYConsumeElToken() throws Exception {
        RecuperacionToken t = tokenValido("tokenOk");
        recuperacionService.restablecer("tokenOk", "claveNueva1");
        assertTrue(encoder.matches("claveNueva1", usuario.getPassword()));
        assertTrue(t.getUsado());
    }

    @Test
    void restablecerConClaveCortaFalla() throws Exception {
        tokenValido("tokenOk");
        assertThrows(IllegalArgumentException.class, () -> recuperacionService.restablecer("tokenOk", "123"));
    }
}
