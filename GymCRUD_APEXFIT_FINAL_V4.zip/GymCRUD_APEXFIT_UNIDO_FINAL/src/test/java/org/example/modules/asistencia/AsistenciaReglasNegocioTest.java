package org.example.modules.asistencia;

import org.example.common.security.IdentityService;
import org.example.exception.BusinessException;
import org.example.modules.asistencia.entity.Asistencia;
import org.example.modules.asistencia.repository.AsistenciaRepository;
import org.example.modules.asistencia.service.AsistenciaService;
import org.example.modules.clase.entity.Clase;
import org.example.modules.clase.repository.ClaseRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.inscripcion.entity.Inscripcion;
import org.example.modules.inscripcion.repository.InscripcionRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Reglas de negocio de las asistencias: membresía vigente, duplicados y cupo máximo. */
class AsistenciaReglasNegocioTest {

    private AsistenciaRepository repository;
    private InscripcionRepository inscripcionRepository;
    private AsistenciaService service;

    private Cliente cliente;
    private Clase clase;
    private final LocalDate hoy = LocalDate.now();

    @BeforeEach
    void preparar() {
        repository = mock(AsistenciaRepository.class);
        inscripcionRepository = mock(InscripcionRepository.class);
        service = new AsistenciaService(repository, mock(ClaseRepository.class), mock(ClienteRepository.class),
                inscripcionRepository, mock(NotificacionService.class), mock(IdentityService.class));

        cliente = new Cliente();
        cliente.setIdCliente(1);
        cliente.setNombre("Ana");
        cliente.setApellido("Mena");
        cliente.setEstado(true);

        clase = new Clase();
        clase.setIdClase(10);
        clase.setNombre("Crossfit");
        clase.setCupoMaximo(2);

        when(repository.save(any(Asistencia.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    private void conMembresiaActiva() {
        Inscripcion i = new Inscripcion();
        i.setEstado("Activa");
        i.setFechaInicio(hoy.minusDays(5));
        i.setFechaFin(hoy.plusDays(25));
        when(inscripcionRepository.findByClienteIdCliente(1)).thenReturn(List.of(i));
    }

    @Test
    void sinMembresiaVigenteSeRechaza() {
        when(inscripcionRepository.findByClienteIdCliente(1)).thenReturn(List.of());
        assertThrows(BusinessException.class, () -> service.registrarAsistencia(cliente, clase, hoy));
        verify(repository, never()).save(any(Asistencia.class));
    }

    @Test
    void membresiaVencidaSeRechaza() {
        Inscripcion vencida = new Inscripcion();
        vencida.setEstado("Vencida");
        vencida.setFechaInicio(hoy.minusDays(60));
        vencida.setFechaFin(hoy.minusDays(30));
        when(inscripcionRepository.findByClienteIdCliente(1)).thenReturn(List.of(vencida));
        assertThrows(BusinessException.class, () -> service.registrarAsistencia(cliente, clase, hoy));
    }

    @Test
    void claseLlenaSeRechaza() {
        conMembresiaActiva();
        when(repository.countByClaseIdClaseAndFechaAsistencia(10, hoy)).thenReturn(2L);
        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.registrarAsistencia(cliente, clase, hoy));
        assertTrue(ex.getMessage().contains("llena"));
    }

    @Test
    void duplicadoMismoDiaSeRechaza() {
        conMembresiaActiva();
        when(repository.existsByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(1, 10, hoy)).thenReturn(true);
        assertThrows(BusinessException.class, () -> service.registrarAsistencia(cliente, clase, hoy));
    }

    @Test
    void conTodoEnReglaSeGuarda() {
        conMembresiaActiva();
        when(repository.countByClaseIdClaseAndFechaAsistencia(10, hoy)).thenReturn(1L);
        Asistencia guardada = service.registrarAsistencia(cliente, clase, hoy);
        assertEquals(hoy, guardada.getFechaAsistencia());
        assertSame(cliente, guardada.getCliente());
        verify(repository).save(any(Asistencia.class));
    }

    @Test
    void diaFueraDeLaAgendaSeRechaza() {
        clase.setDias("LUN");
        LocalDate martes = hoy.with(java.time.temporal.TemporalAdjusters.next(java.time.DayOfWeek.TUESDAY));
        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.registrarAsistencia(cliente, clase, martes, null, true));
        assertTrue(ex.getMessage().contains("solo se dicta"));
    }

    @Test
    void franjaInexistenteSeRechaza() {
        clase.setHoras("08:00-09:00");
        assertThrows(BusinessException.class,
                () -> service.registrarAsistencia(cliente, clase, hoy, "10:00-11:00", true));
    }

    @Test
    void conVariasFranjasHayQueElegirUna() {
        clase.setHoras("08:00-09:00,18:00-19:00");
        assertThrows(BusinessException.class,
                () -> service.registrarAsistencia(cliente, clase, hoy, null, true));
    }

    @Test
    void confirmarPresenciaMarcaYNoSePuedeRepetir() {
        Asistencia inscripcion = new Asistencia();
        inscripcion.setCliente(cliente);
        inscripcion.setClase(clase);
        inscripcion.setFechaAsistencia(hoy);
        inscripcion.setPresente(false);

        Asistencia confirmada = service.confirmarPresencia(inscripcion);
        assertTrue(confirmada.getPresente());
        assertNotNull(confirmada.getHoraIngreso());
        assertThrows(BusinessException.class, () -> service.confirmarPresencia(confirmada));
    }
}
