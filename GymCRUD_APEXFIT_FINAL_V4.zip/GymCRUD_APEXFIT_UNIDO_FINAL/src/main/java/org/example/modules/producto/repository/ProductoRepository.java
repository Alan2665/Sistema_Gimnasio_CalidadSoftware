package org.example.modules.producto.repository;

import org.example.modules.producto.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;
import java.util.Optional;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    Optional<Producto> findByNombreIgnoreCase(String nombre);

    java.util.List<Producto> findByStockLessThanEqual(Integer stock);

    /** Bloquea el producto durante una venta para evitar sobreventa concurrente. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Producto p where p.idProducto = :id")
    Optional<Producto> findByIdForUpdate(@Param("id") Integer id);
}
