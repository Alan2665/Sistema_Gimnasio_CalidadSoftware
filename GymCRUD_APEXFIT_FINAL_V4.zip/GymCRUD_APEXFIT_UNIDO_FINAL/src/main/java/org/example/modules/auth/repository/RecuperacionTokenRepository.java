package org.example.modules.auth.repository;

import org.example.modules.auth.entity.RecuperacionToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface RecuperacionTokenRepository extends JpaRepository<RecuperacionToken, Long> {

    Optional<RecuperacionToken> findByTokenHash(String tokenHash);

    /** Invalida los enlaces anteriores de un usuario cuando se genera uno nuevo. */
    @Modifying
    @Query("update RecuperacionToken t set t.usado = true where t.authUserId = :id and t.usado = false")
    int invalidarAnteriores(@Param("id") Long authUserId);
}
