package org.example.modules.inscripcion.dto;

import java.time.LocalDate;

/** Compra de una membresía por parte del propio cliente (pago en línea: tarjeta o transferencia). */
public class InscripcionCompraRequest {
    private Integer membresiaId;
    private LocalDate fechaInicio;
    private String metodoPago;
    /** Últimos 4 dígitos de la tarjeta; el número completo nunca llega al servidor. */
    private String tarjetaUltimos4;

    public Integer getMembresiaId() { return membresiaId; }
    public void setMembresiaId(Integer membresiaId) { this.membresiaId = membresiaId; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    public String getTarjetaUltimos4() { return tarjetaUltimos4; }
    public void setTarjetaUltimos4(String tarjetaUltimos4) { this.tarjetaUltimos4 = tarjetaUltimos4; }
}
