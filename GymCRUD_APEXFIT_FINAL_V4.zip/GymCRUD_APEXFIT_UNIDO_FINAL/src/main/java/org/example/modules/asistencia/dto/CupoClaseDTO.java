package org.example.modules.asistencia.dto;

/** Cupos ocupados de una clase en una fecha y franja horaria. */
public class CupoClaseDTO {
    private Integer idClase;
    private String franja;
    private long ocupados;
    private Integer cupoMaximo;

    public CupoClaseDTO(Integer idClase, String franja, long ocupados, Integer cupoMaximo) {
        this.idClase = idClase;
        this.franja = franja;
        this.ocupados = ocupados;
        this.cupoMaximo = cupoMaximo;
    }

    public Integer getIdClase() { return idClase; }
    public String getFranja() { return franja; }
    public long getOcupados() { return ocupados; }
    public Integer getCupoMaximo() { return cupoMaximo; }
}
