package org.example.modules.seguimiento.repository;

import org.example.modules.seguimiento.entity.Seguimiento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SeguimientoRepository extends JpaRepository<Seguimiento, Integer> {
    List<Seguimiento> findByIdClienteOrderByFechaAscIdSeguimientoAsc(Integer idCliente);
}
