package org.example.modules.seguimiento.dto;

/** Datos mínimos de un cliente para que el entrenador lo seleccione (sin exponer el resto del perfil). */
public class AlumnoDTO {
    private Integer idCliente;
    private String nombre;
    private String apellido;
    private String cedula;

    public AlumnoDTO(Integer idCliente, String nombre, String apellido, String cedula) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
    }

    public Integer getIdCliente() { return idCliente; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getCedula() { return cedula; }
}
