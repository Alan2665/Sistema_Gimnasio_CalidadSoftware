package org.example.modules.auth.service;

import org.example.modules.auth.entity.AuthUser;
import org.example.modules.auth.entity.RecuperacionToken;
import org.example.modules.auth.repository.AuthUserRepository;
import org.example.modules.auth.repository.RecuperacionTokenRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.entrenador.entity.Entrenador;
import org.example.modules.entrenador.repository.EntrenadorRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.ArrayDeque;
import java.util.Base64;
import java.util.Deque;
import java.util.HexFormat;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Recuperación de contraseña por correo con enlace de un solo uso y vencimiento.
 *
 * <p>Si no hay un servidor SMTP configurado (modo desarrollo), el enlace se imprime en la consola del
 * servidor para poder probar el flujo completo sin enviar correos reales.</p>
 */
@Service
public class RecuperacionService {

    private static final Logger log = LoggerFactory.getLogger(RecuperacionService.class);
    private static final int MAX_SOLICITUDES = 5;
    private static final long VENTANA_MS = 15 * 60 * 1000L;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final AuthUserRepository authUserRepository;
    private final ClienteRepository clienteRepository;
    private final EntrenadorRepository entrenadorRepository;
    private final RecuperacionTokenRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final NotificacionService notificaciones;
    private final ObjectProvider<JavaMailSender> mailSender;

    @Value("${app.frontend-url:http://localhost:4200}")
    private String frontendUrl = "http://localhost:4200";

    @Value("${app.mail.enabled:false}")
    private boolean mailEnabled = false;

    @Value("${app.mail.from:no-reply@apexfit.local}")
    private String mailFrom = "no-reply@apexfit.local";

    @Value("${app.recovery.minutes:30}")
    private long minutosValidez = 30;

    private final Map<String, Deque<Long>> solicitudes = new ConcurrentHashMap<>();

    public RecuperacionService(AuthUserRepository authUserRepository,
                               ClienteRepository clienteRepository,
                               EntrenadorRepository entrenadorRepository,
                               RecuperacionTokenRepository tokenRepository,
                               PasswordEncoder passwordEncoder,
                               NotificacionService notificaciones,
                               ObjectProvider<JavaMailSender> mailSender) {
        this.authUserRepository = authUserRepository;
        this.clienteRepository = clienteRepository;
        this.entrenadorRepository = entrenadorRepository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.notificaciones = notificaciones;
        this.mailSender = mailSender;
    }

    /** @return true si el enlace quedó solo en la consola (modo desarrollo, sin SMTP). */
    @Transactional
    public boolean solicitar(String identificador) {
        String id = identificador == null ? "" : identificador.trim();
        if (id.isEmpty()) throw new IllegalArgumentException("Ingresa tu usuario o correo");
        limitarSolicitudes(id);

        boolean smtpListo = mailEnabled && mailSender.getIfAvailable() != null;
        Optional<Destino> destino = resolverDestino(id);

        // Respuesta siempre genérica: no se revela si la cuenta existe.
        if (destino.isEmpty()) return !smtpListo;

        AuthUser user = destino.get().user();
        tokenRepository.invalidarAnteriores(user.getId());

        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);

        RecuperacionToken entidad = new RecuperacionToken();
        entidad.setAuthUserId(user.getId());
        entidad.setTokenHash(hash(token));
        entidad.setExpira(LocalDateTime.now().plusMinutes(minutosValidez));
        tokenRepository.save(entidad);

        String enlace = frontendUrl + "/restablecer?token=" + token;
        if (smtpListo && destino.get().correo() != null && !destino.get().correo().isBlank()) {
            enviarCorreo(destino.get().correo(), user.getUsername(), enlace);
        } else if (!smtpListo) {
            log.warn("[RECUPERACIÓN DE CLAVE - MODO DESARROLLO] Usuario '{}' -> enlace (válido {} min): {}",
                    user.getUsername(), minutosValidez, enlace);
        }
        return !smtpListo;
    }

    @Transactional
    public void restablecer(String token, String nuevaClave) {
        if (nuevaClave == null || nuevaClave.length() < 6) {
            throw new IllegalArgumentException("La nueva contraseña debe tener al menos 6 caracteres.");
        }
        RecuperacionToken t = tokenRepository.findByTokenHash(hash(token == null ? "" : token.trim()))
                .orElseThrow(() -> new IllegalArgumentException("El enlace no es válido o ya venció."));
        if (Boolean.TRUE.equals(t.getUsado()) || t.getExpira().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("El enlace no es válido o ya venció.");
        }
        AuthUser user = authUserRepository.findById(t.getAuthUserId())
                .orElseThrow(() -> new IllegalArgumentException("El enlace no es válido o ya venció."));

        user.setPassword(passwordEncoder.encode(nuevaClave));
        authUserRepository.save(user);
        t.setUsado(true);
        tokenRepository.save(t);

        notificaciones.notificar(user.getUsername(), "SEGURIDAD", "Contraseña restablecida",
                "Tu contraseña fue restablecida con el enlace de recuperación.");
        notificaciones.notificarAdmins("SEGURIDAD", "Clave restablecida",
                "El usuario \"" + user.getUsername() + "\" (" + user.getRole() + ") restableció su contraseña.");
    }

    // ------------------------------------------------------------------ auxiliares

    private record Destino(AuthUser user, String correo) { }

    /** Busca por username o por correo (clientes y entrenadores). El ADMIN no usa este flujo. */
    private Optional<Destino> resolverDestino(String id) {
        Optional<AuthUser> porUsername = authUserRepository.findByUsername(id);
        if (porUsername.isPresent()) {
            AuthUser u = porUsername.get();
            if (!Boolean.TRUE.equals(u.getActivo())) return Optional.empty();
            Optional<String> correo = correoDe(u);
            if (correo.isPresent()) return Optional.of(new Destino(u, correo.get()));
            boolean conPerfil = "CLIENTE".equals(u.getRole()) || "ENTRENADOR".equals(u.getRole());
            if (conPerfil) return Optional.of(new Destino(u, null));
            return Optional.empty();
        }
        Optional<Cliente> cliente = clienteRepository.findFirstByCorreoIgnoreCase(id);
        if (cliente.isPresent() && cliente.get().getAuthUserId() != null) {
            return authUserRepository.findById(cliente.get().getAuthUserId())
                    .filter(u -> Boolean.TRUE.equals(u.getActivo()))
                    .map(u -> new Destino(u, cliente.get().getCorreo()));
        }
        Optional<Entrenador> entrenador = entrenadorRepository.findFirstByCorreoIgnoreCase(id);
        if (entrenador.isPresent() && entrenador.get().getAuthUserId() != null) {
            return authUserRepository.findById(entrenador.get().getAuthUserId())
                    .filter(u -> Boolean.TRUE.equals(u.getActivo()))
                    .map(u -> new Destino(u, entrenador.get().getCorreo()));
        }
        return Optional.empty();
    }

    private Optional<String> correoDe(AuthUser u) {
        if ("CLIENTE".equals(u.getRole())) {
            return clienteRepository.findByAuthUserId(u.getId()).map(Cliente::getCorreo).filter(c -> !c.isBlank());
        }
        if ("ENTRENADOR".equals(u.getRole())) {
            return entrenadorRepository.findByAuthUserId(u.getId()).map(Entrenador::getCorreo).filter(c -> !c.isBlank());
        }
        return Optional.empty();
    }

    private void enviarCorreo(String para, String username, String enlace) {
        try {
            JavaMailSender sender = mailSender.getIfAvailable();
            if (sender == null) return;
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(mailFrom);
            msg.setTo(para);
            msg.setSubject("APEX FIT - Restablecer contraseña");
            msg.setText("Hola " + username + ",\n\nRecibimos una solicitud para restablecer tu contraseña.\n"
                    + "Usa este enlace (válido por " + minutosValidez + " minutos y de un solo uso):\n\n"
                    + enlace + "\n\nSi no fuiste tú, ignora este mensaje.\n\nAPEX FIT");
            sender.send(msg);
        } catch (Exception e) {
            log.error("No se pudo enviar el correo de recuperación: {}", e.getMessage());
        }
    }

    private void limitarSolicitudes(String id) {
        Deque<Long> marcas = solicitudes.computeIfAbsent(id.toLowerCase(), k -> new ArrayDeque<>());
        synchronized (marcas) {
            long limite = System.currentTimeMillis() - VENTANA_MS;
            while (!marcas.isEmpty() && marcas.peekFirst() < limite) marcas.removeFirst();
            if (marcas.size() >= MAX_SOLICITUDES) {
                throw new IllegalArgumentException("Demasiadas solicitudes. Intenta de nuevo en unos minutos.");
            }
            marcas.addLast(System.currentTimeMillis());
        }
    }

    static String hash(String token) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(token.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
