package org.example.modules.asistencia.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/** Registro de asistencia por QR (o cédula escrita a mano). */
public class QrAsistenciaRequest {
    @NotBlank
    private String codigo;
    @NotNull
    private Integer claseId;

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public Integer getClaseId() { return claseId; }
    public void setClaseId(Integer claseId) { this.claseId = claseId; }
}
