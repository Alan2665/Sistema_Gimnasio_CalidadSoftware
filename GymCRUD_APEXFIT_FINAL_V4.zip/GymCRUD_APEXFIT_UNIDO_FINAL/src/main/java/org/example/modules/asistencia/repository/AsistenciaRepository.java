package org.example.modules.asistencia.repository;

import org.example.modules.asistencia.entity.Asistencia;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;


/**
 * Documentación JavaDoc de la clase AsistenciaRepository.
 *
 * <p>Forma parte del sistema APEX FIT y describe la responsabilidad
 * principal del componente dentro de la arquitectura Spring Boot del proyecto.
 * Esta documentación permite generar la interfaz HTML de JavaDoc para revisión
 * académica y mantenimiento del código.</p>
 *
 * <p>Paquete/archivo: org.example.modules.asistencia.repository.AsistenciaRepository.java</p>
 *
 * @author Javier Eduardo Paredes Cabrera
 * @version 1.0
 */
/**
 * Repositorio JPA encargado del acceso a datos para el módulo asistencia.
 *
 * <p>Esta documentación forma parte del JavaDoc Maven del proyecto y permite
 * explicar la responsabilidad de la clase durante la revisión técnica.</p>
 *
 * @author Javier Paredes
 * @version 1.0
 */
public interface AsistenciaRepository extends JpaRepository<Asistencia, Integer> {
    List<Asistencia> findByClienteAuthUserId(Long authUserId);
    List<Asistencia> findByClaseEntrenadorAuthUserId(Long authUserId);

    List<Asistencia> findByClaseIdClaseAndFechaAsistenciaOrderByIdAsistenciaAsc(Integer idClase, LocalDate fecha);

    java.util.Optional<Asistencia> findFirstByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(Integer idCliente, Integer idClase, LocalDate fecha);

    long countByClaseIdClaseAndFechaAsistencia(Integer idClase, LocalDate fecha);

    long countByClaseIdClaseAndFechaAsistenciaAndFranja(Integer idClase, LocalDate fecha, String franja);

    boolean existsByClienteIdClienteAndClaseEntrenadorAuthUserId(Integer idCliente, Long authUserId);

    boolean existsByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(Integer idCliente, Integer idClase, LocalDate fecha);

    /** Devuelve pares [idClase, cantidad] de asistencias registradas en una fecha. */
    @Query("select a.clase.idClase, a.franja, count(a) from Asistencia a where a.fechaAsistencia = :fecha group by a.clase.idClase, a.franja")
    List<Object[]> contarPorClase(@Param("fecha") LocalDate fecha);
}
