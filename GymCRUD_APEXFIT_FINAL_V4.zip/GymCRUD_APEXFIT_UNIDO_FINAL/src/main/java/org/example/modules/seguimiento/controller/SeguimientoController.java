package org.example.modules.seguimiento.controller;

import org.example.modules.seguimiento.dto.AlumnoDTO;
import org.example.modules.seguimiento.dto.SeguimientoRequest;
import org.example.modules.seguimiento.entity.Seguimiento;
import org.example.modules.seguimiento.service.SeguimientoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seguimientos")
public class SeguimientoController {

    private final SeguimientoService service;

    public SeguimientoController(SeguimientoService service) {
        this.service = service;
    }

    /** Clientes seleccionables (ADMIN / ENTRENADOR). */
    @GetMapping("/alumnos")
    public List<AlumnoDTO> alumnos() {
        return service.alumnos();
    }

    @GetMapping
    public List<Seguimiento> listar(@RequestParam(required = false) Integer clienteId) {
        return service.listar(clienteId);
    }

    @PostMapping
    public Seguimiento registrar(@RequestBody SeguimientoRequest request) {
        return service.registrar(request);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }
}
