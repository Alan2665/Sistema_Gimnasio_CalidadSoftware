package org.example.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Establece la nueva clave usando el token recibido por correo. */
public class RestablecerClaveRequest {
    @NotBlank
    private String token;

    @NotBlank
    @Size(min = 6, max = 100)
    private String nuevaClave;

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getNuevaClave() { return nuevaClave; }
    public void setNuevaClave(String nuevaClave) { this.nuevaClave = nuevaClave; }
}
