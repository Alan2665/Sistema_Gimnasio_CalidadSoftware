package org.example.modules.auth.dto;

/** Campos que el propio usuario puede editar de su perfil. */
public class ActualizarPerfilRequest {
    private String telefono;
    private String correo;

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}
