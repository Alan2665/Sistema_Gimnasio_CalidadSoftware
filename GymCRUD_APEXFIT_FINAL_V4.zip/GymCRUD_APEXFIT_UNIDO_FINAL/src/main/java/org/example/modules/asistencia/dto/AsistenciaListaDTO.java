package org.example.modules.asistencia.dto;

/** Fila de la lista de una clase: inscrito + si ya asistió. */
public class AsistenciaListaDTO {
    private Integer idAsistencia;
    private String cliente;
    private String cedula;
    private boolean presente;
    private String horaIngreso;
    private String franja;

    public AsistenciaListaDTO(Integer idAsistencia, String cliente, String cedula, boolean presente, String horaIngreso, String franja) {
        this.idAsistencia = idAsistencia;
        this.cliente = cliente;
        this.cedula = cedula;
        this.presente = presente;
        this.horaIngreso = horaIngreso;
        this.franja = franja;
    }

    public Integer getIdAsistencia() { return idAsistencia; }
    public String getCliente() { return cliente; }
    public String getCedula() { return cedula; }
    public boolean isPresente() { return presente; }
    public String getHoraIngreso() { return horaIngreso; }
    public String getFranja() { return franja; }
}
