package org.example.modules.inscripcion.service;

import org.example.common.security.AuthContext;
import org.example.common.security.IdentityService;
import org.example.exception.BusinessException;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.inscripcion.dto.InscripcionCompraRequest;
import org.example.modules.inscripcion.entity.Inscripcion;
import org.example.modules.inscripcion.repository.InscripcionRepository;
import org.example.modules.membresia.entity.Membresia;
import org.example.modules.membresia.repository.MembresiaRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.example.modules.pago.entity.Pago;
import org.example.modules.pago.repository.PagoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/** Inscripciones de membresía. El cliente solo puede crear inscripciones para sí mismo. */
@Service
public class InscripcionService {

    private final InscripcionRepository repository;
    private final NotificacionService notificaciones;
    private final IdentityService identity;
    private final MembresiaRepository membresiaRepository;
    private final PagoRepository pagoRepository;

    public InscripcionService(InscripcionRepository repository,
                              NotificacionService notificaciones,
                              IdentityService identity,
                              MembresiaRepository membresiaRepository,
                              PagoRepository pagoRepository) {
        this.repository = repository;
        this.notificaciones = notificaciones;
        this.identity = identity;
        this.membresiaRepository = membresiaRepository;
        this.pagoRepository = pagoRepository;
    }

    public List<Inscripcion> listar() {
        if (AuthContext.isAdmin()) return repository.findAll();
        if (AuthContext.isCliente()) return repository.findByClienteAuthUserId(identity.authUserId());
        return List.of();
    }

    public Inscripcion buscarPorId(Integer id) {
        Inscripcion i = repository.findById(id).orElse(null);
        if (i == null || AuthContext.isAdmin()) return i;
        if (AuthContext.isCliente() && i.getCliente() != null
                && identity.authUserId().equals(i.getCliente().getAuthUserId())) return i;
        return null;
    }

    /** Alta administrativa de una inscripción (el cliente debe usar {@link #comprarMembresia}). */
    public Inscripcion guardar(Inscripcion inscripcion) {
        AuthContext.requireAdmin();
        Inscripcion guardada = repository.save(inscripcion);
        notificar(guardada);
        return guardada;
    }

    /**
     * Compra de membresía por el propio cliente: crea la inscripción y su pago en un solo paso.
     * Los clientes no pueden pagar en efectivo.
     */
    @Transactional
    public Inscripcion comprarMembresia(InscripcionCompraRequest req) {
        AuthContext.requireAnyRole("CLIENTE");
        if (req == null || req.getMembresiaId() == null) {
            throw new IllegalArgumentException("Debes seleccionar una membresía");
        }
        String metodo = req.getMetodoPago() == null ? "" : req.getMetodoPago().trim().toUpperCase();
        if (!metodo.equals("TARJETA") && !metodo.equals("TRANSFERENCIA")) {
            throw new BusinessException("Los clientes solo pueden pagar con tarjeta o transferencia");
        }
        String referencia = null;
        if (metodo.equals("TARJETA")) {
            String ult = req.getTarjetaUltimos4();
            if (ult == null || !ult.matches("\\d{4}")) {
                throw new BusinessException("Completa los datos de la tarjeta para pagar");
            }
            referencia = "Tarjeta •••• " + ult;
        }

        Cliente cliente = identity.clienteActualObligatorio();
        Membresia plan = membresiaRepository.findById(req.getMembresiaId())
                .orElseThrow(() -> new IllegalArgumentException("La membresía seleccionada no existe"));
        LocalDate hoy = LocalDate.now();
        LocalDate inicio = req.getFechaInicio() == null || req.getFechaInicio().isBefore(hoy) ? hoy : req.getFechaInicio();
        int dias = plan.getDuracionDias() == null ? 30 : plan.getDuracionDias();

        Inscripcion nueva = new Inscripcion();
        nueva.setCliente(cliente);
        nueva.setMembresia(plan);
        nueva.setFechaInicio(inicio);
        nueva.setFechaFin(inicio.plusDays(dias));
        nueva.setEstado("Activa");
        Inscripcion guardada = repository.save(nueva);

        Pago pago = new Pago();
        pago.setInscripcion(guardada);
        pago.setTipoPago("MEMBRESIA");
        pago.setMonto(plan.getPrecio());
        pago.setFechaPago(hoy);
        pago.setMetodoPago(metodo);
        pago.setEstado("Completado");
        pago.setReferenciaPago(referencia);
        pagoRepository.save(pago);

        notificar(guardada);
        notificaciones.notificarAdmins("VENTA", "Pago de membresía",
                cliente.getNombre() + " " + cliente.getApellido() + " pagó la membresía " + plan.getNombre()
                        + " ($" + plan.getPrecio() + ", " + metodo + "). Recibo disponible en Pagos.");
        return guardada;
    }

    public Inscripcion actualizar(Integer id, Inscripcion inscripcion) {
        AuthContext.requireAdmin();
        inscripcion.setIdInscripcion(id);
        return repository.save(inscripcion);
    }

    public void eliminar(Integer id) {
        AuthContext.requireAdmin();
        repository.deleteById(id);
    }

    private void notificar(Inscripcion guardada) {
        try {
            if (guardada.getCliente() == null || guardada.getMembresia() == null) return;
            String cliente = guardada.getCliente().getNombre() + " " + guardada.getCliente().getApellido();
            String plan = guardada.getMembresia().getNombre();
            if (AuthContext.isAdmin()) {
                notificaciones.notificarPorAuthUserId(guardada.getCliente().getAuthUserId(), "INSCRIPCION",
                        "Membresía registrada", "Se registró tu membresía " + plan + " hasta el " + guardada.getFechaFin() + ".");
            } else {
                notificaciones.notificarAdmins("INSCRIPCION", "Nueva inscripción de membresía",
                        cliente + " se inscribió al plan " + plan + ".");
                notificaciones.notificarPorAuthUserId(guardada.getCliente().getAuthUserId(), "INSCRIPCION",
                        "Inscripción registrada", "Tu inscripción al plan " + plan + " fue registrada.");
            }
        } catch (Exception ignored) {
            // La notificación nunca debe romper la inscripción.
        }
    }
}
