package org.example.modules.seguimiento.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Datos para registrar una medición de seguimiento. */
public class SeguimientoRequest {
    private Integer clienteId;
    private LocalDate fecha;
    private BigDecimal pesoKg;
    private BigDecimal cinturaCm;
    private BigDecimal pechoCm;
    private BigDecimal caderaCm;
    private BigDecimal brazoCm;
    private String notas;

    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public BigDecimal getPesoKg() { return pesoKg; }
    public void setPesoKg(BigDecimal pesoKg) { this.pesoKg = pesoKg; }
    public BigDecimal getCinturaCm() { return cinturaCm; }
    public void setCinturaCm(BigDecimal cinturaCm) { this.cinturaCm = cinturaCm; }
    public BigDecimal getPechoCm() { return pechoCm; }
    public void setPechoCm(BigDecimal pechoCm) { this.pechoCm = pechoCm; }
    public BigDecimal getCaderaCm() { return caderaCm; }
    public void setCaderaCm(BigDecimal caderaCm) { this.caderaCm = caderaCm; }
    public BigDecimal getBrazoCm() { return brazoCm; }
    public void setBrazoCm(BigDecimal brazoCm) { this.brazoCm = brazoCm; }
    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }
}
