package org.example.modules.asistencia.dto;

import jakarta.validation.constraints.NotNull;

/** Ingreso directo (ADMIN): el cliente llega y se registra de inmediato en la clase. */
public class IngresoDirectoRequest {
    @NotNull
    private Integer clienteId;
    @NotNull
    private Integer claseId;

    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }
    public Integer getClaseId() { return claseId; }
    public void setClaseId(Integer claseId) { this.claseId = claseId; }
}
