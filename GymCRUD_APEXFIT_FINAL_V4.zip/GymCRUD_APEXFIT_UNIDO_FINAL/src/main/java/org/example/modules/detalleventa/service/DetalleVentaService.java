package org.example.modules.detalleventa.service;

import org.example.common.security.AuthContext;
import org.example.common.security.IdentityService;
import org.example.modules.detalleventa.entity.DetalleVenta;
import org.example.modules.detalleventa.repository.DetalleVentaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/** Detalle de ventas: el ADMIN ve todo; el CLIENTE solo los detalles de sus propias compras. */
@Service
public class DetalleVentaService {

    private final DetalleVentaRepository repository;
    private final IdentityService identity;

    public DetalleVentaService(DetalleVentaRepository repository, IdentityService identity) {
        this.repository = repository;
        this.identity = identity;
    }

    public List<DetalleVenta> listar() {
        if (AuthContext.isAdmin()) return repository.findAll();
        if (AuthContext.isCliente()) return repository.findByVentaClienteAuthUserId(identity.authUserId());
        return List.of();
    }

    public DetalleVenta buscarPorId(Integer id) {
        DetalleVenta d = repository.findById(id).orElse(null);
        if (d == null || AuthContext.isAdmin()) return d;
        if (AuthContext.isCliente() && d.getVenta() != null && d.getVenta().getCliente() != null
                && identity.authUserId().equals(d.getVenta().getCliente().getAuthUserId())) return d;
        return null;
    }

    public DetalleVenta guardar(DetalleVenta detalleVenta) {
        AuthContext.requireAdmin();
        return repository.save(detalleVenta);
    }

    public DetalleVenta actualizar(Integer id, DetalleVenta detalleVenta) {
        AuthContext.requireAdmin();
        detalleVenta.setIdDetalle(id);
        return repository.save(detalleVenta);
    }

    public void eliminar(Integer id) {
        AuthContext.requireAdmin();
        repository.deleteById(id);
    }
}
