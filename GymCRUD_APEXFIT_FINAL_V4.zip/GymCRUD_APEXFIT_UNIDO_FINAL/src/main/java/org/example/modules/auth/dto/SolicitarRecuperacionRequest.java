package org.example.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;

/** Solicitud pública de recuperación: usuario o correo registrado. */
public class SolicitarRecuperacionRequest {
    @NotBlank
    private String identificador;

    public String getIdentificador() { return identificador; }
    public void setIdentificador(String identificador) { this.identificador = identificador; }
}
