package org.example.modules.alertas.service;

import org.example.modules.inscripcion.entity.Inscripcion;
import org.example.modules.inscripcion.repository.InscripcionRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.example.modules.producto.entity.Producto;
import org.example.modules.producto.repository.ProductoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Tareas automáticas: avisos de membresías por vencer / vencidas y de stock bajo.
 * Se ejecuta al iniciar la aplicación y todos los días a las 08:00.
 * Los avisos no se repiten (se deduplican por destinatario + título + mensaje).
 */
@Service
public class AlertasProgramadasService {

    private static final Logger log = LoggerFactory.getLogger(AlertasProgramadasService.class);

    private final InscripcionRepository inscripcionRepository;
    private final ProductoRepository productoRepository;
    private final NotificacionService notificaciones;

    @Value("${app.alertas.dias-aviso:3}")
    private int diasAviso = 3;

    @Value("${app.stock.minimo:5}")
    private int stockMinimo = 5;

    public AlertasProgramadasService(InscripcionRepository inscripcionRepository,
                                     ProductoRepository productoRepository,
                                     NotificacionService notificaciones) {
        this.inscripcionRepository = inscripcionRepository;
        this.productoRepository = productoRepository;
        this.notificaciones = notificaciones;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void alIniciar() {
        ejecutar();
    }

    @Scheduled(cron = "${app.alertas.cron:0 0 8 * * *}")
    public void ejecutar() {
        try {
            revisarMembresias();
            revisarStock();
        } catch (Exception e) {
            log.warn("No se pudieron generar las alertas programadas: {}", e.getMessage());
        }
    }

    void revisarMembresias() {
        LocalDate hoy = LocalDate.now();
        int porVencer = 0;

        for (Inscripcion i : inscripcionRepository.findAll()) {
            if (!"ACTIVA".equalsIgnoreCase(i.getEstado()) || i.getFechaFin() == null || i.getCliente() == null) continue;
            String plan = i.getMembresia() == null ? "tu membresía" : "tu membresía " + i.getMembresia().getNombre();
            String cliente = i.getCliente().getNombre() + " " + i.getCliente().getApellido();

            if (i.getFechaFin().isBefore(hoy)) {
                // Venció: se marca como Vencida y se avisa una sola vez.
                i.setEstado("Vencida");
                inscripcionRepository.save(i);
                notificaciones.notificarUnicaPorAuthUserId(i.getCliente().getAuthUserId(), "INSCRIPCION",
                        "Membresía vencida", plan + " venció el " + i.getFechaFin() + ". Renuévala para seguir entrenando.");
                notificaciones.notificarUnicaAdmins("INSCRIPCION", "Membresía vencida",
                        "La membresía de " + cliente + " venció el " + i.getFechaFin() + ".");
                continue;
            }

            long dias = ChronoUnit.DAYS.between(hoy, i.getFechaFin());
            if (dias <= diasAviso) {
                porVencer++;
                String cuando = dias == 0 ? "vence hoy" : "vence el " + i.getFechaFin();
                notificaciones.notificarUnicaPorAuthUserId(i.getCliente().getAuthUserId(), "INSCRIPCION",
                        "Tu membresía está por vencer", plan + " " + cuando + ". Renuévala a tiempo.");
            }
        }

        if (porVencer > 0) {
            notificaciones.notificarUnicaAdmins("INSCRIPCION", "Membresías por vencer",
                    porVencer + " membresía(s) vencen en los próximos " + diasAviso + " días (" + hoy + ").");
        }
    }

    void revisarStock() {
        List<Producto> bajos = productoRepository.findByStockLessThanEqual(stockMinimo);
        for (Producto p : bajos) {
            int stock = p.getStock() == null ? 0 : p.getStock();
            notificaciones.notificarUnicaAdmins("STOCK", "Stock bajo: " + p.getNombre(),
                    "Quedan " + stock + " unidades de " + p.getNombre() + ". Considera reponer inventario.");
        }
    }
}
