package org.example.modules.asistencia.dto;

/** Resultado de confirmar la asistencia de un cliente inscrito. */
public class QrAsistenciaResponse {
    private String cliente;
    private String cedula;
    private String clase;
    private String fecha;
    private String hora;
    private long presentes;
    private long inscritos;
    private String mensaje;

    public QrAsistenciaResponse(String cliente, String cedula, String clase, String fecha,
                                String hora, long presentes, long inscritos, String mensaje) {
        this.cliente = cliente;
        this.cedula = cedula;
        this.clase = clase;
        this.fecha = fecha;
        this.hora = hora;
        this.presentes = presentes;
        this.inscritos = inscritos;
        this.mensaje = mensaje;
    }

    public String getCliente() { return cliente; }
    public String getCedula() { return cedula; }
    public String getClase() { return clase; }
    public String getFecha() { return fecha; }
    public String getHora() { return hora; }
    public long getPresentes() { return presentes; }
    public long getInscritos() { return inscritos; }
    public String getMensaje() { return mensaje; }
}
