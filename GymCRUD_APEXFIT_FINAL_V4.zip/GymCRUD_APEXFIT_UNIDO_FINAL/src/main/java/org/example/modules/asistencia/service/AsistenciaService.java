package org.example.modules.asistencia.service;

import org.example.common.security.AuthContext;
import org.example.common.security.IdentityService;
import org.example.exception.BusinessException;
import org.example.modules.asistencia.dto.AsistenciaListaDTO;
import org.example.modules.asistencia.dto.CupoClaseDTO;
import org.example.modules.asistencia.dto.QrAsistenciaResponse;
import org.example.modules.asistencia.entity.Asistencia;
import org.example.modules.asistencia.repository.AsistenciaRepository;
import org.example.modules.clase.entity.Clase;
import org.example.modules.clase.repository.ClaseRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.entrenador.entity.Entrenador;
import org.example.modules.inscripcion.entity.Inscripcion;
import org.example.modules.inscripcion.repository.InscripcionRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Servicio de asistencias.
 *
 * <p>Reglas de negocio aplicadas a todo registro: cliente activo, membresía vigente en la fecha,
 * sin duplicar la misma clase el mismo día y respetando el cupo máximo de la clase.</p>
 */
@Service
public class AsistenciaService {

    private final AsistenciaRepository repository;
    private final ClaseRepository claseRepository;
    private final ClienteRepository clienteRepository;
    private final InscripcionRepository inscripcionRepository;
    private final NotificacionService notificaciones;
    private final IdentityService identity;

    public AsistenciaService(AsistenciaRepository repository,
                             ClaseRepository claseRepository,
                             ClienteRepository clienteRepository,
                             InscripcionRepository inscripcionRepository,
                             NotificacionService notificaciones,
                             IdentityService identity) {
        this.repository = repository;
        this.claseRepository = claseRepository;
        this.clienteRepository = clienteRepository;
        this.inscripcionRepository = inscripcionRepository;
        this.notificaciones = notificaciones;
        this.identity = identity;
    }

    // ------------------------------------------------------------------ lectura

    public List<Asistencia> listar() {
        if (AuthContext.isAdmin()) return repository.findAll();
        Long authUserId = identity.authUserId();
        if (AuthContext.isCliente()) return repository.findByClienteAuthUserId(authUserId);
        if (AuthContext.isEntrenador()) return repository.findByClaseEntrenadorAuthUserId(authUserId);
        return List.of();
    }

    public Asistencia buscarPorId(Integer id) {
        Asistencia a = repository.findById(id).orElse(null);
        if (a == null || AuthContext.isAdmin()) return a;
        Long authUserId = identity.authUserId();
        if (AuthContext.isCliente() && a.getCliente() != null
                && authUserId.equals(a.getCliente().getAuthUserId())) return a;
        if (AuthContext.isEntrenador() && a.getClase() != null && a.getClase().getEntrenador() != null
                && authUserId.equals(a.getClase().getEntrenador().getAuthUserId())) return a;
        return null;
    }

    /** Cupos ocupados por clase y franja en una fecha (visible para cualquier usuario autenticado). */
    public List<CupoClaseDTO> cuposPorFecha(LocalDate fecha) {
        LocalDate f = fecha == null ? LocalDate.now() : fecha;
        Map<String, Long> porFranja = new HashMap<>();
        Map<Integer, Long> porClase = new HashMap<>();
        for (Object[] fila : repository.contarPorClase(f)) {
            Integer idClase = (Integer) fila[0];
            String franja = fila[1] == null ? "" : (String) fila[1];
            long n = ((Number) fila[2]).longValue();
            porFranja.merge(idClase + "|" + franja, n, Long::sum);
            porClase.merge(idClase, n, Long::sum);
        }
        List<CupoClaseDTO> resultado = new ArrayList<>();
        for (Clase c : claseRepository.findAll()) {
            List<String> franjas = franjasDe(c);
            if (franjas.isEmpty()) {
                resultado.add(new CupoClaseDTO(c.getIdClase(), null, porClase.getOrDefault(c.getIdClase(), 0L), c.getCupoMaximo()));
            } else {
                for (String fr : franjas) {
                    resultado.add(new CupoClaseDTO(c.getIdClase(), fr,
                            porFranja.getOrDefault(c.getIdClase() + "|" + fr, 0L), c.getCupoMaximo()));
                }
            }
        }
        return resultado;
    }

    // ------------------------------------------------------------------ escritura

    /** Inscripción a una clase desde el formulario (ADMIN para cualquier cliente, CLIENTE solo para sí mismo). */
    public Asistencia guardar(Asistencia payload) {
        AuthContext.requireAnyRole("ADMIN", "CLIENTE");
        if (payload == null || payload.getClase() == null || payload.getClase().getIdClase() == null) {
            throw new IllegalArgumentException("Debes seleccionar una clase");
        }
        Clase clase = claseRepository.findById(payload.getClase().getIdClase())
                .orElseThrow(() -> new IllegalArgumentException("La clase seleccionada no existe"));

        Cliente cliente;
        if (AuthContext.isCliente()) {
            // El cliente solo puede inscribirse a sí mismo, sin importar lo que venga en el cuerpo.
            cliente = identity.clienteActualObligatorio();
        } else {
            if (payload.getCliente() == null || payload.getCliente().getIdCliente() == null) {
                throw new IllegalArgumentException("Debes seleccionar un cliente");
            }
            cliente = clienteRepository.findById(payload.getCliente().getIdCliente())
                    .orElseThrow(() -> new IllegalArgumentException("El cliente seleccionado no existe"));
        }

        LocalDate hoy = LocalDate.now();
        LocalDate fecha = payload.getFechaAsistencia() == null ? hoy : payload.getFechaAsistencia();
        if (AuthContext.isCliente() && fecha.isBefore(hoy)) {
            throw new BusinessException("Solo puedes inscribirte a clases de hoy en adelante");
        }
        return registrarAsistencia(cliente, clase, fecha, payload.getFranja(), true);
    }

    /**
     * Toma de lista: confirma que un cliente YA INSCRITO en la clase de hoy realmente asistió.
     * No crea inscripciones; si el cliente no está inscrito, se rechaza.
     */
    public QrAsistenciaResponse registrarPorQr(String codigo, Integer claseId) {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        Clase clase = claseRepository.findById(claseId)
                .orElseThrow(() -> new IllegalArgumentException("La clase seleccionada no existe"));
        validarClasePropia(clase);

        Cliente cliente = buscarClientePorCodigo(codigo);
        LocalDate hoy = LocalDate.now();
        String nombre = cliente.getNombre() + " " + cliente.getApellido();

        Asistencia inscripcion = repository
                .findFirstByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(cliente.getIdCliente(), clase.getIdClase(), hoy)
                .orElseThrow(() -> new BusinessException(nombre + " no está inscrito en " + clase.getNombre()
                        + " para hoy. Debe inscribirse primero (desde Asistencias)."));

        Asistencia confirmada = confirmarPresencia(inscripcion);
        return respuestaPresencia(confirmada, clase, cliente, "Asistencia confirmada: " + nombre);
    }

    /** Marca como presente a un inscrito desde la lista de la clase (sin cámara). */
    public QrAsistenciaResponse marcarPresente(Integer idAsistencia) {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        Asistencia a = repository.findById(idAsistencia)
                .orElseThrow(() -> new IllegalArgumentException("La inscripción no existe"));
        validarClasePropia(a.getClase());
        Asistencia confirmada = confirmarPresencia(a);
        String nombre = a.getCliente().getNombre() + " " + a.getCliente().getApellido();
        return respuestaPresencia(confirmada, a.getClase(), a.getCliente(), "Asistencia confirmada: " + nombre);
    }

    /** Lista de inscritos de una clase en una fecha, con su estado de asistencia. */
    public List<AsistenciaListaDTO> listaDeClase(Integer claseId, LocalDate fecha) {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        Clase clase = claseRepository.findById(claseId)
                .orElseThrow(() -> new IllegalArgumentException("La clase seleccionada no existe"));
        validarClasePropia(clase);
        LocalDate f = fecha == null ? LocalDate.now() : fecha;

        List<AsistenciaListaDTO> lista = new ArrayList<>();
        for (Asistencia a : repository.findByClaseIdClaseAndFechaAsistenciaOrderByIdAsistenciaAsc(claseId, f)) {
            String hora = a.getHoraIngreso() == null ? null
                    : String.format("%02d:%02d", a.getHoraIngreso().getHour(), a.getHoraIngreso().getMinute());
            lista.add(new AsistenciaListaDTO(a.getIdAsistencia(),
                    a.getCliente().getNombre() + " " + a.getCliente().getApellido(),
                    a.getCliente().getCedula(), Boolean.TRUE.equals(a.getPresente()), hora, a.getFranja()));
        }
        return lista;
    }

    /** Núcleo de la toma de lista: pasa una inscripción a "presente" una sola vez. */
    public Asistencia confirmarPresencia(Asistencia inscripcion) {
        if (Boolean.TRUE.equals(inscripcion.getPresente())) {
            String nombre = inscripcion.getCliente().getNombre() + " " + inscripcion.getCliente().getApellido();
            throw new BusinessException(nombre + " ya fue registrado como presente en esta clase");
        }
        inscripcion.setPresente(true);
        inscripcion.setHoraIngreso(java.time.LocalDateTime.now());
        return repository.save(inscripcion);
    }

    /** El entrenador solo puede tomar lista en sus propias clases; el ADMIN en cualquiera. */
    private void validarClasePropia(Clase clase) {
        if (!AuthContext.isEntrenador()) return;
        Entrenador propio = identity.entrenadorActual()
                .orElseThrow(() -> new SecurityException("Tu usuario no está vinculado a un entrenador"));
        if (clase.getEntrenador() == null
                || !propio.getIdEntrenador().equals(clase.getEntrenador().getIdEntrenador())) {
            throw new SecurityException("Solo puedes tomar lista en tus propias clases");
        }
    }

    private QrAsistenciaResponse respuestaPresencia(Asistencia a, Clase clase, Cliente cliente, String mensaje) {
        LocalDate fecha = a.getFechaAsistencia();
        List<Asistencia> inscritos = repository.findByClaseIdClaseAndFechaAsistenciaOrderByIdAsistenciaAsc(clase.getIdClase(), fecha);
        long presentes = inscritos.stream().filter(x -> Boolean.TRUE.equals(x.getPresente())).count();
        String hora = a.getHoraIngreso() == null ? ""
                : String.format("%02d:%02d", a.getHoraIngreso().getHour(), a.getHoraIngreso().getMinute());
        return new QrAsistenciaResponse(cliente.getNombre() + " " + cliente.getApellido(), cliente.getCedula(),
                clase.getNombre(), String.valueOf(fecha), hora, presentes, inscritos.size(), mensaje);
    }

    /** Inscripción sin franja elegida (se valida contra los días de la clase si los tiene). */
    public Asistencia registrarAsistencia(Cliente cliente, Clase clase, LocalDate fecha) {
        return registrarAsistencia(cliente, clase, fecha, null, true);
    }

    /**
     * Núcleo de las reglas de negocio de una inscripción. Lanza {@link BusinessException} si no se cumplen.
     *
     * @param validarAgenda si es false (ingreso directo del ADMIN) no se exige que la fecha caiga en un día de la clase
     */
    public Asistencia registrarAsistencia(Cliente cliente, Clase clase, LocalDate fecha, String franja, boolean validarAgenda) {
        if (cliente == null || clase == null) {
            throw new IllegalArgumentException("Cliente y clase son obligatorios");
        }
        if (Boolean.FALSE.equals(cliente.getEstado())) {
            throw new BusinessException("El cliente está inactivo");
        }
        boolean propio = AuthContext.isCliente();
        String nombre = cliente.getNombre() + " " + cliente.getApellido();

        String franjaFinal = validarAgenda ? validarAgenda(clase, fecha, franja) : (franja == null || franja.isBlank() ? null : franja);

        if (inscripcionVigente(cliente, fecha).isEmpty()) {
            throw new BusinessException(propio
                    ? "No tienes una membresía vigente para el " + fecha
                        + ". Registra o renueva tu membresía antes de inscribirte a una clase."
                    : nombre + " no tiene una membresía vigente para el " + fecha
                        + ". Debe registrar o renovar su membresía.");
        }
        if (repository.existsByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(
                cliente.getIdCliente(), clase.getIdClase(), fecha)) {
            throw new BusinessException(propio
                    ? "Ya estás inscrito en " + clase.getNombre() + " para el " + fecha
                    : nombre + " ya está registrado en " + clase.getNombre() + " para el " + fecha);
        }
        Integer cupo = clase.getCupoMaximo();
        if (cupo != null && cupo > 0) {
            long ocupados = franjaFinal == null
                    ? repository.countByClaseIdClaseAndFechaAsistencia(clase.getIdClase(), fecha)
                    : repository.countByClaseIdClaseAndFechaAsistenciaAndFranja(clase.getIdClase(), fecha, franjaFinal);
            if (ocupados >= cupo) {
                throw new BusinessException("La clase " + clase.getNombre()
                        + (franjaFinal == null ? "" : " (" + franjaFinal + ")") + " está llena para el " + fecha
                        + " (" + ocupados + "/" + cupo + ")");
            }
        }

        Asistencia nueva = new Asistencia();
        nueva.setCliente(cliente);
        nueva.setClase(clase);
        nueva.setFechaAsistencia(fecha);
        nueva.setFranja(franjaFinal);
        nueva.setPresente(false);
        Asistencia guardada = repository.save(nueva);
        notificarInscripcionAClase(guardada);
        return guardada;
    }

    /** Verifica que la fecha sea un día de la clase y que la franja exista; devuelve la franja final (o null). */
    private String validarAgenda(Clase clase, LocalDate fecha, String franja) {
        Set<String> dias = diasDe(clase);
        if (!dias.isEmpty() && !dias.contains(codigoDia(fecha.getDayOfWeek()))) {
            throw new BusinessException("La clase " + clase.getNombre() + " solo se dicta: " + nombresDias(dias)
                    + ". El " + fecha + " es " + nombreDia(fecha.getDayOfWeek()) + ".");
        }
        List<String> franjas = franjasDe(clase);
        if (franjas.isEmpty()) return franja == null || franja.isBlank() ? null : franja;
        if (franja == null || franja.isBlank()) {
            if (franjas.size() == 1) return franjas.get(0);
            throw new BusinessException("Elige el horario de la clase " + clase.getNombre() + ".");
        }
        if (!franjas.contains(franja)) {
            throw new BusinessException("El horario " + franja + " no está disponible en la clase " + clase.getNombre()
                    + ". Disponibles: " + String.join(", ", franjas));
        }
        return franja;
    }

    /** Ingreso directo del ADMIN (cliente sin inscripción previa): inscribe si hace falta y marca presente. */
    public QrAsistenciaResponse ingresoDirecto(Integer clienteId, Integer claseId) {
        AuthContext.requireAdmin();
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("El cliente seleccionado no existe"));
        Clase clase = claseRepository.findById(claseId)
                .orElseThrow(() -> new IllegalArgumentException("La clase seleccionada no existe"));
        LocalDate hoy = LocalDate.now();

        Asistencia a = repository
                .findFirstByClienteIdClienteAndClaseIdClaseAndFechaAsistencia(clienteId, claseId, hoy)
                .orElseGet(() -> registrarAsistencia(cliente, clase, hoy, franjaActual(clase), false));
        Asistencia confirmada = confirmarPresencia(a);
        return respuestaPresencia(confirmada, clase, cliente,
                "Ingreso registrado: " + cliente.getNombre() + " " + cliente.getApellido());
    }

    /** Franja que contiene la hora actual (o la primera si ninguna coincide; null si la clase no tiene franjas). */
    private String franjaActual(Clase clase) {
        List<String> franjas = franjasDe(clase);
        if (franjas.isEmpty()) return null;
        java.time.LocalTime ahora = java.time.LocalTime.now();
        for (String fr : franjas) {
            String[] p = fr.split("-");
            if (p.length == 2) {
                try {
                    if (!ahora.isBefore(java.time.LocalTime.parse(p[0])) && !ahora.isAfter(java.time.LocalTime.parse(p[1]))) return fr;
                } catch (Exception ignored) { /* franja mal formada: se omite */ }
            }
        }
        return franjas.get(0);
    }

    // ---- utilidades de agenda
    private static final String[] CODIGOS = {"LUN", "MAR", "MIE", "JUE", "VIE", "SAB", "DOM"};
    private static final String[] NOMBRES = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};

    static String codigoDia(java.time.DayOfWeek d) { return CODIGOS[d.getValue() - 1]; }
    static String nombreDia(java.time.DayOfWeek d) { return NOMBRES[d.getValue() - 1]; }

    static Set<String> diasDe(Clase c) {
        Set<String> r = new java.util.LinkedHashSet<>();
        if (c.getDias() == null) return r;
        for (String d : c.getDias().split(",")) {
            String t = d.trim().toUpperCase();
            if (!t.isEmpty()) r.add(t);
        }
        return r;
    }

    static List<String> franjasDe(Clase c) {
        List<String> r = new ArrayList<>();
        if (c.getHoras() == null) return r;
        for (String h : c.getHoras().split(",")) {
            String t = h.trim();
            if (!t.isEmpty()) r.add(t);
        }
        return r;
    }

    private static String nombresDias(Set<String> codigos) {
        List<String> nombres = new ArrayList<>();
        for (int i = 0; i < CODIGOS.length; i++) if (codigos.contains(CODIGOS[i])) nombres.add(NOMBRES[i]);
        return String.join(", ", nombres);
    }

    public Asistencia actualizar(Integer id, Asistencia asistencia) {
        AuthContext.requireAdmin();
        asistencia.setIdAsistencia(id);
        return repository.save(asistencia);
    }

    public void eliminar(Integer id) {
        AuthContext.requireAdmin();
        repository.deleteById(id);
    }

    // ------------------------------------------------------------------ auxiliares

    /** Membresía activa del cliente que cubre la fecha indicada. */
    public Optional<Inscripcion> inscripcionVigente(Cliente cliente, LocalDate fecha) {
        if (cliente == null || cliente.getIdCliente() == null) return Optional.empty();
        return inscripcionRepository.findByClienteIdCliente(cliente.getIdCliente()).stream()
                .filter(i -> "ACTIVA".equalsIgnoreCase(i.getEstado()))
                .filter(i -> i.getFechaInicio() == null || !fecha.isBefore(i.getFechaInicio()))
                .filter(i -> i.getFechaFin() == null || !fecha.isAfter(i.getFechaFin()))
                .findFirst();
    }

    private Cliente buscarClientePorCodigo(String codigo) {
        String limpio = codigo == null ? "" : codigo.trim();
        if (limpio.regionMatches(true, 0, "APEXFIT:", 0, 8)) limpio = limpio.substring(8).trim();
        if (limpio.isEmpty()) throw new IllegalArgumentException("Código vacío");
        Optional<Cliente> porToken = clienteRepository.findByQrToken(limpio);
        if (porToken.isPresent()) return porToken.get();
        return clienteRepository.findFirstByCedula(limpio)
                .orElseThrow(() -> new IllegalArgumentException("Código no reconocido: no corresponde a ningún cliente"));
    }

    /** Avisa al cliente, al entrenador de la clase y (si no la registró un admin) a los administradores. */
    private void notificarInscripcionAClase(Asistencia a) {
        try {
            if (a == null || a.getClase() == null || a.getCliente() == null) return;
            String clase = a.getClase().getNombre();
            String horario = a.getClase().getHorario() == null ? "" : " (" + a.getClase().getHorario() + ")";
            String cliente = a.getCliente().getNombre() + " " + a.getCliente().getApellido();
            String fecha = String.valueOf(a.getFechaAsistencia());

            notificaciones.notificarPorAuthUserId(a.getCliente().getAuthUserId(), "CLASE", "Inscripción a clase",
                    "Quedaste inscrito en " + clase + horario + " para el " + fecha + ".");
            if (a.getClase().getEntrenador() != null) {
                notificaciones.notificarPorAuthUserId(a.getClase().getEntrenador().getAuthUserId(), "CLASE",
                        "Nuevo alumno en tu clase",
                        cliente + " se inscribió en " + clase + horario + " para el " + fecha + ".");
            }
            if (!AuthContext.isAdmin()) {
                notificaciones.notificarAdmins("CLASE", "Nueva inscripción a clase",
                        cliente + " se inscribió en " + clase + horario + " para el " + fecha + ".");
            }
        } catch (Exception ignored) {
            // La notificación nunca debe romper el registro de asistencia.
        }
    }
}
