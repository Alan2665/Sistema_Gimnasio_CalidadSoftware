package org.example.modules.seguimiento.service;

import org.example.common.security.AuthContext;
import org.example.common.security.IdentityService;
import org.example.modules.asistencia.entity.Asistencia;
import org.example.modules.asistencia.repository.AsistenciaRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.example.modules.seguimiento.dto.AlumnoDTO;
import org.example.modules.seguimiento.dto.SeguimientoRequest;
import org.example.modules.seguimiento.entity.Seguimiento;
import org.example.modules.seguimiento.repository.SeguimientoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Seguimiento físico: ADMIN y ENTRENADOR registran mediciones; el CLIENTE solo consulta las suyas.
 */
@Service
public class SeguimientoService {

    private final SeguimientoRepository repository;
    private final ClienteRepository clienteRepository;
    private final IdentityService identity;
    private final NotificacionService notificaciones;
    private final AsistenciaRepository asistenciaRepository;

    public SeguimientoService(SeguimientoRepository repository,
                              ClienteRepository clienteRepository,
                              IdentityService identity,
                              NotificacionService notificaciones,
                              AsistenciaRepository asistenciaRepository) {
        this.repository = repository;
        this.clienteRepository = clienteRepository;
        this.identity = identity;
        this.notificaciones = notificaciones;
        this.asistenciaRepository = asistenciaRepository;
    }

    public List<AlumnoDTO> alumnos() {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        if (AuthContext.isEntrenador()) {
            // Solo los clientes inscritos (alguna vez) en clases de este entrenador, sin repetir.
            Map<Integer, AlumnoDTO> unicos = new LinkedHashMap<>();
            for (Asistencia a : asistenciaRepository.findByClaseEntrenadorAuthUserId(identity.authUserId())) {
                Cliente c = a.getCliente();
                if (c != null && !Boolean.FALSE.equals(c.getEstado())) {
                    unicos.putIfAbsent(c.getIdCliente(), new AlumnoDTO(c.getIdCliente(), c.getNombre(), c.getApellido(), c.getCedula()));
                }
            }
            return new ArrayList<>(unicos.values());
        }
        return clienteRepository.findAll().stream()
                .filter(c -> !Boolean.FALSE.equals(c.getEstado()))
                .map(c -> new AlumnoDTO(c.getIdCliente(), c.getNombre(), c.getApellido(), c.getCedula()))
                .toList();
    }

    public List<Seguimiento> listar(Integer clienteId) {
        if (AuthContext.isCliente()) {
            // El cliente solo ve el suyo, ignorando el parámetro recibido.
            Cliente propio = identity.clienteActualObligatorio();
            return repository.findByIdClienteOrderByFechaAscIdSeguimientoAsc(propio.getIdCliente());
        }
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        if (clienteId == null) throw new IllegalArgumentException("Debes indicar el cliente");
        validarAlumnoPropio(clienteId);
        return repository.findByIdClienteOrderByFechaAscIdSeguimientoAsc(clienteId);
    }

    public Seguimiento registrar(SeguimientoRequest req) {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        if (req == null || req.getClienteId() == null) throw new IllegalArgumentException("Debes seleccionar un cliente");
        Cliente cliente = clienteRepository.findById(req.getClienteId())
                .orElseThrow(() -> new IllegalArgumentException("El cliente seleccionado no existe"));
        validarAlumnoPropio(cliente.getIdCliente());

        validarRango("Peso (kg)", req.getPesoKg(), 20, 400, true);
        validarRango("Cintura (cm)", req.getCinturaCm(), 30, 250, false);
        validarRango("Pecho (cm)", req.getPechoCm(), 30, 250, false);
        validarRango("Cadera (cm)", req.getCaderaCm(), 30, 250, false);
        validarRango("Brazo (cm)", req.getBrazoCm(), 10, 100, false);

        LocalDate fecha = req.getFecha() == null ? LocalDate.now() : req.getFecha();
        if (fecha.isAfter(LocalDate.now())) throw new IllegalArgumentException("La fecha no puede ser futura");

        Seguimiento s = new Seguimiento();
        s.setIdCliente(cliente.getIdCliente());
        s.setFecha(fecha);
        s.setPesoKg(req.getPesoKg());
        s.setCinturaCm(req.getCinturaCm());
        s.setPechoCm(req.getPechoCm());
        s.setCaderaCm(req.getCaderaCm());
        s.setBrazoCm(req.getBrazoCm());
        String notas = req.getNotas() == null ? "" : req.getNotas().trim();
        s.setNotas(notas.length() > 500 ? notas.substring(0, 500) : notas);
        s.setRegistradoPor(AuthContext.username());
        Seguimiento guardado = repository.save(s);

        notificaciones.notificarPorAuthUserId(cliente.getAuthUserId(), "SEGUIMIENTO", "Nueva medición registrada",
                "Tu entrenador registró una medición: peso " + req.getPesoKg() + " kg (" + fecha + ").");
        return guardado;
    }

    public void eliminar(Integer id) {
        AuthContext.requireAnyRole("ADMIN", "ENTRENADOR");
        Seguimiento s = repository.findById(id).orElse(null);
        if (s == null) return;
        // El entrenador solo borra lo que él mismo registró.
        if (!AuthContext.isAdmin() && !AuthContext.username().equals(s.getRegistradoPor())) {
            throw new SecurityException("Solo puedes eliminar las mediciones que tú registraste");
        }
        repository.deleteById(id);
    }

    /** El entrenador solo puede ver/registrar seguimiento de clientes inscritos en sus clases. */
    private void validarAlumnoPropio(Integer clienteId) {
        if (!AuthContext.isEntrenador()) return;
        if (!asistenciaRepository.existsByClienteIdClienteAndClaseEntrenadorAuthUserId(clienteId, identity.authUserId())) {
            throw new SecurityException("Este cliente no está inscrito en ninguna de tus clases");
        }
    }

    private void validarRango(String campo, BigDecimal valor, int min, int max, boolean obligatorio) {
        if (valor == null) {
            if (obligatorio) throw new IllegalArgumentException(campo + " es obligatorio");
            return;
        }
        if (valor.compareTo(BigDecimal.valueOf(min)) < 0 || valor.compareTo(BigDecimal.valueOf(max)) > 0) {
            throw new IllegalArgumentException(campo + " debe estar entre " + min + " y " + max);
        }
    }
}
