package org.example.modules.auth.service;

import org.example.modules.auth.dto.PerfilDTO;
import org.example.modules.auth.entity.AuthUser;
import org.example.modules.auth.repository.AuthUserRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.entrenador.entity.Entrenador;
import org.example.modules.entrenador.repository.EntrenadorRepository;
import org.example.modules.notificacion.service.NotificacionService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;
import java.util.regex.Pattern;

/** Gestión de la cuenta del usuario autenticado: cambio de clave y perfil (teléfono / correo / QR). */
@Service
public class CuentaService {

    private static final Pattern CORREO = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    private static final Pattern TELEFONO = Pattern.compile("^[0-9+()\\-\\s]{7,20}$");

    private final AuthUserRepository authUserRepository;
    private final ClienteRepository clienteRepository;
    private final EntrenadorRepository entrenadorRepository;
    private final PasswordEncoder passwordEncoder;
    private final NotificacionService notificaciones;

    public CuentaService(AuthUserRepository authUserRepository,
                         ClienteRepository clienteRepository,
                         EntrenadorRepository entrenadorRepository,
                         PasswordEncoder passwordEncoder,
                         NotificacionService notificaciones) {
        this.authUserRepository = authUserRepository;
        this.clienteRepository = clienteRepository;
        this.entrenadorRepository = entrenadorRepository;
        this.passwordEncoder = passwordEncoder;
        this.notificaciones = notificaciones;
    }

    @Transactional
    public void cambiarClave(String username, String claveActual, String nuevaClave) {
        AuthUser user = authUserRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado."));
        if (!passwordEncoder.matches(claveActual, user.getPassword())) {
            throw new IllegalArgumentException("La contraseña actual es incorrecta.");
        }
        if (nuevaClave == null || nuevaClave.length() < 6) {
            throw new IllegalArgumentException("La nueva contraseña debe tener al menos 6 caracteres.");
        }
        if (passwordEncoder.matches(nuevaClave, user.getPassword())) {
            throw new IllegalArgumentException("La nueva contraseña debe ser diferente a la actual.");
        }
        user.setPassword(passwordEncoder.encode(nuevaClave));
        authUserRepository.save(user);
        notificaciones.notificar(user.getUsername(), "SEGURIDAD", "Contraseña actualizada",
                "Tu contraseña fue cambiada correctamente. Si no fuiste tú, contacta al administrador.");
    }

    /** Perfil del usuario; para clientes genera (una sola vez) su código secreto de QR. */
    @Transactional
    public PerfilDTO obtenerPerfil(String username) {
        AuthUser user = authUserRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado."));
        PerfilDTO dto = new PerfilDTO();
        dto.setUsername(user.getUsername());
        dto.setRole(user.getRole());

        if ("CLIENTE".equals(user.getRole())) {
            clienteRepository.findByAuthUserId(user.getId()).ifPresent(c -> {
                if (c.getQrToken() == null || c.getQrToken().isBlank()) {
                    c.setQrToken(UUID.randomUUID().toString().replace("-", ""));
                    clienteRepository.save(c);
                }
                dto.setNombre(c.getNombre());
                dto.setApellido(c.getApellido());
                dto.setCedula(c.getCedula());
                dto.setTelefono(c.getTelefono());
                dto.setCorreo(c.getCorreo());
                dto.setQrCodigo("APEXFIT:" + c.getQrToken());
            });
        } else if ("ENTRENADOR".equals(user.getRole())) {
            entrenadorRepository.findByAuthUserId(user.getId()).ifPresent(e -> {
                dto.setNombre(e.getNombre());
                dto.setApellido(e.getApellido());
                dto.setCedula(e.getCedula());
                dto.setTelefono(e.getTelefono());
                dto.setCorreo(e.getCorreo());
            });
        }
        return dto;
    }

    @Transactional
    public PerfilDTO actualizarPerfil(String username, String telefono, String correo) {
        AuthUser user = authUserRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado."));
        String tel = telefono == null ? "" : telefono.trim();
        String mail = correo == null ? "" : correo.trim();
        if (!tel.isEmpty() && !TELEFONO.matcher(tel).matches()) {
            throw new IllegalArgumentException("El teléfono no es válido.");
        }
        if (!mail.isEmpty() && !CORREO.matcher(mail).matches()) {
            throw new IllegalArgumentException("El correo no es válido.");
        }

        if ("CLIENTE".equals(user.getRole())) {
            Cliente c = clienteRepository.findByAuthUserId(user.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Tu usuario no está vinculado a un cliente."));
            c.setTelefono(tel);
            c.setCorreo(mail);
            clienteRepository.save(c);
        } else if ("ENTRENADOR".equals(user.getRole())) {
            Entrenador e = entrenadorRepository.findByAuthUserId(user.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Tu usuario no está vinculado a un entrenador."));
            e.setTelefono(tel);
            e.setCorreo(mail);
            entrenadorRepository.save(e);
        } else {
            throw new IllegalArgumentException("Este tipo de cuenta no tiene perfil editable.");
        }
        return obtenerPerfil(username);
    }
}
