package org.example.modules.clase.service;

import org.example.common.security.AuthContext;
import org.example.modules.auth.repository.AuthUserRepository;
import org.example.modules.clase.entity.Clase;
import org.example.modules.clase.repository.ClaseRepository;
import org.springframework.stereotype.Service;
import org.example.exception.BusinessException;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Servicio de clases/salas. Admin ve todo; entrenador ve solo sus clases. */
@Service
public class ClaseService {

    private final ClaseRepository repository;
    private final AuthUserRepository authUserRepository;

    public ClaseService(ClaseRepository repository, AuthUserRepository authUserRepository) {
        this.repository = repository;
        this.authUserRepository = authUserRepository;
    }

    public List<Clase> listar() {
        if (AuthContext.isEntrenador()) {
            Long authUserId = authUserRepository.findByUsername(AuthContext.username()).map(u -> u.getId()).orElse(-1L);
            return repository.findByEntrenadorAuthUserId(authUserId);
        }
        return repository.findAll();
    }

    public Clase buscarPorId(Integer id) { return repository.findById(id).orElse(null); }
    public Clase guardar(Clase clase) {
        AuthContext.requireAdmin();
        normalizarAgenda(clase);
        return repository.save(clase);
    }

    public Clase actualizar(Integer id, Clase clase) {
        AuthContext.requireAdmin();
        normalizarAgenda(clase);
        clase.setIdClase(id);
        return repository.save(clase);
    }

    public void eliminar(Integer id) {
        AuthContext.requireAdmin();
        repository.deleteById(id);
    }

    // ------------------------------------------------------------------ agenda (días + horas)

    private static final String[] CODIGOS = {"LUN", "MAR", "MIE", "JUE", "VIE", "SAB", "DOM"};
    private static final String[] NOMBRES = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    private static final Pattern FRANJA = Pattern.compile("^([01]\\d|2[0-3]):[0-5]\\d-([01]\\d|2[0-3]):[0-5]\\d$");

    /** Valida días/horas enviados desde el formulario y regenera el texto legible del horario. */
    void normalizarAgenda(Clase clase) {
        Set<String> dias = new LinkedHashSet<>();
        if (clase.getDias() != null) {
            for (String d : clase.getDias().split(",")) {
                String t = d.trim().toUpperCase();
                if (t.isEmpty()) continue;
                if (indiceDia(t) < 0) throw new BusinessException("Día no válido: " + d);
                dias.add(t);
            }
        }
        List<String> franjas = new ArrayList<>();
        if (clase.getHoras() != null) {
            for (String h : clase.getHoras().split(",")) {
                String t = h.trim();
                if (t.isEmpty()) continue;
                if (!FRANJA.matcher(t).matches()) throw new BusinessException("Horario no válido: " + h + " (use HH:mm-HH:mm)");
                String[] p = t.split("-");
                if (p[0].compareTo(p[1]) >= 0) throw new BusinessException("La hora de fin debe ser posterior a la de inicio: " + t);
                if (!franjas.contains(t)) franjas.add(t);
            }
        }
        // Orden estable: días de lunes a domingo, franjas por hora de inicio
        List<String> diasOrdenados = new ArrayList<>();
        for (String c : CODIGOS) if (dias.contains(c)) diasOrdenados.add(c);
        franjas.sort(String::compareTo);

        clase.setDias(String.join(",", diasOrdenados));
        clase.setHoras(String.join(",", franjas));
        if (!diasOrdenados.isEmpty() || !franjas.isEmpty()) {
            clase.setHorario(textoHorario(diasOrdenados, franjas));
        }
    }

    /** Ej.: "Lunes, Miércoles y Sábado · 08:00-09:00, 18:00-19:00". */
    static String textoHorario(List<String> codigosDias, List<String> franjas) {
        List<String> nombres = new ArrayList<>();
        for (String c : codigosDias) nombres.add(NOMBRES[indiceDia(c)]);
        String dias = nombres.isEmpty() ? "" : nombres.size() == 1 ? nombres.get(0)
                : String.join(", ", nombres.subList(0, nombres.size() - 1)) + " y " + nombres.get(nombres.size() - 1);
        String horas = String.join(", ", franjas);
        if (dias.isEmpty()) return horas;
        return horas.isEmpty() ? dias : dias + " · " + horas;
    }

    private static int indiceDia(String codigo) {
        for (int i = 0; i < CODIGOS.length; i++) if (CODIGOS[i].equals(codigo)) return i;
        return -1;
    }

    /**
     * Para clases antiguas con horario en texto libre ("Lunes y Miércoles 19:00 - 20:00"):
     * deduce los días y las franjas. Devuelve true si cambió algo.
     */
    public static boolean completarAgendaDesdeTexto(Clase clase) {
        boolean tieneDias = clase.getDias() != null && !clase.getDias().isBlank();
        boolean tieneHoras = clase.getHoras() != null && !clase.getHoras().isBlank();
        if ((tieneDias && tieneHoras) || clase.getHorario() == null) return false;

        String texto = Normalizer.normalize(clase.getHorario(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase();
        boolean cambio = false;

        if (!tieneDias) {
            Set<Integer> idx = new LinkedHashSet<>();
            String[] nombresPlano = {"lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"};
            Matcher rango = Pattern.compile("([a-z]+)\\s+a\\s+([a-z]+)").matcher(texto);
            while (rango.find()) {
                int a = indice(nombresPlano, rango.group(1)), b = indice(nombresPlano, rango.group(2));
                if (a >= 0 && b >= 0) { for (int i = a; ; i = (i + 1) % 7) { idx.add(i); if (i == b) break; } }
            }
            for (int i = 0; i < nombresPlano.length; i++) if (texto.contains(nombresPlano[i])) idx.add(i);
            if (!idx.isEmpty()) {
                List<String> codigos = new ArrayList<>();
                for (int i = 0; i < CODIGOS.length; i++) if (idx.contains(i)) codigos.add(CODIGOS[i]);
                clase.setDias(String.join(",", codigos));
                cambio = true;
            }
        }
        if (!tieneHoras) {
            List<String> franjas = new ArrayList<>();
            Matcher m = Pattern.compile("(\\d{1,2}):(\\d{2})\\s*(?:-|a)\\s*(\\d{1,2}):(\\d{2})").matcher(texto);
            while (m.find()) {
                String f = String.format("%02d:%s-%02d:%s", Integer.parseInt(m.group(1)), m.group(2), Integer.parseInt(m.group(3)), m.group(4));
                if (FRANJA.matcher(f).matches() && f.substring(0, 5).compareTo(f.substring(6)) < 0 && !franjas.contains(f)) franjas.add(f);
            }
            if (!franjas.isEmpty()) {
                clase.setHoras(String.join(",", franjas));
                cambio = true;
            }
        }
        return cambio;
    }

    private static int indice(String[] arr, String valor) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(valor)) return i;
        return -1;
    }
}
