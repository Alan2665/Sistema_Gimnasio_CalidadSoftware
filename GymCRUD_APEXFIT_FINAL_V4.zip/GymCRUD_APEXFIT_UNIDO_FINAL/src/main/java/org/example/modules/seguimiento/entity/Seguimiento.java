package org.example.modules.seguimiento.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Medición de progreso físico de un cliente, registrada por su entrenador o por el administrador. */
@Entity
@Table(name = "seguimiento")
public class Seguimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_seguimiento")
    private Integer idSeguimiento;

    @Column(name = "id_cliente", nullable = false)
    private Integer idCliente;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(name = "peso_kg", precision = 6, scale = 2)
    private BigDecimal pesoKg;

    @Column(name = "cintura_cm", precision = 6, scale = 1)
    private BigDecimal cinturaCm;

    @Column(name = "pecho_cm", precision = 6, scale = 1)
    private BigDecimal pechoCm;

    @Column(name = "cadera_cm", precision = 6, scale = 1)
    private BigDecimal caderaCm;

    @Column(name = "brazo_cm", precision = 6, scale = 1)
    private BigDecimal brazoCm;

    @Column(length = 500)
    private String notas;

    /** Username de quien registró la medición. */
    @Column(name = "registrado_por", length = 80)
    private String registradoPor;

    public Integer getIdSeguimiento() { return idSeguimiento; }
    public void setIdSeguimiento(Integer idSeguimiento) { this.idSeguimiento = idSeguimiento; }
    public Integer getIdCliente() { return idCliente; }
    public void setIdCliente(Integer idCliente) { this.idCliente = idCliente; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public BigDecimal getPesoKg() { return pesoKg; }
    public void setPesoKg(BigDecimal pesoKg) { this.pesoKg = pesoKg; }
    public BigDecimal getCinturaCm() { return cinturaCm; }
    public void setCinturaCm(BigDecimal cinturaCm) { this.cinturaCm = cinturaCm; }
    public BigDecimal getPechoCm() { return pechoCm; }
    public void setPechoCm(BigDecimal pechoCm) { this.pechoCm = pechoCm; }
    public BigDecimal getCaderaCm() { return caderaCm; }
    public void setCaderaCm(BigDecimal caderaCm) { this.caderaCm = caderaCm; }
    public BigDecimal getBrazoCm() { return brazoCm; }
    public void setBrazoCm(BigDecimal brazoCm) { this.brazoCm = brazoCm; }
    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }
    public String getRegistradoPor() { return registradoPor; }
    public void setRegistradoPor(String registradoPor) { this.registradoPor = registradoPor; }
}
