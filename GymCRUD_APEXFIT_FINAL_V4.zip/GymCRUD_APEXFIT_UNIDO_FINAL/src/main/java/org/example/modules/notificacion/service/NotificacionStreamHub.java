package org.example.modules.notificacion.service;

import org.example.modules.notificacion.entity.Notificacion;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Conexiones SSE abiertas por usuario para enviar notificaciones en tiempo real. */
@Component
public class NotificacionStreamHub {

    private static final long TIMEOUT_MS = 30 * 60 * 1000L;

    private final Map<String, List<SseEmitter>> conexiones = new ConcurrentHashMap<>();

    public SseEmitter suscribir(String username) {
        SseEmitter emitter = new SseEmitter(TIMEOUT_MS);
        List<SseEmitter> lista = conexiones.computeIfAbsent(username, k -> new CopyOnWriteArrayList<>());
        lista.add(emitter);

        Runnable limpiar = () -> lista.remove(emitter);
        emitter.onCompletion(limpiar);
        emitter.onTimeout(limpiar);
        emitter.onError(e -> limpiar.run());

        try {
            emitter.send(SseEmitter.event().name("conectado").data("ok"));
        } catch (IOException e) {
            limpiar.run();
        }
        return emitter;
    }

    /** Envía la notificación a todas las pestañas abiertas del usuario. */
    public void publicar(String username, Notificacion notificacion) {
        List<SseEmitter> lista = conexiones.get(username);
        if (lista == null) return;
        for (SseEmitter emitter : lista) {
            try {
                emitter.send(SseEmitter.event()
                        .name("notificacion")
                        .data(notificacion, MediaType.APPLICATION_JSON));
            } catch (Exception e) {
                lista.remove(emitter);
            }
        }
    }
}
