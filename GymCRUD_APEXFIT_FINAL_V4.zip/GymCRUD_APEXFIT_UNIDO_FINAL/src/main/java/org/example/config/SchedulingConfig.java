package org.example.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Habilita las tareas programadas (alertas diarias). */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}
