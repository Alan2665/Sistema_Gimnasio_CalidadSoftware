package org.example.common.security;

import org.example.modules.auth.entity.AuthUser;
import org.example.modules.auth.repository.AuthUserRepository;
import org.example.modules.cliente.entity.Cliente;
import org.example.modules.cliente.repository.ClienteRepository;
import org.example.modules.entrenador.entity.Entrenador;
import org.example.modules.entrenador.repository.EntrenadorRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

/** Resuelve quién es la persona (cliente / entrenador) detrás del usuario autenticado. */
@Service
public class IdentityService {

    private final AuthUserRepository authUserRepository;
    private final ClienteRepository clienteRepository;
    private final EntrenadorRepository entrenadorRepository;

    public IdentityService(AuthUserRepository authUserRepository,
                           ClienteRepository clienteRepository,
                           EntrenadorRepository entrenadorRepository) {
        this.authUserRepository = authUserRepository;
        this.clienteRepository = clienteRepository;
        this.entrenadorRepository = entrenadorRepository;
    }

    /** Id del usuario autenticado o -1 si no existe. */
    public Long authUserId() {
        String username = AuthContext.username();
        if (username == null) return -1L;
        return authUserRepository.findByUsername(username).map(AuthUser::getId).orElse(-1L);
    }

    public Optional<Cliente> clienteActual() {
        return clienteRepository.findByAuthUserId(authUserId());
    }

    public Optional<Entrenador> entrenadorActual() {
        return entrenadorRepository.findByAuthUserId(authUserId());
    }

    public Cliente clienteActualObligatorio() {
        return clienteActual().orElseThrow(() ->
                new IllegalStateException("Tu usuario no está vinculado a un cliente. Contacta al administrador."));
    }
}
