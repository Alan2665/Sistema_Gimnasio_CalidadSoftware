import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toasts" aria-live="polite">
      <div class="toast" *ngFor="let m of toast.mensajes$ | async" [ngClass]="m.tipo" (click)="toast.cerrar(m.id)">
        <span class="ico">{{ m.tipo === 'error' ? '⚠️' : m.tipo === 'exito' ? '✅' : 'ℹ️' }}</span>
        <span class="txt">{{ m.texto }}</span>
      </div>
    </div>
  `,
  styles: `
    .toasts { position: fixed; top: 1rem; right: 1rem; z-index: 1000; display: flex; flex-direction: column; gap: 0.6rem; max-width: min(420px, calc(100vw - 2rem)); }
    .toast {
      display: flex; gap: 0.6rem; align-items: flex-start; padding: 0.8rem 1rem; border-radius: var(--radius-md);
      background: var(--bg-secondary); border: 1px solid var(--border-color-hover); box-shadow: 0 14px 34px rgba(0,0,0,0.35);
      cursor: pointer; animation: entrar 0.25s ease; font-size: 0.9rem;
    }
    .toast.error { border-color: var(--danger); }
    .toast.exito { border-color: var(--success); }
    .toast.info { border-color: var(--accent-primary); }
    .txt { overflow-wrap: anywhere; }
    @keyframes entrar { from { transform: translateX(16px); opacity: 0; } to { transform: none; opacity: 1; } }
  `
})
export class ToastComponent {
  constructor(public toast: ToastService) {}
}
