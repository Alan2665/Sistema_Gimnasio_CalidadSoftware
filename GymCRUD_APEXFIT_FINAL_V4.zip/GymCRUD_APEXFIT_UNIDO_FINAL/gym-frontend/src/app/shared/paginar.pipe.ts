import { Pipe, PipeTransform } from '@angular/core';

/** Devuelve solo los elementos de la página indicada (la página se ajusta al rango válido). */
@Pipe({ name: 'paginar', standalone: true })
export class PaginarPipe implements PipeTransform {
  transform<T>(lista: T[] | null | undefined, pagina: number, tam = 10): T[] {
    if (!lista) return [];
    const paginas = Math.max(1, Math.ceil(lista.length / tam));
    const p = Math.min(Math.max(1, pagina || 1), paginas);
    return lista.slice((p - 1) * tam, p * tam);
  }
}
