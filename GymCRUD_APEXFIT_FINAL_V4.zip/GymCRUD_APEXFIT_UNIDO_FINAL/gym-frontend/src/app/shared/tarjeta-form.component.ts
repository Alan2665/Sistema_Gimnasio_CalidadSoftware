import { Component, EventEmitter, OnDestroy, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface TarjetaEstado {
  valido: boolean;
  ultimos4: string;
  marca: string;
}

/**
 * Formulario de tarjeta de crédito/débito. Valida el número (algoritmo de Luhn), el vencimiento y el CVV.
 * Solo emite al padre los ÚLTIMOS 4 DÍGITOS y la marca: el número completo, el CVV y el titular
 * nunca salen de este componente ni se guardan.
 */
@Component({
  selector: 'app-tarjeta-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="tarjeta">
      <div class="vista" [ngClass]="marca">
        <div class="marca">{{ marcaTexto }}</div>
        <div class="num">{{ numeroVista }}</div>
        <div class="pie">
          <span>{{ titular || 'NOMBRE DEL TITULAR' | uppercase }}</span>
          <span>{{ vencimiento || 'MM/AA' }}</span>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Nombre del titular</label>
        <input class="form-control" name="tarjTitular" [(ngModel)]="titular" (ngModelChange)="validar()" autocomplete="cc-name" placeholder="Como aparece en la tarjeta">
        <small class="error" *ngIf="tocado && errores.titular">{{ errores.titular }}</small>
      </div>

      <div class="form-group">
        <label class="form-label">Número de tarjeta</label>
        <input class="form-control" name="tarjNumero" [ngModel]="numero" (ngModelChange)="alCambiarNumero($event)" inputmode="numeric" autocomplete="cc-number" placeholder="0000 0000 0000 0000" maxlength="23">
        <small class="error" *ngIf="tocado && errores.numero">{{ errores.numero }}</small>
      </div>

      <div class="fila">
        <div class="form-group">
          <label class="form-label">Vencimiento</label>
          <input class="form-control" name="tarjVence" [ngModel]="vencimiento" (ngModelChange)="alCambiarVencimiento($event)" inputmode="numeric" autocomplete="cc-exp" placeholder="MM/AA" maxlength="5">
          <small class="error" *ngIf="tocado && errores.vencimiento">{{ errores.vencimiento }}</small>
        </div>
        <div class="form-group">
          <label class="form-label">CVV</label>
          <input class="form-control" type="password" name="tarjCvv" [ngModel]="cvv" (ngModelChange)="alCambiarCvv($event)" inputmode="numeric" autocomplete="cc-csc" placeholder="•••" maxlength="4">
          <small class="error" *ngIf="tocado && errores.cvv">{{ errores.cvv }}</small>
        </div>
      </div>

      <small class="nota">🔒 Solo se guardan los últimos 4 dígitos como referencia. El número completo y el CVV no se almacenan.</small>
    </div>
  `,
  styles: `
    .tarjeta { display: flex; flex-direction: column; gap: .25rem; }
    .vista {
      border-radius: 16px; padding: 1rem 1.1rem; margin-bottom: .75rem; color: #fff; min-height: 128px;
      background: linear-gradient(135deg, #4f46e5, #9333ea); display: flex; flex-direction: column; justify-content: space-between;
      box-shadow: 0 10px 26px rgba(79, 70, 229, .35);
    }
    .vista.visa { background: linear-gradient(135deg, #1e3a8a, #2563eb); }
    .vista.mastercard { background: linear-gradient(135deg, #7f1d1d, #ea580c); }
    .vista.amex { background: linear-gradient(135deg, #065f46, #0891b2); }
    .marca { font-weight: 800; letter-spacing: 1px; font-size: .95rem; opacity: .95; }
    .num { font-size: 1.15rem; letter-spacing: 2px; font-variant-numeric: tabular-nums; }
    .pie { display: flex; justify-content: space-between; font-size: .72rem; opacity: .92; gap: .5rem; }
    .fila { display: grid; grid-template-columns: 1fr 1fr; gap: .75rem; }
    .error { color: var(--danger); font-size: .75rem; }
    .nota { color: var(--text-muted); font-size: .74rem; line-height: 1.35; }
  `
})
export class TarjetaFormComponent implements OnDestroy {
  @Output() cambio = new EventEmitter<TarjetaEstado>();

  titular = '';
  numero = '';
  vencimiento = '';
  cvv = '';
  tocado = false;
  errores: { titular?: string; numero?: string; vencimiento?: string; cvv?: string } = {};

  get digitos(): string { return this.numero.replace(/\D/g, ''); }

  get marca(): string {
    const d = this.digitos;
    if (/^4/.test(d)) return 'visa';
    if (/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/.test(d)) return 'mastercard';
    if (/^3[47]/.test(d)) return 'amex';
    return 'otra';
  }

  get marcaTexto(): string {
    return { visa: 'VISA', mastercard: 'MASTERCARD', amex: 'AMERICAN EXPRESS', otra: 'TARJETA' }[this.marca] || 'TARJETA';
  }

  get numeroVista(): string {
    const d = this.digitos.padEnd(16, '•');
    return (d.match(/.{1,4}/g) || []).join(' ');
  }

  alCambiarNumero(valor: string): void {
    const d = (valor || '').replace(/\D/g, '').slice(0, this.marca === 'amex' ? 15 : 16);
    this.numero = this.marca === 'amex'
      ? [d.slice(0, 4), d.slice(4, 10), d.slice(10)].filter(Boolean).join(' ')
      : (d.match(/.{1,4}/g) || []).join(' ');
    this.validar();
  }

  alCambiarVencimiento(valor: string): void {
    let d = (valor || '').replace(/\D/g, '').slice(0, 4);
    if (d.length >= 3) d = d.slice(0, 2) + '/' + d.slice(2);
    this.vencimiento = d;
    this.validar();
  }

  alCambiarCvv(valor: string): void {
    this.cvv = (valor || '').replace(/\D/g, '').slice(0, this.marca === 'amex' ? 4 : 3);
    this.validar();
  }

  validar(): void {
    const e: typeof this.errores = {};
    const d = this.digitos;

    if (this.titular.trim().length < 3) e.titular = 'Ingresa el nombre del titular.';
    if (!this.luhn(d) || d.length < 13) e.numero = 'Número de tarjeta no válido.';

    const m = /^(\d{2})\/(\d{2})$/.exec(this.vencimiento);
    if (!m || Number(m[1]) < 1 || Number(m[1]) > 12) {
      e.vencimiento = 'Usa el formato MM/AA.';
    } else {
      const hoy = new Date();
      const anio = 2000 + Number(m[2]);
      const mes = Number(m[1]);
      if (anio < hoy.getFullYear() || (anio === hoy.getFullYear() && mes < hoy.getMonth() + 1)) {
        e.vencimiento = 'La tarjeta está vencida.';
      }
    }

    const largoCvv = this.marca === 'amex' ? 4 : 3;
    if (this.cvv.length !== largoCvv) e.cvv = `El CVV tiene ${largoCvv} dígitos.`;

    this.errores = e;
    this.tocado = true;
    const valido = Object.keys(e).length === 0;
    this.cambio.emit({ valido, ultimos4: valido ? d.slice(-4) : '', marca: this.marcaTexto });
  }

  /** Algoritmo de Luhn: detecta números de tarjeta mal digitados. */
  private luhn(num: string): boolean {
    if (!/^\d+$/.test(num)) return false;
    let suma = 0;
    let doble = false;
    for (let i = num.length - 1; i >= 0; i--) {
      let n = Number(num[i]);
      if (doble) { n *= 2; if (n > 9) n -= 9; }
      suma += n;
      doble = !doble;
    }
    return suma % 10 === 0;
  }

  ngOnDestroy(): void {
    // Se borran los datos sensibles de memoria al cerrar el formulario
    this.numero = this.cvv = this.titular = this.vencimiento = '';
  }
}
