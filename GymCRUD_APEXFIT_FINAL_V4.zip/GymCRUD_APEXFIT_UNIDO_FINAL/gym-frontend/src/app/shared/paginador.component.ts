import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Controles de paginación para tablas. Uso: <app-paginador [total]="lista.length" [(pagina)]="pagina"></app-paginador> */
@Component({
  selector: 'app-paginador',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="paginador" *ngIf="total > tam">
      <span class="info">Mostrando {{ desde }}–{{ hasta }} de {{ total }}</span>
      <div class="botones">
        <button type="button" (click)="ir(paginaActual - 1)" [disabled]="paginaActual === 1" aria-label="Anterior">‹</button>
        <button type="button" *ngFor="let n of numeros" [class.activo]="n === paginaActual" (click)="ir(n)">{{ n }}</button>
        <button type="button" (click)="ir(paginaActual + 1)" [disabled]="paginaActual === totalPaginas" aria-label="Siguiente">›</button>
      </div>
    </div>
  `,
  styles: `
    .paginador { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; padding: 0.85rem 0.25rem 0; }
    .info { color: var(--text-muted); font-size: 0.82rem; }
    .botones { display: flex; gap: 0.35rem; }
    button {
      min-width: 2.1rem; height: 2.1rem; padding: 0 0.6rem; border-radius: var(--radius-sm, 8px);
      background: transparent; border: 1px solid var(--border-color-hover); color: var(--text-secondary);
      cursor: pointer; font-family: var(--font-sans); font-weight: 600;
    }
    button:hover:not(:disabled) { border-color: var(--accent-primary); color: var(--text-primary); }
    button.activo { background: var(--accent-gradient); border-color: transparent; color: #fff; }
    button:disabled { opacity: 0.35; cursor: default; }
  `
})
export class PaginadorComponent {
  @Input() total = 0;
  @Input() tam = 10;
  @Input() pagina = 1;
  @Output() paginaChange = new EventEmitter<number>();

  get totalPaginas(): number { return Math.max(1, Math.ceil(this.total / this.tam)); }
  get paginaActual(): number { return Math.min(Math.max(1, this.pagina || 1), this.totalPaginas); }
  get desde(): number { return this.total === 0 ? 0 : (this.paginaActual - 1) * this.tam + 1; }
  get hasta(): number { return Math.min(this.total, this.paginaActual * this.tam); }

  get numeros(): number[] {
    const total = this.totalPaginas;
    const ini = Math.max(1, Math.min(this.paginaActual - 2, total - 4));
    const fin = Math.min(total, ini + 4);
    const lista: number[] = [];
    for (let i = ini; i <= fin; i++) lista.push(i);
    return lista;
  }

  ir(n: number): void {
    const destino = Math.min(Math.max(1, n), this.totalPaginas);
    if (destino !== this.paginaActual) this.paginaChange.emit(destino);
  }
}
