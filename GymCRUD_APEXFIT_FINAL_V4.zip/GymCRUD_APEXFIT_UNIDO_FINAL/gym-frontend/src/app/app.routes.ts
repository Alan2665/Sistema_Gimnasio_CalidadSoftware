import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ClientesComponent } from './components/clientes/clientes.component';
import { EntrenadoresComponent } from './components/entrenadores/entrenadores.component';
import { MembresiasComponent } from './components/membresias/membresias.component';
import { InscripcionesComponent } from './components/inscripciones/inscripciones.component';
import { ClasesComponent } from './components/clases/clases.component';
import { AsistenciasComponent } from './components/asistencias/asistencias.component';
import { AsistenciaEntrenadoresComponent } from './components/asistencia-entrenadores/asistencia-entrenadores.component';
import { ProductosComponent } from './components/productos/productos.component';
import { TiendaComponent } from './components/tienda/tienda.component';
import { PagosComponent } from './components/pagos/pagos.component';
import { CuentaComponent } from './components/cuenta/cuenta.component';
import { LoginComponent } from './components/login/login.component';
import { CalendarioComponent } from './components/calendario/calendario.component';
import { ControlAccesoComponent } from './components/control-acceso/control-acceso.component';
import { ReportesComponent } from './components/reportes/reportes.component';
import { SeguimientoComponent } from './components/seguimiento/seguimiento.component';
import { RestablecerComponent } from './components/restablecer/restablecer.component';
import { authGuard, noClienteGuard, soloRoles } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'restablecer', component: RestablecerComponent },
  { path: 'dashboard', canActivate: [authGuard], component: DashboardComponent },
  { path: 'clientes', canActivate: [authGuard], component: ClientesComponent },
  { path: 'entrenadores', canActivate: [authGuard], component: EntrenadoresComponent },
  { path: 'membresias', canActivate: [authGuard], component: MembresiasComponent },
  { path: 'inscripciones', canActivate: [authGuard], component: InscripcionesComponent },
  { path: 'clases', canActivate: [authGuard], component: ClasesComponent },
  { path: 'asistencias', canActivate: [authGuard], component: AsistenciasComponent },
  { path: 'asistencias-entrenadores', canActivate: [authGuard], component: AsistenciaEntrenadoresComponent },
  { path: 'productos', canActivate: [authGuard, noClienteGuard], component: ProductosComponent },
  { path: 'tienda', canActivate: [authGuard], component: TiendaComponent },
  { path: 'pagos', canActivate: [authGuard], component: PagosComponent },
  { path: 'cuenta', canActivate: [authGuard], component: CuentaComponent },
  { path: 'calendario', canActivate: [authGuard], component: CalendarioComponent },
  { path: 'seguimiento', canActivate: [authGuard], component: SeguimientoComponent },
  { path: 'control-acceso', canActivate: [authGuard, soloRoles('ADMIN', 'ENTRENADOR')], component: ControlAccesoComponent },
  { path: 'reportes', canActivate: [authGuard, soloRoles('ADMIN')], component: ReportesComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];
