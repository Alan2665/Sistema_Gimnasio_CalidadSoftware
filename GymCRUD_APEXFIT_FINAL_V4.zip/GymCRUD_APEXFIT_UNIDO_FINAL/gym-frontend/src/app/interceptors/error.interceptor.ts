import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { ToastService } from '../services/toast.service';

/** Rutas que gestionan sus propios errores en pantalla o se consultan en segundo plano. */
const SILENCIADAS = ['/api/auth/', '/api/notificaciones', '/api/asistencias/qr'];

/** Muestra un aviso con el mensaje del servidor cuando una petición falla. */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const toast = inject(ToastService);
  const router = inject(Router);

  return next(req).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse && !SILENCIADAS.some(r => req.url.includes(r))) {
        const msgServidor = (err.error && typeof err.error === 'object' && 'message' in err.error)
          ? String((err.error as { message: unknown }).message) : '';

        if (err.status === 0) {
          toast.error('No se pudo conectar con el servidor. Verifica que el backend esté en ejecución.');
        } else if (err.status === 401) {
          toast.error('Tu sesión expiró. Inicia sesión nuevamente.');
          router.navigate(['/login']);
        } else if (err.status === 403) {
          toast.error(msgServidor || 'No tienes permiso para realizar esta acción.');
        } else if (err.status >= 500) {
          toast.error(msgServidor || 'Ocurrió un error en el servidor. Intenta nuevamente.');
        } else if (msgServidor) {
          toast.error(msgServidor);
        }
      }
      return throwError(() => err);
    })
  );
};
