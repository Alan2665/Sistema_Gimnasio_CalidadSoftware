import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface ToastMsg {
  id: number;
  tipo: 'error' | 'exito' | 'info';
  texto: string;
}

/** Avisos emergentes globales (errores del servidor, confirmaciones). */
@Injectable({ providedIn: 'root' })
export class ToastService {
  private contador = 0;
  readonly mensajes$ = new BehaviorSubject<ToastMsg[]>([]);

  error(texto: string): void { this.agregar('error', texto, 6500); }
  exito(texto: string): void { this.agregar('exito', texto, 4000); }
  info(texto: string): void { this.agregar('info', texto, 4000); }

  cerrar(id: number): void {
    this.mensajes$.next(this.mensajes$.value.filter(m => m.id !== id));
  }

  private agregar(tipo: ToastMsg['tipo'], texto: string, ms: number): void {
    // Evita apilar el mismo mensaje varias veces seguidas
    if (this.mensajes$.value.some(m => m.texto === texto)) return;
    const id = ++this.contador;
    this.mensajes$.next([...this.mensajes$.value, { id, tipo, texto }].slice(-4));
    setTimeout(() => this.cerrar(id), ms);
  }
}
