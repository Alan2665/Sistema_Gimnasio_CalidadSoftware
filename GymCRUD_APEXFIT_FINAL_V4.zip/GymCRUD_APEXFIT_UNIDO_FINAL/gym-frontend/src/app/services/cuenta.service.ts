import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Perfil } from '../models/gym.models';

const CUENTA_URL = 'http://localhost:8081/api/cuenta';

@Injectable({ providedIn: 'root' })
export class CuentaService {
  constructor(private http: HttpClient) {}

  perfil(): Observable<Perfil> {
    return this.http.get<Perfil>(`${CUENTA_URL}/perfil`);
  }

  actualizarPerfil(telefono: string, correo: string): Observable<Perfil> {
    return this.http.put<Perfil>(`${CUENTA_URL}/perfil`, { telefono, correo });
  }
}
