import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

/** Estado del menú lateral en pantallas pequeñas (abierto / cerrado). */
@Injectable({ providedIn: 'root' })
export class SidebarStateService {
  readonly abierto$ = new BehaviorSubject<boolean>(false);

  alternar(): void { this.abierto$.next(!this.abierto$.value); }
  cerrar(): void { if (this.abierto$.value) this.abierto$.next(false); }
}
