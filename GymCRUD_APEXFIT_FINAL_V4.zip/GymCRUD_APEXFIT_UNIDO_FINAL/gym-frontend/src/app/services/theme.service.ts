import { Injectable } from '@angular/core';

export type Tema = 'dark' | 'light';

/** Tema claro/oscuro persistido en el navegador. */
@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly clave = 'gym_theme';
  tema: Tema = 'dark';

  constructor() {
    let guardado: string | null = null;
    try { guardado = localStorage.getItem(this.clave); } catch { /* almacenamiento no disponible */ }
    this.aplicar(guardado === 'light' ? 'light' : 'dark');
  }

  alternar(): void {
    this.aplicar(this.tema === 'dark' ? 'light' : 'dark');
  }

  private aplicar(tema: Tema): void {
    this.tema = tema;
    document.documentElement.setAttribute('data-theme', tema);
    try { localStorage.setItem(this.clave, tema); } catch { /* ignorar */ }
  }
}
