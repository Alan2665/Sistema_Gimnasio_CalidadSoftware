import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Alumno, Seguimiento } from '../models/gym.models';

const URL = 'http://localhost:8081/api/seguimientos';

@Injectable({ providedIn: 'root' })
export class SeguimientoService {
  constructor(private http: HttpClient) {}

  alumnos(): Observable<Alumno[]> {
    return this.http.get<Alumno[]>(`${URL}/alumnos`);
  }

  listar(clienteId?: number): Observable<Seguimiento[]> {
    return clienteId === undefined
      ? this.http.get<Seguimiento[]>(URL)
      : this.http.get<Seguimiento[]>(URL, { params: { clienteId } });
  }

  registrar(data: Partial<Seguimiento> & { clienteId: number }): Observable<Seguimiento> {
    return this.http.post<Seguimiento>(URL, data);
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${URL}/${id}`);
  }
}
