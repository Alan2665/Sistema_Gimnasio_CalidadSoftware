export interface Cliente {
  idCliente?: number;
  cedula: string;
  nombre: string;
  apellido: string;
  telefono: string;
  correo: string;
  fechaRegistro?: string; // Format: YYYY-MM-DD
  estado: boolean;
  authUserId?: number;
  username?: string;
  password?: string;
}

export interface Entrenador {
  idEntrenador?: number;
  cedula: string;
  nombre: string;
  apellido: string;
  telefono: string;
  especialidad: string;
  correo?: string;
  authUserId?: number;
  username?: string;
  password?: string;
}

export interface Membresia {
  idMembresia?: number;
  nombre: string;
  descripcion: string;
  duracionDias: number;
  precio: number;
}

export interface Clase {
  idClase?: number;
  entrenador: Entrenador;
  nombre: string;
  descripcion: string;
  horario: string;
  /** Días en que se dicta: LUN,MAR,MIE,JUE,VIE,SAB,DOM (vacío = cualquier día) */
  dias?: string;
  /** Franjas disponibles HH:mm-HH:mm separadas por coma */
  horas?: string;
  aula?: string;
  cupoMaximo: number;
}

export interface Inscripcion {
  idInscripcion?: number;
  cliente: Cliente;
  membresia: Membresia;
  fechaInicio: string; // Format: YYYY-MM-DD
  fechaFin: string;    // Format: YYYY-MM-DD
  estado: string;      // Activa, Vencida, Cancelada, etc.
}

export interface Asistencia {
  idAsistencia?: number;
  cliente: Cliente;
  clase: Clase;
  fechaAsistencia: string; // Format: YYYY-MM-DD
  /** Franja horaria elegida (HH:mm-HH:mm) */
  franja?: string | null;
  presente?: boolean | null;
  horaIngreso?: string | null;
}

export interface AsistenciaEntrenador {
  idAsistenciaEntrenador?: number;
  entrenador: Entrenador;
  clase: Clase;
  fechaAsistencia: string;
  horaEntrada?: string;
  horaSalida?: string;
  tiempoMinutos?: number;
}

export type TipoPago = 'MEMBRESIA' | 'PRODUCTO';
export type MetodoPagoPOS = 'EFECTIVO' | 'TRANSFERENCIA' | 'TARJETA';

export interface Pago {
  idPago?: number;
  tipoPago?: TipoPago;
  inscripcion?: Inscripcion;
  venta?: Venta;
  monto: number;
  fechaPago: string;       // Format: YYYY-MM-DD
  metodoPago: string;      // Efectivo, Tarjeta, Transferencia, etc.
  estado: string;          // Completado, Pendiente, Reembolsado, etc.
  referenciaPago?: string | null; // ej. "Tarjeta •••• 1234"
}

export interface Producto {
  idProducto?: number;
  nombre: string;
  descripcion: string;
  precio: number;
  stock: number;
  imagen?: string | null;
}

export interface Venta {
  idVenta?: number;
  cliente: Cliente;
  fechaVenta: string;      // Format: YYYY-MM-DD
  total: number;
}

export interface DetalleVenta {
  idDetalle?: number;
  venta?: Venta;
  producto: Producto;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
}

export interface CupoClase {
  idClase: number;
  franja: string | null;
  ocupados: number;
  cupoMaximo: number | null;
}

export interface QrAsistenciaResponse {
  cliente: string;
  cedula: string;
  clase: string;
  fecha: string;
  hora: string;
  presentes: number;
  inscritos: number;
  mensaje: string;
}

export interface AsistenciaLista {
  idAsistencia: number;
  cliente: string;
  cedula: string;
  presente: boolean;
  horaIngreso: string | null;
  franja: string | null;
}

export interface Perfil {
  username: string;
  role: string;
  nombre?: string;
  apellido?: string;
  cedula?: string;
  telefono?: string;
  correo?: string;
  qrCodigo?: string;
}

export interface Seguimiento {
  idSeguimiento?: number;
  idCliente: number;
  fecha: string;
  pesoKg?: number | null;
  cinturaCm?: number | null;
  pechoCm?: number | null;
  caderaCm?: number | null;
  brazoCm?: number | null;
  notas?: string;
  registradoPor?: string;
}

export interface Alumno {
  idCliente: number;
  nombre: string;
  apellido: string;
  cedula: string;
}
