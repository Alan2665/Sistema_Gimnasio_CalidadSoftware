import { Asistencia } from '../models/gym.models';

export type EstadoAsistencia = 'ASISTIO' | 'NO_ASISTIO' | 'PENDIENTE';

export function hoyIso(): string {
  const d = new Date();
  const z = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

/**
 * Estado real de una inscripción a clase:
 *  - ASISTIO: se confirmó su ingreso (QR o toma de lista)
 *  - NO_ASISTIO: la fecha ya pasó y nunca ingresó
 *  - PENDIENTE: es hoy o una fecha futura y aún no ingresa
 */
export function estadoAsistencia(a: Pick<Asistencia, 'presente' | 'fechaAsistencia'>): EstadoAsistencia {
  if (a.presente) return 'ASISTIO';
  return a.fechaAsistencia < hoyIso() ? 'NO_ASISTIO' : 'PENDIENTE';
}

export const ETIQUETA_ESTADO: Record<EstadoAsistencia, string> = {
  ASISTIO: 'Asistió',
  NO_ASISTIO: 'No asistió',
  PENDIENTE: 'Pendiente'
};
