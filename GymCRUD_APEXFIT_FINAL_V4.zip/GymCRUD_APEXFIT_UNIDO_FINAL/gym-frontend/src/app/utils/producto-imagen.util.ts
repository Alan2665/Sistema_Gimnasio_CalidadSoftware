/**
 * Imagen de un producto: usa la que subió el administrador (campo "imagen") y, si no hay,
 * una ilustración por defecto según el nombre. Productos y Punto de Venta usan ESTA misma función,
 * por eso un cambio en Productos se refleja de inmediato en el Punto de Venta.
 */
export function imagenDeProducto(producto: { nombre?: string; imagen?: string | null } | null | undefined): string {
  if (producto?.imagen) return producto.imagen;
  const n = (producto?.nombre || '').toLowerCase();
  if (n.includes('whey') || n.includes('prote')) return 'assets/img/products/whey.svg';
  if (n.includes('gatorade') || n.includes('bebida') || n.includes('botella')) return 'assets/img/products/gatorade.svg';
  if (n.includes('toalla')) return 'assets/img/products/toalla.svg';
  if (n.includes('guante')) return 'assets/img/products/guantes.svg';
  if (n.includes('shaker')) return 'assets/img/products/shaker.svg';
  if (n.includes('creatina')) return 'assets/img/products/creatina.svg';
  return 'assets/img/products/default.svg';
}

/** Lee una imagen del equipo, la reduce (máx. 480 px) y la devuelve como data URL JPEG liviano. */
export function archivoAImagen(file: File, maxLado = 480, calidad = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('El archivo seleccionado no es una imagen.'));
      return;
    }
    const lector = new FileReader();
    lector.onerror = () => reject(new Error('No se pudo leer el archivo.'));
    lector.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('No se pudo procesar la imagen.'));
      img.onload = () => {
        const escala = Math.min(1, maxLado / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * escala));
        const h = Math.max(1, Math.round(img.height * escala));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) { reject(new Error('No se pudo procesar la imagen.')); return; }
        ctx.fillStyle = '#ffffff';          // fondo blanco para PNG con transparencia
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', calidad));
      };
      img.src = String(lector.result);
    };
    lector.readAsDataURL(file);
  });
}
