import { DetalleVenta, Pago } from '../models/gym.models';

function esc(valor: unknown): string {
  return String(valor ?? '').replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } as Record<string, string>
  )[c] || c);
}

function dinero(v: unknown): string {
  return '$' + Number(v ?? 0).toFixed(2);
}

export function esPagoProducto(p: Pago): boolean {
  return (p.tipoPago || 'MEMBRESIA') === 'PRODUCTO';
}

export function clienteDelPago(p: Pago): string {
  const c = p.inscripcion?.cliente || p.venta?.cliente;
  return c ? `${c.nombre} ${c.apellido}` : 'Cliente desconocido';
}

export function detallesDelPago(p: Pago, detalles: DetalleVenta[]): DetalleVenta[] {
  const id = p.venta?.idVenta;
  return id === undefined ? [] : detalles.filter(d => d.venta?.idVenta === id);
}

export function referenciaDelPago(p: Pago): string {
  return esPagoProducto(p)
    ? `Venta POS #${p.venta?.idVenta ?? 'N/A'}`
    : `Inscripción #${p.inscripcion?.idInscripcion ?? 'N/A'}`;
}

/** Construye el HTML imprimible del recibo de un pago (membresía o compra de productos). */
export function construirReciboHtml(p: Pago, detalles: DetalleVenta[]): string {
  const producto = esPagoProducto(p);
  const numero = 'R-' + String(p.idPago || 0).padStart(6, '0');

  const filas = producto
    ? detallesDelPago(p, detalles).map(d =>
        `<tr><td>${esc(d.producto?.nombre || 'Producto')}</td><td class="c">${esc(d.cantidad)}</td>` +
        `<td class="r">${dinero(d.precioUnitario)}</td><td class="r">${dinero(d.subtotal)}</td></tr>`).join('')
    : `<tr><td>${esc('Membresía: ' + (p.inscripcion?.membresia?.nombre || 'Plan'))}</td><td class="c">1</td>` +
      `<td class="r">${dinero(p.monto)}</td><td class="r">${dinero(p.monto)}</td></tr>`;

  const css = 'body{font-family:Arial,Helvetica,sans-serif;padding:30px;color:#111827}' +
    '.recibo{max-width:720px;margin:auto;border:1px solid #d1d5db;padding:30px;border-radius:12px}' +
    '.head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #6366f1;padding-bottom:14px;margin-bottom:18px}' +
    'h1{margin:0;font-size:28px;letter-spacing:-1px}h1 span{color:#6366f1}.sub{color:#6b7280;font-size:13px;margin-top:4px}' +
    '.num{text-align:right;font-size:13px;color:#374151}.num b{display:block;font-size:18px;color:#111827}' +
    '.info{display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:14px;margin-bottom:18px}' +
    'table{width:100%;border-collapse:collapse;font-size:14px}th{background:#f3f4f6;text-align:left;padding:8px;border-bottom:1px solid #d1d5db}' +
    'td{padding:8px;border-bottom:1px solid #e5e7eb}.c{text-align:center}.r{text-align:right}' +
    '.total{font-size:24px;font-weight:800;text-align:right;margin-top:20px}.foot{margin-top:26px;text-align:center;color:#6b7280;font-size:12px}' +
    '@media print{body{padding:0}.recibo{border:none}}';

  return `<html><head><meta charset="utf-8"><title>Recibo ${numero} - APEXFIT</title><style>${css}</style></head><body>` +
    `<div class="recibo"><div class="head"><div><h1>APEX<span>FIT</span></h1>` +
    `<div class="sub">Gimnasio · Recibo de ${producto ? 'compra de productos' : 'membresía'}</div></div>` +
    `<div class="num">Recibo N°<b>${numero}</b></div></div>` +
    `<div class="info"><div><b>Cliente:</b> ${esc(clienteDelPago(p))}</div><div><b>Fecha:</b> ${esc(p.fechaPago)}</div>` +
    `<div><b>Método de pago:</b> ${esc(p.metodoPago)}${p.referenciaPago ? ' (' + esc(p.referenciaPago) + ')' : ''}</div><div><b>Estado:</b> ${esc(p.estado)}</div>` +
    `<div><b>Referencia:</b> ${esc(referenciaDelPago(p))}</div></div>` +
    `<table><thead><tr><th>Descripción</th><th class="c">Cant.</th><th class="r">P. unitario</th><th class="r">Subtotal</th></tr></thead>` +
    `<tbody>${filas}</tbody></table><div class="total">Total: ${dinero(p.monto)}</div>` +
    `<div class="foot">¡Gracias por entrenar con APEXFIT!</div></div>` +
    `<script>window.onload=function(){window.print()}</script></body></html>`;
}

/** Abre el recibo en una ventana nueva y lanza el diálogo de impresión (permite "Guardar como PDF"). */
export function imprimirReciboPago(p: Pago, detalles: DetalleVenta[]): void {
  const w = window.open('', '_blank', 'width=800,height=700');
  if (!w) return;
  w.document.open();
  w.document.write(construirReciboHtml(p, detalles));
  w.document.close();
}
