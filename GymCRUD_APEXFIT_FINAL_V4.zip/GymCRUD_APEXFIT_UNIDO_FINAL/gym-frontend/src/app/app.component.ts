import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { NotificacionesComponent } from './components/notificaciones/notificaciones.component';
import { ToastComponent } from './shared/toast.component';
import { SidebarStateService } from './services/sidebar-state.service';
import { ThemeService } from './services/theme.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, SidebarComponent, NotificacionesComponent, ToastComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'gym-frontend';

  constructor(
    public router: Router,
    public sidebarState: SidebarStateService,
    private theme: ThemeService   // se inyecta para aplicar el tema guardado desde el arranque
  ) {}

  ngOnInit(): void {
    // En móvil, el menú se cierra al navegar
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => this.sidebarState.cerrar());
  }

  esLogin(): boolean {
    const url = this.router.url;
    return url.startsWith('/login') || url.startsWith('/restablecer');
  }
}
