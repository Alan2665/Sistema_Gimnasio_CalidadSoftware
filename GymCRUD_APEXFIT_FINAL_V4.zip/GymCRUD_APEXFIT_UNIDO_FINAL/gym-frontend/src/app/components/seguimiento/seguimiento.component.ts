import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { SeguimientoService } from '../../services/seguimiento.service';
import { ToastService } from '../../services/toast.service';
import { Alumno, Seguimiento } from '../../models/gym.models';
import { PaginarPipe } from '../../shared/paginar.pipe';
import { PaginadorComponent } from '../../shared/paginador.component';

type Metrica = 'pesoKg' | 'cinturaCm' | 'pechoCm' | 'caderaCm' | 'brazoCm';

interface PuntoGrafico { x: number; y: number; valor: number; fecha: string; }

const METRICAS: { clave: Metrica; nombre: string; unidad: string }[] = [
  { clave: 'pesoKg', nombre: 'Peso', unidad: 'kg' },
  { clave: 'cinturaCm', nombre: 'Cintura', unidad: 'cm' },
  { clave: 'pechoCm', nombre: 'Pecho', unidad: 'cm' },
  { clave: 'caderaCm', nombre: 'Cadera', unidad: 'cm' },
  { clave: 'brazoCm', nombre: 'Brazo', unidad: 'cm' }
];

/** Seguimiento físico: el entrenador/admin registra mediciones por alumno; el cliente ve su propia evolución. */
@Component({
  selector: 'app-seguimiento',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginarPipe, PaginadorComponent],
  template: `
    <div class="animate-fade-in">
      <div style="margin-bottom: 1.5rem;">
        <h1 style="font-size: 2.25rem;">{{ esCliente ? 'Mi progreso' : 'Seguimiento de alumnos' }}</h1>
        <p style="color: var(--text-secondary);">
          {{ esCliente ? 'Evolución de tus mediciones registradas por tu entrenador' : 'Registra peso y medidas y observa la evolución de cada alumno' }}
        </p>
      </div>

      <div class="glass-card" *ngIf="!esCliente" style="margin-bottom:1.5rem;">
        <div class="form-group" style="margin:0;">
          <label class="form-label">Alumno</label>
          <select class="form-control" [(ngModel)]="alumnoId" (ngModelChange)="cargar()" name="alumno">
            <option [ngValue]="null" disabled>-- Seleccionar alumno --</option>
            <option *ngFor="let a of alumnos" [ngValue]="a.idCliente">{{ a.nombre }} {{ a.apellido }} ({{ a.cedula }})</option>
          </select>
        </div>
      </div>

      <div class="cols" *ngIf="esCliente || alumnoId">
        <!-- GRÁFICO -->
        <div class="glass-card">
          <div class="cab">
            <h2>Evolución</h2>
            <select class="form-control" style="max-width: 170px;" [(ngModel)]="metrica" (ngModelChange)="construir()" name="metrica">
              <option *ngFor="let m of metricas" [ngValue]="m.clave">{{ m.nombre }} ({{ m.unidad }})</option>
            </select>
          </div>

          <ng-container *ngIf="puntos.length >= 2; else pocos">
            <svg viewBox="0 0 560 270" style="width:100%; height:auto;" role="img" aria-label="Gráfico de evolución">
              <g *ngFor="let t of ticks">
                <line x1="46" [attr.y1]="t.y" x2="545" [attr.y2]="t.y" style="stroke: var(--border-color)" stroke-width="1"/>
                <text x="40" [attr.y]="t.y + 4" text-anchor="end" style="fill: var(--text-muted)" font-size="11">{{ t.valor }}</text>
              </g>
              <polyline [attr.points]="linea" fill="none" stroke="#6366f1" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>
              <g *ngFor="let p of puntos">
                <circle [attr.cx]="p.x" [attr.cy]="p.y" r="5" fill="#a855f7" stroke="#fff" stroke-width="1.5"><title>{{ p.fecha }}: {{ p.valor }} {{ unidad }}</title></circle>
              </g>
              <text [attr.x]="puntos[0].x" y="262" text-anchor="start" style="fill: var(--text-secondary)" font-size="11">{{ puntos[0].fecha }}</text>
              <text [attr.x]="puntos[puntos.length - 1].x" y="262" text-anchor="end" style="fill: var(--text-secondary)" font-size="11">{{ puntos[puntos.length - 1].fecha }}</text>
            </svg>
            <div class="resumen">
              <span>Inicio: <b>{{ puntos[0].valor }} {{ unidad }}</b></span>
              <span>Actual: <b>{{ puntos[puntos.length - 1].valor }} {{ unidad }}</b></span>
              <span [class.baja]="cambio < 0" [class.sube]="cambio > 0">Cambio: <b>{{ cambio > 0 ? '+' : '' }}{{ cambio }} {{ unidad }}</b></span>
            </div>
          </ng-container>
          <ng-template #pocos>
            <p style="color: var(--text-muted); padding: 2rem 0; text-align:center;">
              Se necesitan al menos 2 mediciones de {{ nombreMetrica.toLowerCase() }} para dibujar la evolución.
            </p>
          </ng-template>
        </div>

        <!-- FORMULARIO (solo staff) -->
        <div class="glass-card" *ngIf="!esCliente">
          <h2 style="margin-bottom: 1rem;">Nueva medición</h2>
          <form (ngSubmit)="guardar()">
            <div class="grid2">
              <div class="form-group"><label class="form-label">Fecha</label><input type="date" class="form-control" name="fecha" [(ngModel)]="nuevo.fecha" [max]="hoy" required></div>
              <div class="form-group"><label class="form-label">Peso (kg) *</label><input type="number" step="0.1" class="form-control" name="peso" [(ngModel)]="nuevo.pesoKg" required></div>
              <div class="form-group"><label class="form-label">Cintura (cm)</label><input type="number" step="0.1" class="form-control" name="cintura" [(ngModel)]="nuevo.cinturaCm"></div>
              <div class="form-group"><label class="form-label">Pecho (cm)</label><input type="number" step="0.1" class="form-control" name="pecho" [(ngModel)]="nuevo.pechoCm"></div>
              <div class="form-group"><label class="form-label">Cadera (cm)</label><input type="number" step="0.1" class="form-control" name="cadera" [(ngModel)]="nuevo.caderaCm"></div>
              <div class="form-group"><label class="form-label">Brazo (cm)</label><input type="number" step="0.1" class="form-control" name="brazo" [(ngModel)]="nuevo.brazoCm"></div>
            </div>
            <div class="form-group"><label class="form-label">Notas / rutina</label><textarea class="form-control" rows="2" name="notas" [(ngModel)]="nuevo.notas" maxlength="500"></textarea></div>
            <button type="submit" class="btn btn-primary" style="width:100%;" [disabled]="guardando">{{ guardando ? 'Guardando...' : 'Guardar medición' }}</button>
          </form>
        </div>
      </div>

      <!-- HISTORIAL -->
      <div class="glass-card" style="padding:0; margin-top: 1.5rem;" *ngIf="esCliente || alumnoId">
        <div class="table-container">
          <table class="custom-table">
            <thead><tr><th>Fecha</th><th>Peso</th><th>Cintura</th><th>Pecho</th><th>Cadera</th><th>Brazo</th><th>Notas</th><th *ngIf="!esCliente"></th></tr></thead>
            <tbody>
              <tr *ngFor="let r of historialDesc | paginar:pagina">
                <td>{{ r.fecha }}</td>
                <td>{{ r.pesoKg ?? '—' }}</td><td>{{ r.cinturaCm ?? '—' }}</td><td>{{ r.pechoCm ?? '—' }}</td>
                <td>{{ r.caderaCm ?? '—' }}</td><td>{{ r.brazoCm ?? '—' }}</td>
                <td style="max-width: 260px; overflow-wrap:anywhere;">{{ r.notas || '' }}</td>
                <td *ngIf="!esCliente" style="text-align:right;"><button type="button" class="btn btn-danger" (click)="eliminar(r)">Eliminar</button></td>
              </tr>
              <tr *ngIf="registros.length === 0"><td [attr.colspan]="esCliente ? 7 : 8" style="text-align:center; color: var(--text-muted); padding: 2rem;">Aún no hay mediciones registradas.</td></tr>
            </tbody>
          </table>
          <div class="paginador-wrap"><app-paginador [total]="registros.length" [(pagina)]="pagina"></app-paginador></div>
        </div>
      </div>
    </div>
  `,
  styles: `
    .cols { display: grid; grid-template-columns: 1.4fr 1fr; gap: 1.5rem; }
    @media (max-width: 1100px) { .cols { grid-template-columns: 1fr; } }
    .cab { display: flex; justify-content: space-between; align-items: center; gap: 1rem; margin-bottom: .75rem; }
    h2 { font-size: 1.15rem; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 1rem; }
    .resumen { display: flex; gap: 1.25rem; flex-wrap: wrap; margin-top: .75rem; font-size: .9rem; color: var(--text-secondary); }
    .resumen b { color: var(--text-primary); }
    .baja b { color: var(--success); }
    .sube b { color: var(--warning); }
  `
})
export class SeguimientoComponent implements OnInit {
  readonly metricas = METRICAS;
  readonly hoy = new Date().toISOString().substring(0, 10);

  alumnos: Alumno[] = [];
  alumnoId: number | null = null;
  registros: Seguimiento[] = [];
  pagina = 1;

  metrica: Metrica = 'pesoKg';
  puntos: PuntoGrafico[] = [];
  ticks: { valor: number; y: number }[] = [];
  linea = '';
  cambio = 0;

  nuevo: Partial<Seguimiento> = this.vacio();
  guardando = false;

  constructor(
    private service: SeguimientoService,
    private authService: AuthService,
    private toast: ToastService
  ) {}

  get esCliente(): boolean { return this.authService.obtenerRol() === 'CLIENTE'; }
  get unidad(): string { return METRICAS.find(m => m.clave === this.metrica)?.unidad || ''; }
  get nombreMetrica(): string { return METRICAS.find(m => m.clave === this.metrica)?.nombre || ''; }
  get historialDesc(): Seguimiento[] { return [...this.registros].reverse(); }

  ngOnInit(): void {
    if (this.esCliente) {
      this.cargar();
    } else {
      this.service.alumnos().subscribe({ next: (r) => this.alumnos = r });
    }
  }

  private vacio(): Partial<Seguimiento> {
    return { fecha: new Date().toISOString().substring(0, 10), pesoKg: null, cinturaCm: null, pechoCm: null, caderaCm: null, brazoCm: null, notas: '' };
  }

  cargar(): void {
    this.pagina = 1;
    if (!this.esCliente && !this.alumnoId) { this.registros = []; this.construir(); return; }
    const obs = this.esCliente ? this.service.listar() : this.service.listar(this.alumnoId as number);
    obs.subscribe({
      next: (r) => { this.registros = r; this.construir(); },
      error: () => { this.registros = []; this.construir(); }
    });
  }

  guardar(): void {
    if (!this.alumnoId) { this.toast.error('Selecciona un alumno.'); return; }
    if (!this.nuevo.pesoKg) { this.toast.error('El peso es obligatorio.'); return; }
    this.guardando = true;
    this.service.registrar({ ...this.nuevo, clienteId: this.alumnoId }).subscribe({
      next: () => {
        this.guardando = false;
        this.nuevo = this.vacio();
        this.toast.exito('Medición registrada.');
        this.cargar();
      },
      error: () => { this.guardando = false; }
    });
  }

  eliminar(r: Seguimiento): void {
    if (!r.idSeguimiento || !confirm('¿Eliminar esta medición?')) return;
    this.service.eliminar(r.idSeguimiento).subscribe({
      next: () => { this.toast.exito('Medición eliminada.'); this.cargar(); }
    });
  }

  /** Calcula los puntos del gráfico de línea para la métrica elegida. */
  construir(): void {
    const datos = this.registros
      .filter(r => r[this.metrica] !== null && r[this.metrica] !== undefined)
      .map(r => ({ fecha: r.fecha, valor: Number(r[this.metrica]) }));

    if (datos.length < 2) { this.puntos = []; this.ticks = []; this.linea = ''; this.cambio = 0; return; }

    const min = Math.min(...datos.map(d => d.valor));
    const max = Math.max(...datos.map(d => d.valor));
    const margen = Math.max((max - min) * 0.15, 0.5);
    const lo = Math.floor((min - margen) * 10) / 10;
    const hi = Math.ceil((max + margen) * 10) / 10;

    const x0 = 56, x1 = 535, yTop = 20, yBase = 235;
    const y = (v: number) => yBase - ((v - lo) / (hi - lo)) * (yBase - yTop);
    const paso = (x1 - x0) / (datos.length - 1);

    this.puntos = datos.map((d, i) => ({ x: Math.round(x0 + paso * i), y: Math.round(y(d.valor)), valor: d.valor, fecha: d.fecha }));
    this.linea = this.puntos.map(p => `${p.x},${p.y}`).join(' ');
    this.ticks = [0, 0.25, 0.5, 0.75, 1].map(f => {
      const valor = Math.round((lo + (hi - lo) * f) * 10) / 10;
      return { valor, y: Math.round(y(valor)) };
    });
    this.cambio = Math.round((datos[datos.length - 1].valor - datos[0].valor) * 10) / 10;
  }
}
