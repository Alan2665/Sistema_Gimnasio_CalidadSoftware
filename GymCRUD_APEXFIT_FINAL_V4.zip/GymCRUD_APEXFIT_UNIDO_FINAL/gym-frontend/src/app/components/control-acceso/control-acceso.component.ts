import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import jsQR from 'jsqr';
import { AsistenciaService, ClaseService } from '../../services/gym.service';
import { AsistenciaLista, Clase } from '../../models/gym.models';

interface Registro {
  ok: boolean;
  texto: string;
  detalle: string;
  hora: string;
}

/** Control de acceso: el ADMIN o el entrenador escanean el QR del cliente (o digitan su cédula) para registrar asistencia. */
@Component({
  selector: 'app-control-acceso',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="animate-fade-in">
      <div style="margin-bottom: 1.5rem;">
        <h1 style="font-size: 2.25rem;">Toma de lista</h1>
        <p style="color: var(--text-secondary);">Escanea el QR del cliente para confirmar que los inscritos realmente asistieron a la clase de hoy</p>
      </div>

      <div class="layout">
        <div class="glass-card">
          <div class="form-group">
            <label class="form-label">Clase en curso</label>
            <select class="form-control" [(ngModel)]="claseId" (ngModelChange)="cargarLista()" name="clase">
              <option [ngValue]="null" disabled>-- Seleccionar clase --</option>
              <option *ngFor="let c of clases" [ngValue]="c.idClase">{{ c.nombre }} · {{ c.horario }}</option>
            </select>
          </div>

          <div class="visor" [class.activo]="camaraActiva">
            <video #video playsinline muted></video>
            <div class="mira" *ngIf="camaraActiva"></div>
            <div class="placeholder" *ngIf="!camaraActiva">📷<br>La cámara está apagada</div>
          </div>
          <canvas #canvas style="display:none;"></canvas>

          <div class="acciones">
            <button type="button" class="btn btn-primary" *ngIf="!camaraActiva" (click)="iniciarCamara()" [disabled]="!claseId">Iniciar cámara</button>
            <button type="button" class="btn btn-secondary" *ngIf="camaraActiva" (click)="detenerCamara()">Detener cámara</button>
          </div>
          <div class="aviso" *ngIf="errorCamara">{{ errorCamara }}</div>

          <hr style="border: none; border-top: 1px solid var(--border-color); margin: 1.25rem 0;">

          <form (ngSubmit)="registrarManual()">
            <label class="form-label">¿Sin cámara? Escribe la cédula del cliente (o usa un lector de códigos) para confirmar su asistencia</label>
            <div style="display:flex; gap:.5rem;">
              <input class="form-control" name="manual" [(ngModel)]="codigoManual" placeholder="Cédula o código" autocomplete="off">
              <button type="submit" class="btn btn-secondary" [disabled]="!claseId || !codigoManual.trim() || procesando">Registrar</button>
            </div>
          </form>
        </div>

        <div class="glass-card">
          <h2 style="font-size:1.15rem; margin-bottom: 1rem;">Último registro</h2>

          <div class="resultado" *ngIf="ultimo; else vacio" [ngClass]="ultimo.ok ? 'ok' : 'mal'">
            <div class="icono">{{ ultimo.ok ? '✅' : '⛔' }}</div>
            <div>
              <div class="titulo">{{ ultimo.texto }}</div>
              <div class="detalle">{{ ultimo.detalle }}</div>
            </div>
          </div>
          <ng-template #vacio><p style="color: var(--text-muted);">Aún no se ha registrado ningún ingreso.</p></ng-template>

          <h3 style="font-size:1rem; margin: 1.5rem 0 .75rem;">Historial de la sesión</h3>
          <div class="historial">
            <div class="fila" *ngFor="let r of historial" [ngClass]="r.ok ? 'ok' : 'mal'">
              <span class="hora">{{ r.hora }}</span>
              <span>{{ r.texto }}</span>
            </div>
            <div *ngIf="historial.length === 0" style="color: var(--text-muted); font-size:.9rem;">Sin movimientos.</div>
          </div>
        </div>
      </div>

      <div class="glass-card" style="margin-top: 1.5rem;" *ngIf="claseId">
        <div class="lista-cab">
          <h2 style="font-size:1.15rem;">Inscritos de hoy</h2>
          <span class="badge" [ngClass]="presentes === lista.length && lista.length ? 'badge-success' : 'badge-info'">
            Presentes {{ presentes }} de {{ lista.length }}
          </span>
        </div>
        <div class="progreso" *ngIf="lista.length"><div [style.width.%]="lista.length ? presentes * 100 / lista.length : 0"></div></div>

        <div class="table-container" *ngIf="lista.length; else sinInscritos">
          <table class="custom-table">
            <thead><tr><th>Cliente</th><th>Horario</th><th>Estado</th><th style="text-align:right;">Acción</th></tr></thead>
            <tbody>
              <tr *ngFor="let r of lista">
                <td><strong>{{ r.cliente }}</strong><div style="font-size:.75rem; color: var(--text-muted);">Cédula: {{ r.cedula }}</div></td>
                <td>{{ r.franja || '—' }}</td>
                <td>
                  <span class="badge" [ngClass]="r.presente ? 'badge-success' : 'badge-warning'">{{ r.presente ? 'Presente' : 'Pendiente' }}</span>
                  <span *ngIf="r.horaIngreso" style="font-size:.75rem; color: var(--text-muted); margin-left:.4rem;">{{ r.horaIngreso }}</span>
                </td>
                <td style="text-align:right;">
                  <button type="button" class="btn btn-secondary" *ngIf="!r.presente" (click)="marcar(r)" [disabled]="procesando">✔ Marcar presente</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <ng-template #sinInscritos><p style="color: var(--text-muted);">Nadie está inscrito en esta clase para hoy. Los clientes se inscriben desde Asistencias.</p></ng-template>
      </div>
    </div>
  `,
  styles: `
    .lista-cab { display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap; margin-bottom:.75rem; }
    .progreso { height: 8px; border-radius: 999px; background: var(--border-color); overflow: hidden; margin-bottom: 1rem; }
    .progreso div { height: 100%; background: linear-gradient(90deg, #34d399, #059669); transition: width .4s ease; }
    .layout { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    @media (max-width: 1000px) { .layout { grid-template-columns: 1fr; } }
    .visor { position: relative; width: 100%; aspect-ratio: 4 / 3; max-height: 360px; border-radius: var(--radius-lg); overflow: hidden; background: #000; border: 1px solid var(--border-color-hover); }
    .visor video { width: 100%; height: 100%; object-fit: cover; display: none; }
    .visor.activo video { display: block; }
    .placeholder { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; color: #9ca3af; font-size: 1rem; line-height: 2; }
    .mira { position: absolute; inset: 18%; border: 3px solid rgba(99,102,241,.9); border-radius: 18px; box-shadow: 0 0 0 999px rgba(0,0,0,.35); }
    .acciones { margin-top: 1rem; display: flex; gap: .5rem; }
    .aviso { margin-top: .75rem; padding: .7rem .9rem; border-radius: var(--radius-md); background: rgba(245,158,11,.12); border: 1px solid rgba(245,158,11,.4); font-size: .85rem; }
    .resultado { display: flex; gap: 1rem; align-items: center; padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--border-color-hover); }
    .resultado.ok { border-color: var(--success); background: var(--success-glow); }
    .resultado.mal { border-color: var(--danger); background: var(--danger-glow); }
    .icono { font-size: 2rem; }
    .titulo { font-weight: 700; }
    .detalle { color: var(--text-secondary); font-size: .88rem; margin-top: 2px; }
    .historial { display: flex; flex-direction: column; gap: .4rem; max-height: 260px; overflow-y: auto; }
    .fila { display: flex; gap: .75rem; font-size: .85rem; padding: .45rem .6rem; border-radius: var(--radius-sm); border-left: 3px solid; }
    .fila.ok { border-color: var(--success); }
    .fila.mal { border-color: var(--danger); }
    .hora { color: var(--text-muted); font-variant-numeric: tabular-nums; }
  `
})
export class ControlAccesoComponent implements OnInit, OnDestroy {
  @ViewChild('video') videoRef!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  clases: Clase[] = [];
  claseId: number | null = null;
  codigoManual = '';

  camaraActiva = false;
  errorCamara = '';
  procesando = false;

  lista: AsistenciaLista[] = [];
  ultimo: Registro | null = null;
  historial: Registro[] = [];

  private stream: MediaStream | null = null;
  private rafId = 0;
  private ultimoEscaneo = 0;
  private ultimoCodigo = '';
  private ultimoCodigoTiempo = 0;

  constructor(private claseService: ClaseService, private asistenciaService: AsistenciaService) {}

  ngOnInit(): void {
    this.claseService.listar().subscribe({
      next: (res) => {
        this.clases = res;
        if (res.length === 1) { this.claseId = res[0].idClase ?? null; this.cargarLista(); }
      }
    });
  }

  get presentes(): number { return this.lista.filter(r => r.presente).length; }

  private hoy(): string {
    const d = new Date();
    const z = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
  }

  cargarLista(): void {
    if (!this.claseId) { this.lista = []; return; }
    this.asistenciaService.lista(this.claseId, this.hoy()).subscribe({
      next: (r) => this.lista = r,
      error: () => this.lista = []
    });
  }

  marcar(r: AsistenciaLista): void {
    this.procesando = true;
    this.asistenciaService.marcarPresente(r.idAsistencia).subscribe({
      next: (res) => {
        this.procesando = false;
        this.agregar({ ok: true, texto: res.cliente, detalle: `Presente en ${res.clase} · ${res.presentes}/${res.inscritos}`, hora: this.hora() });
        this.cargarLista();
      },
      error: () => { this.procesando = false; }
    });
  }

  ngOnDestroy(): void {
    this.detenerCamara();
  }

  // ------------------------------------------------------------------ cámara
  async iniciarCamara(): Promise<void> {
    this.errorCamara = '';
    if (!navigator.mediaDevices?.getUserMedia) {
      this.errorCamara = 'Este navegador no permite usar la cámara. Usa el campo de cédula.';
      return;
    }
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      this.camaraActiva = true;
      // El <video> ya existe en el DOM (solo está oculto con CSS), se puede enlazar de inmediato
      const video = this.videoRef.nativeElement;
      video.srcObject = this.stream;
      await video.play();
      this.rafId = requestAnimationFrame(() => this.escanear());
    } catch (e) {
      this.detenerCamara();
      const nombre = (e as { name?: string })?.name;
      this.errorCamara = nombre === 'NotAllowedError'
        ? 'Permiso de cámara denegado. Habilítalo en el navegador o usa el campo de cédula.'
        : nombre === 'NotFoundError'
          ? 'No se encontró ninguna cámara. Usa el campo de cédula.'
          : 'No se pudo iniciar la cámara. Usa el campo de cédula.';
    }
  }

  detenerCamara(): void {
    if (this.rafId) cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.stream?.getTracks().forEach(t => t.stop());
    this.stream = null;
    this.camaraActiva = false;
    const video = this.videoRef?.nativeElement;
    if (video) video.srcObject = null;
  }

  private escanear(): void {
    if (!this.camaraActiva) return;
    const ahora = performance.now();
    const video = this.videoRef.nativeElement;

    // ~7 lecturas por segundo es suficiente y evita saturar el CPU
    if (ahora - this.ultimoEscaneo > 140 && video.readyState === video.HAVE_ENOUGH_DATA && video.videoWidth > 0) {
      this.ultimoEscaneo = ahora;
      const canvas = this.canvasRef.nativeElement;
      const ancho = Math.min(480, video.videoWidth);
      const alto = Math.round(ancho * video.videoHeight / video.videoWidth);
      canvas.width = ancho;
      canvas.height = alto;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (ctx) {
        ctx.drawImage(video, 0, 0, ancho, alto);
        const img = ctx.getImageData(0, 0, ancho, alto);
        const codigo = jsQR(img.data, ancho, alto, { inversionAttempts: 'dontInvert' });
        if (codigo?.data) this.procesarCodigo(codigo.data);
      }
    }
    this.rafId = requestAnimationFrame(() => this.escanear());
  }

  // ------------------------------------------------------------------ registro
  private procesarCodigo(codigo: string): void {
    const ahora = Date.now();
    // Evita registrar varias veces el mismo QR mientras sigue frente a la cámara
    if (codigo === this.ultimoCodigo && ahora - this.ultimoCodigoTiempo < 5000) return;
    this.ultimoCodigo = codigo;
    this.ultimoCodigoTiempo = ahora;
    this.registrar(codigo);
  }

  registrarManual(): void {
    const codigo = this.codigoManual.trim();
    if (!codigo) return;
    this.registrar(codigo);
    this.codigoManual = '';
  }

  private registrar(codigo: string): void {
    if (!this.claseId || this.procesando) return;
    this.procesando = true;
    this.asistenciaService.registrarPorQr(codigo, this.claseId).subscribe({
      next: (res) => {
        this.procesando = false;
        this.agregar({ ok: true, texto: res.cliente, detalle: `Asistencia confirmada en ${res.clase} a las ${res.hora} · Presentes ${res.presentes}/${res.inscritos}`, hora: this.hora() });
        this.cargarLista();
      },
      error: (err) => {
        this.procesando = false;
        this.agregar({
          ok: false,
          texto: 'Asistencia no registrada',
          detalle: err?.error?.message || 'No se pudo registrar la asistencia.',
          hora: this.hora()
        });
      }
    });
  }

  private agregar(r: Registro): void {
    this.ultimo = r;
    this.historial = [r, ...this.historial].slice(0, 12);
  }

  private hora(): string {
    return new Date().toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
}
