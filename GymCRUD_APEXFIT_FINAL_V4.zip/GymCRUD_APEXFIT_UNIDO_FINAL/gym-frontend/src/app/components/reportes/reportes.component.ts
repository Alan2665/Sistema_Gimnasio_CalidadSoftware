import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import {
  AsistenciaService, DetalleVentaService, InscripcionService, PagoService
} from '../../services/gym.service';
import { Asistencia, DetalleVenta, Inscripcion, Pago } from '../../models/gym.models';
import { estadoAsistencia } from '../../utils/asistencia.util';

interface FilaFaltas { cliente: string; cedula: string; inscritas: number; asistio: number; falto: number; porcentaje: number; }

interface FilaSimple { etiqueta: string; valor: number; extra?: number; }

function aIso(d: Date): string {
  const z = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

function esc(v: unknown): string {
  return String(v ?? '').replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } as Record<string, string>
  )[c] || c);
}

/** Reportes del administrador: ventas, productos más vendidos, ingresos y asistencia, con filtro de fechas y exportación. */
@Component({
  selector: 'app-reportes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="animate-fade-in">
      <div style="margin-bottom: 1.5rem;">
        <h1 style="font-size: 2.25rem;">Reportes</h1>
        <p style="color: var(--text-secondary);">Resumen del negocio por rango de fechas, listo para Excel o PDF</p>
      </div>

      <div class="glass-card filtros">
        <div class="form-group" style="margin:0;">
          <label class="form-label">Desde</label>
          <input type="date" class="form-control" [(ngModel)]="desde" (change)="calcular()">
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Hasta</label>
          <input type="date" class="form-control" [(ngModel)]="hasta" (change)="calcular()">
        </div>
        <div class="atajos">
          <button type="button" class="btn btn-secondary" (click)="atajo('hoy')">Hoy</button>
          <button type="button" class="btn btn-secondary" (click)="atajo('semana')">7 días</button>
          <button type="button" class="btn btn-secondary" (click)="atajo('mes')">Este mes</button>
          <button type="button" class="btn btn-secondary" (click)="atajo('anio')">Este año</button>
        </div>
        <div class="exportar">
          <button type="button" class="btn btn-primary" (click)="descargarCsv()" [disabled]="cargando">⬇ Excel (CSV)</button>
          <button type="button" class="btn btn-secondary" (click)="imprimir()" [disabled]="cargando">🖨 Imprimir / PDF</button>
        </div>
      </div>

      <p *ngIf="cargando" style="color: var(--text-muted);">Cargando datos...</p>
      <div class="aviso" *ngIf="errorFechas">{{ errorFechas }}</div>

      <ng-container *ngIf="!cargando">
        <div class="kpis">
          <div class="glass-card kpi"><span>Total recaudado</span><strong class="verde">\${{ totalRecaudado | number:'1.2-2' }}</strong></div>
          <div class="glass-card kpi"><span>Membresías</span><strong>\${{ ingresosMembresia | number:'1.2-2' }}</strong></div>
          <div class="glass-card kpi"><span>Punto de venta</span><strong>\${{ ingresosPos | number:'1.2-2' }}</strong></div>
          <div class="glass-card kpi"><span>Ventas POS</span><strong>{{ numeroVentas }}</strong></div>
          <div class="glass-card kpi"><span>Inscripciones a clases</span><strong>{{ totalAsistencias }}</strong></div>
          <div class="glass-card kpi"><span>Asistieron</span><strong class="verde">{{ asistieron }}</strong></div>
          <div class="glass-card kpi"><span>Inscritos que no asistieron</span><strong class="rojo">{{ noAsistieron }}</strong></div>
          <div class="glass-card kpi"><span>Asistencia real</span><strong>{{ tasaAsistencia }}%</strong></div>
          <div class="glass-card kpi"><span>Nuevas inscripciones</span><strong>{{ nuevasInscripciones }}</strong></div>
        </div>

        <div class="cols">
          <div class="glass-card">
            <h2>Productos más vendidos</h2>
            <div class="barra-fila" *ngFor="let f of topProductos">
              <div class="barra-top"><span>{{ f.etiqueta }}</span><b>{{ f.valor }} uds · \${{ f.extra | number:'1.2-2' }}</b></div>
              <div class="barra"><div [style.width.%]="porcentaje(f.valor, maxProductos)"></div></div>
            </div>
            <p class="vacio" *ngIf="topProductos.length === 0">Sin ventas de productos en este rango.</p>
          </div>

          <div class="glass-card">
            <h2>Asistencia por clase</h2>
            <div class="barra-fila" *ngFor="let f of asistenciaPorClase">
              <div class="barra-top"><span>{{ f.etiqueta }}</span><b>{{ f.valor }}</b></div>
              <div class="barra"><div class="alt" [style.width.%]="porcentaje(f.valor, maxAsistencias)"></div></div>
            </div>
            <p class="vacio" *ngIf="asistenciaPorClase.length === 0">Sin asistencias en este rango.</p>
          </div>

          <div class="glass-card" style="grid-column: 1 / -1;">
            <h2>Clientes inscritos que no están asistiendo</h2>
            <p class="vacio" style="margin-bottom:.75rem;">Solo cuentan clases cuya fecha ya pasó: asistió = su ingreso fue confirmado por QR o toma de lista.</p>
            <div class="table-container" *ngIf="faltasPorCliente.length; else sinFaltas">
              <table class="custom-table">
                <thead><tr><th>Cliente</th><th>Inscripciones</th><th>Asistió</th><th>No asistió</th><th>% asistencia</th></tr></thead>
                <tbody>
                  <tr *ngFor="let f of faltasPorCliente">
                    <td><strong>{{ f.cliente }}</strong><div style="font-size:.75rem; color: var(--text-muted);">Cédula: {{ f.cedula }}</div></td>
                    <td>{{ f.inscritas }}</td>
                    <td style="color: var(--success); font-weight:700;">{{ f.asistio }}</td>
                    <td style="color: var(--danger); font-weight:700;">{{ f.falto }}</td>
                    <td><span class="badge" [ngClass]="f.porcentaje >= 70 ? 'badge-success' : f.porcentaje >= 40 ? 'badge-warning' : 'badge-danger'">{{ f.porcentaje }}%</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <ng-template #sinFaltas><p class="vacio">No hay inscritos con inasistencias en este rango. 🎉</p></ng-template>
          </div>

          <div class="glass-card">
            <h2>Ingresos por método de pago</h2>
            <div class="barra-fila" *ngFor="let f of porMetodo">
              <div class="barra-top"><span>{{ f.etiqueta }}</span><b>\${{ f.valor | number:'1.2-2' }}</b></div>
              <div class="barra"><div class="verde" [style.width.%]="porcentaje(f.valor, maxMetodo)"></div></div>
            </div>
            <p class="vacio" *ngIf="porMetodo.length === 0">Sin pagos en este rango.</p>
          </div>
        </div>
      </ng-container>
    </div>
  `,
  styles: `
    .filtros { display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap; margin-bottom: 1.5rem; }
    .atajos, .exportar { display: flex; gap: .5rem; flex-wrap: wrap; }
    .exportar { margin-left: auto; }
    .aviso { margin-bottom: 1rem; padding: .7rem .9rem; border-radius: var(--radius-md); background: rgba(245,158,11,.12); border: 1px solid rgba(245,158,11,.4); }
    .kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
    .kpi { display: flex; flex-direction: column; gap: .3rem; }
    .kpi span { color: var(--text-secondary); font-size: .82rem; }
    .kpi strong { font-size: 1.6rem; }
    .verde { color: var(--success); }
    .rojo { color: var(--danger); }
    .cols { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem; }
    h2 { font-size: 1.1rem; margin-bottom: 1rem; }
    .barra-fila { margin-bottom: .85rem; }
    .barra-top { display: flex; justify-content: space-between; gap: .75rem; font-size: .85rem; margin-bottom: .25rem; }
    .barra-top span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .barra { height: 9px; border-radius: 999px; background: var(--border-color); overflow: hidden; }
    .barra div { height: 100%; border-radius: 999px; background: var(--accent-gradient); transition: width .4s ease; }
    .barra div.alt { background: linear-gradient(90deg, #f59e0b, #ef4444); }
    .barra div.verde { background: linear-gradient(90deg, #34d399, #059669); }
    .vacio { color: var(--text-muted); font-size: .9rem; }
    @media (max-width: 700px) { .exportar { margin-left: 0; } }
  `
})
export class ReportesComponent implements OnInit {
  desde = '';
  hasta = '';
  cargando = true;
  errorFechas = '';

  private pagos: Pago[] = [];
  private detalles: DetalleVenta[] = [];
  private asistencias: Asistencia[] = [];
  private inscripciones: Inscripcion[] = [];

  totalRecaudado = 0;
  ingresosMembresia = 0;
  ingresosPos = 0;
  numeroVentas = 0;
  totalAsistencias = 0;
  asistieron = 0;
  noAsistieron = 0;
  tasaAsistencia = 0;
  faltasPorCliente: FilaFaltas[] = [];
  nuevasInscripciones = 0;

  topProductos: FilaSimple[] = [];
  asistenciaPorClase: FilaSimple[] = [];
  porMetodo: FilaSimple[] = [];
  private pagosRango: Pago[] = [];

  constructor(
    private pagoService: PagoService,
    private detalleService: DetalleVentaService,
    private asistenciaService: AsistenciaService,
    private inscripcionService: InscripcionService
  ) {}

  ngOnInit(): void {
    this.atajo('mes', false);
    forkJoin({
      pagos: this.pagoService.listar(),
      detalles: this.detalleService.listar(),
      asistencias: this.asistenciaService.listar(),
      inscripciones: this.inscripcionService.listar()
    }).subscribe({
      next: (r) => {
        this.pagos = r.pagos;
        this.detalles = r.detalles;
        this.asistencias = r.asistencias;
        this.inscripciones = r.inscripciones;
        this.cargando = false;
        this.calcular();
      },
      error: () => { this.cargando = false; }
    });
  }

  atajo(tipo: 'hoy' | 'semana' | 'mes' | 'anio', recalcular = true): void {
    const hoy = new Date();
    this.hasta = aIso(hoy);
    if (tipo === 'hoy') this.desde = aIso(hoy);
    else if (tipo === 'semana') this.desde = aIso(new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - 6));
    else if (tipo === 'mes') this.desde = aIso(new Date(hoy.getFullYear(), hoy.getMonth(), 1));
    else this.desde = aIso(new Date(hoy.getFullYear(), 0, 1));
    if (recalcular) this.calcular();
  }

  porcentaje(valor: number, max: number): number {
    return max > 0 ? Math.max(3, Math.round((valor / max) * 100)) : 0;
  }
  get maxProductos(): number { return Math.max(0, ...this.topProductos.map(f => f.valor)); }
  get maxAsistencias(): number { return Math.max(0, ...this.asistenciaPorClase.map(f => f.valor)); }
  get maxMetodo(): number { return Math.max(0, ...this.porMetodo.map(f => f.valor)); }

  private enRango(fecha: string | undefined): boolean {
    if (!fecha) return false;
    const f = String(fecha).substring(0, 10);
    return f >= this.desde && f <= this.hasta;
  }

  calcular(): void {
    this.errorFechas = '';
    if (!this.desde || !this.hasta) return;
    if (this.desde > this.hasta) {
      this.errorFechas = 'La fecha "Desde" no puede ser posterior a "Hasta".';
      return;
    }

    this.pagosRango = this.pagos.filter(p => this.enRango(p.fechaPago) && (p.estado || '').toLowerCase() === 'completado');
    const esProd = (p: Pago) => (p.tipoPago || 'MEMBRESIA') === 'PRODUCTO';
    this.totalRecaudado = this.suma(this.pagosRango);
    this.ingresosPos = this.suma(this.pagosRango.filter(esProd));
    this.ingresosMembresia = this.suma(this.pagosRango.filter(p => !esProd(p)));
    this.numeroVentas = this.pagosRango.filter(esProd).length;

    const rangoAsis = this.asistencias.filter(a => this.enRango(a.fechaAsistencia));
    this.totalAsistencias = rangoAsis.length;

    // Asistencia real vs inscripción
    const porCliente = new Map<string, FilaFaltas>();
    this.asistieron = 0;
    this.noAsistieron = 0;
    for (const a of rangoAsis) {
      const estado = estadoAsistencia(a);
      if (estado === 'PENDIENTE') continue;            // aún no se puede saber si asistirá
      const clave = String(a.cliente?.idCliente ?? a.cliente?.cedula);
      const fila = porCliente.get(clave) || {
        cliente: `${a.cliente?.nombre ?? ''} ${a.cliente?.apellido ?? ''}`.trim(),
        cedula: a.cliente?.cedula ?? '', inscritas: 0, asistio: 0, falto: 0, porcentaje: 0
      };
      fila.inscritas++;
      if (estado === 'ASISTIO') { fila.asistio++; this.asistieron++; } else { fila.falto++; this.noAsistieron++; }
      porCliente.set(clave, fila);
    }
    const evaluadas = this.asistieron + this.noAsistieron;
    this.tasaAsistencia = evaluadas ? Math.round((this.asistieron / evaluadas) * 100) : 0;
    this.faltasPorCliente = [...porCliente.values()]
      .map(f => ({ ...f, porcentaje: Math.round((f.asistio / f.inscritas) * 100) }))
      .filter(f => f.falto > 0)
      .sort((a, b) => b.falto - a.falto || a.porcentaje - b.porcentaje)
      .slice(0, 15);
    this.nuevasInscripciones = this.inscripciones.filter(i => this.enRango(i.fechaInicio)).length;

    // Productos más vendidos (por unidades)
    const prod = new Map<string, { uds: number; total: number }>();
    for (const d of this.detalles.filter(x => this.enRango(x.venta?.fechaVenta))) {
      const nombre = d.producto?.nombre || 'Producto';
      const a = prod.get(nombre) || { uds: 0, total: 0 };
      a.uds += Number(d.cantidad) || 0;
      a.total += Number(d.subtotal) || 0;
      prod.set(nombre, a);
    }
    this.topProductos = [...prod.entries()]
      .map(([etiqueta, v]) => ({ etiqueta, valor: v.uds, extra: v.total }))
      .sort((a, b) => b.valor - a.valor).slice(0, 8);

    // Asistencia por clase
    const clases = new Map<string, number>();
    for (const a of rangoAsis) {
      const n = a.clase?.nombre || 'Sin clase';
      clases.set(n, (clases.get(n) || 0) + 1);
    }
    this.asistenciaPorClase = [...clases.entries()].map(([etiqueta, valor]) => ({ etiqueta, valor }))
      .sort((a, b) => b.valor - a.valor).slice(0, 8);

    // Ingresos por método de pago
    const metodos = new Map<string, number>();
    for (const p of this.pagosRango) {
      const m = p.metodoPago || 'Otro';
      metodos.set(m, (metodos.get(m) || 0) + Number(p.monto));
    }
    this.porMetodo = [...metodos.entries()].map(([etiqueta, valor]) => ({ etiqueta, valor }))
      .sort((a, b) => b.valor - a.valor);
  }

  private suma(lista: Pago[]): number {
    return Math.round(lista.reduce((s, p) => s + Number(p.monto || 0), 0) * 100) / 100;
  }

  // ------------------------------------------------------------------ exportación
  /** CSV con separador ";" y BOM UTF-8: se abre directo en Excel en español. */
  descargarCsv(): void {
    if (this.errorFechas) return;
    const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const fila = (...c: unknown[]) => c.map(q).join(';');
    const l: string[] = [];

    l.push(fila('REPORTE APEX FIT'));
    l.push(fila('Desde', this.desde, 'Hasta', this.hasta));
    l.push('');
    l.push(fila('RESUMEN'));
    l.push(fila('Total recaudado', this.totalRecaudado.toFixed(2)));
    l.push(fila('Ingresos por membresías', this.ingresosMembresia.toFixed(2)));
    l.push(fila('Ingresos punto de venta', this.ingresosPos.toFixed(2)));
    l.push(fila('Ventas POS', this.numeroVentas));
    l.push(fila('Inscripciones a clases', this.totalAsistencias));
    l.push(fila('Asistieron', this.asistieron));
    l.push(fila('Inscritos que no asistieron', this.noAsistieron));
    l.push(fila('Asistencia real (%)', this.tasaAsistencia));
    l.push(fila('Nuevas inscripciones', this.nuevasInscripciones));
    l.push('');
    l.push(fila('PRODUCTOS MÁS VENDIDOS'));
    l.push(fila('Producto', 'Unidades', 'Ingresos'));
    this.topProductos.forEach(f => l.push(fila(f.etiqueta, f.valor, (f.extra || 0).toFixed(2))));
    l.push('');
    l.push(fila('ASISTENCIA POR CLASE'));
    l.push(fila('Clase', 'Asistencias'));
    this.asistenciaPorClase.forEach(f => l.push(fila(f.etiqueta, f.valor)));
    l.push('');
    l.push(fila('CLIENTES INSCRITOS QUE NO ESTÁN ASISTIENDO'));
    l.push(fila('Cliente', 'Cédula', 'Inscripciones', 'Asistió', 'No asistió', '% asistencia'));
    this.faltasPorCliente.forEach(f => l.push(fila(f.cliente, f.cedula, f.inscritas, f.asistio, f.falto, f.porcentaje)));
    l.push('');
    l.push(fila('INGRESOS POR MÉTODO DE PAGO'));
    l.push(fila('Método', 'Monto'));
    this.porMetodo.forEach(f => l.push(fila(f.etiqueta, f.valor.toFixed(2))));
    l.push('');
    l.push(fila('DETALLE DE PAGOS'));
    l.push(fila('N° pago', 'Fecha', 'Tipo', 'Cliente', 'Método', 'Monto'));
    this.pagosRango.forEach(p => {
      const c = p.inscripcion?.cliente || p.venta?.cliente;
      l.push(fila(p.idPago, p.fechaPago, p.tipoPago || 'MEMBRESIA', c ? `${c.nombre} ${c.apellido}` : '', p.metodoPago, Number(p.monto).toFixed(2)));
    });

    const blob = new Blob(['\uFEFF' + l.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_apexfit_${this.desde}_a_${this.hasta}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /** Abre una vista imprimible; en el diálogo se puede elegir "Guardar como PDF". */
  imprimir(): void {
    if (this.errorFechas) return;
    const tabla = (titulo: string, cab: string[], filas: string[][]) =>
      `<h2>${esc(titulo)}</h2><table><thead><tr>${cab.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>` +
      (filas.length ? filas.map(f => `<tr>${f.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')
        : `<tr><td colspan="${cab.length}" class="v">Sin datos en este rango</td></tr>`) + `</tbody></table>`;

    const css = 'body{font-family:Arial,Helvetica,sans-serif;padding:28px;color:#111827}h1{margin:0;font-size:26px}h1 span{color:#6366f1}' +
      '.sub{color:#6b7280;margin:4px 0 18px}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:8px}' +
      '.k{border:1px solid #d1d5db;border-radius:8px;padding:10px}.k small{color:#6b7280;display:block}.k b{font-size:20px}' +
      'h2{font-size:16px;margin:22px 0 8px;border-bottom:2px solid #6366f1;padding-bottom:4px}table{width:100%;border-collapse:collapse;font-size:13px}' +
      'th{background:#f3f4f6;text-align:left;padding:6px;border-bottom:1px solid #d1d5db}td{padding:6px;border-bottom:1px solid #e5e7eb}.v{text-align:center;color:#6b7280}';

    const html = `<html><head><meta charset="utf-8"><title>Reporte APEXFIT ${esc(this.desde)} a ${esc(this.hasta)}</title><style>${css}</style></head><body>` +
      `<h1>APEX<span>FIT</span> · Reporte</h1><div class="sub">Del ${esc(this.desde)} al ${esc(this.hasta)}</div>` +
      `<div class="kpis">` +
      `<div class="k"><small>Total recaudado</small><b>$${this.totalRecaudado.toFixed(2)}</b></div>` +
      `<div class="k"><small>Membresías</small><b>$${this.ingresosMembresia.toFixed(2)}</b></div>` +
      `<div class="k"><small>Punto de venta</small><b>$${this.ingresosPos.toFixed(2)}</b></div>` +
      `<div class="k"><small>Ventas POS</small><b>${this.numeroVentas}</b></div>` +
      `<div class="k"><small>Inscripciones a clases</small><b>${this.totalAsistencias}</b></div>` +
      `<div class="k"><small>Asistieron / No asistieron</small><b>${this.asistieron} / ${this.noAsistieron}</b></div>` +
      `<div class="k"><small>Asistencia real</small><b>${this.tasaAsistencia}%</b></div>` +
      `<div class="k"><small>Nuevas inscripciones</small><b>${this.nuevasInscripciones}</b></div></div>` +
      tabla('Productos más vendidos', ['Producto', 'Unidades', 'Ingresos'],
        this.topProductos.map(f => [f.etiqueta, String(f.valor), '$' + (f.extra || 0).toFixed(2)])) +
      tabla('Asistencia por clase', ['Clase', 'Asistencias'], this.asistenciaPorClase.map(f => [f.etiqueta, String(f.valor)])) +
      tabla('Inscritos que no están asistiendo', ['Cliente', 'Inscripciones', 'Asistió', 'No asistió', '% asistencia'],
        this.faltasPorCliente.map(f => [f.cliente, String(f.inscritas), String(f.asistio), String(f.falto), f.porcentaje + '%'])) +
      tabla('Ingresos por método de pago', ['Método', 'Monto'], this.porMetodo.map(f => [f.etiqueta, '$' + f.valor.toFixed(2)])) +
      `<script>window.onload=function(){window.print()}</script></body></html>`;

    const w = window.open('', '_blank', 'width=900,height=700');
    if (!w) return;
    w.document.open();
    w.document.write(html);
    w.document.close();
  }
}
