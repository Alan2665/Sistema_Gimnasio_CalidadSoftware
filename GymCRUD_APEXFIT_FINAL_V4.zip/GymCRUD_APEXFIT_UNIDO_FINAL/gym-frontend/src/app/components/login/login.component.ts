import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username = '';
  password = '';
  cargando = false;
  error = '';
  exito = '';

  // Recuperación de contraseña
  recuperando = false;
  recIdentificador = '';
  exitoRecuperacion = '';
  modoDesarrollo = false;

  constructor(private authService: AuthService, private router: Router) {}

  ingresar(): void {
    this.error = '';
    this.exito = '';

    if (!this.username.trim() || !this.password.trim()) {
      this.error = 'Ingrese usuario y contraseña.';
      return;
    }

    this.cargando = true;
    const peticion = this.authService.login(this.username, this.password);

    peticion.subscribe({
      next: () => {
        this.cargando = false;
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.cargando = false;
        this.error = err?.error?.message || 'Usuario o contraseña incorrectos.';
      }
    });
  }

  abrirRecuperacion(event: Event): void {
    event.preventDefault();
    this.error = '';
    this.exito = '';
    this.exitoRecuperacion = '';
    this.modoDesarrollo = false;
    this.recIdentificador = this.username;
    this.recuperando = true;
  }

  volverAlLogin(event?: Event): void {
    event?.preventDefault();
    this.error = '';
    this.recuperando = false;
  }

  solicitarRecuperacion(): void {
    this.error = '';
    this.exitoRecuperacion = '';
    this.modoDesarrollo = false;

    if (!this.recIdentificador.trim()) {
      this.error = 'Escribe tu usuario o tu correo.';
      return;
    }

    this.cargando = true;
    this.authService.solicitarRecuperacion(this.recIdentificador.trim()).subscribe({
      next: (res) => {
        this.cargando = false;
        this.exitoRecuperacion = res?.message || 'Solicitud enviada.';
        this.modoDesarrollo = !!res?.modoDesarrollo;
      },
      error: (err) => {
        this.cargando = false;
        this.error = err?.error?.message || 'No se pudo procesar la solicitud.';
      }
    });
  }
}
