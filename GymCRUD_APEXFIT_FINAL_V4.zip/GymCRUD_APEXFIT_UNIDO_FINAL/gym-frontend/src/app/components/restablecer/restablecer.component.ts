import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

/** Pantalla pública a la que llega el enlace de recuperación (/restablecer?token=...). */
@Component({
  selector: 'app-restablecer',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page force-dark">
      <div class="card">
        <div class="brand">
          <div class="icon">🔑</div>
          <h1>APEX<span>FIT</span></h1>
          <p>Crea tu nueva contraseña</p>
        </div>

        <div class="error" *ngIf="!token">El enlace no es válido. Solicita uno nuevo desde el inicio de sesión.</div>

        <form *ngIf="token && !listo" (ngSubmit)="guardar()">
          <label>Nueva contraseña (mínimo 6 caracteres)</label>
          <input type="password" name="nueva" [(ngModel)]="nueva" autocomplete="new-password" />

          <label>Confirmar contraseña</label>
          <input type="password" name="confirmar" [(ngModel)]="confirmar" autocomplete="new-password" />

          <button type="submit" [disabled]="cargando">{{ cargando ? 'Guardando...' : 'Restablecer contraseña' }}</button>
          <div class="error" *ngIf="error">{{ error }}</div>
        </form>

        <div class="success" *ngIf="listo">Contraseña restablecida. Ya puedes iniciar sesión.</div>

        <a href="#" class="link" (click)="irLogin($event)">{{ listo ? 'Ir a iniciar sesión' : '← Volver al inicio de sesión' }}</a>
      </div>
    </div>
  `,
  styles: `
    .page { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1.5rem; background: var(--bg-primary); }
    .card { width: 100%; max-width: 420px; padding: 2rem; border-radius: var(--radius-lg); background: var(--bg-secondary); border: 1px solid var(--border-color-hover); display: flex; flex-direction: column; gap: 1rem; }
    .brand { text-align: center; }
    .icon { font-size: 2rem; }
    h1 { margin: 0.25rem 0; font-size: 2rem; letter-spacing: -1px; }
    h1 span { color: var(--accent-primary); }
    p { margin: 0; color: var(--text-secondary); }
    form { display: flex; flex-direction: column; gap: 0.6rem; }
    label { font-size: 0.85rem; color: var(--text-secondary); font-weight: 600; }
    input { padding: 0.8rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--border-color-hover); background: var(--bg-primary); color: var(--text-primary); font-size: 1rem; font-family: var(--font-sans); }
    input:focus { outline: none; border-color: var(--accent-primary); }
    button { margin-top: 0.4rem; padding: 0.85rem; border: none; border-radius: var(--radius-md); background: var(--accent-gradient); color: #fff; font-weight: 700; font-size: 1rem; cursor: pointer; font-family: var(--font-sans); }
    button:disabled { opacity: 0.6; cursor: wait; }
    .error { padding: 10px; border-radius: var(--radius-md); background: rgba(239,68,68,0.15); color: #fca5a5; text-align: center; }
    .success { padding: 10px; border-radius: var(--radius-md); background: rgba(16,185,129,0.15); color: #6ee7b7; text-align: center; }
    .link { align-self: center; color: var(--accent-primary); font-weight: 600; text-decoration: none; }
    .link:hover { text-decoration: underline; }
  `
})
export class RestablecerComponent implements OnInit {
  token = '';
  nueva = '';
  confirmar = '';
  error = '';
  cargando = false;
  listo = false;

  constructor(private route: ActivatedRoute, private router: Router, private authService: AuthService) {}

  ngOnInit(): void {
    this.token = (this.route.snapshot.queryParamMap.get('token') || '').trim();
  }

  guardar(): void {
    this.error = '';
    if (this.nueva.length < 6) { this.error = 'La contraseña debe tener al menos 6 caracteres.'; return; }
    if (this.nueva !== this.confirmar) { this.error = 'La confirmación no coincide.'; return; }

    this.cargando = true;
    this.authService.restablecerClave(this.token, this.nueva).subscribe({
      next: () => { this.cargando = false; this.listo = true; },
      error: (err) => {
        this.cargando = false;
        this.error = err?.error?.message || 'No se pudo restablecer la contraseña.';
      }
    });
  }

  irLogin(event: Event): void {
    event.preventDefault();
    this.router.navigate(['/login']);
  }
}
