import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InscripcionService, PagoService, DetalleVentaService } from '../../services/gym.service';
import { AuthService } from '../../services/auth.service';
import { Pago, Inscripcion, DetalleVenta } from '../../models/gym.models';
import { imprimirReciboPago } from '../../utils/recibo.util';
import { TarjetaEstado, TarjetaFormComponent } from '../../shared/tarjeta-form.component';

import { PaginarPipe } from '../../shared/paginar.pipe';
import { PaginadorComponent } from '../../shared/paginador.component';

@Component({
  selector: 'app-pagos', standalone: true, imports: [CommonModule, FormsModule, PaginarPipe, PaginadorComponent, TarjetaFormComponent],
  templateUrl: './pagos.component.html', styleUrl: './pagos.component.css'
})
export class PagosComponent implements OnInit {
  pagina = 1;
  pagos: Pago[]=[]; pagosFiltrados: Pago[]=[]; inscripciones: Inscripcion[]=[]; filtroBusqueda='';
  mostrarModalForm=false; mostrarModalEliminar=false; model:Pago=this.nuevoPago(); pagoAEliminar:Pago|null=null;
  referenciaTransferencia='';
  detalles: DetalleVenta[]=[]; filtroTipo:'TODOS'|'MEMBRESIA'|'PRODUCTO'='TODOS';

  constructor(private service:PagoService,private inscripcionService:InscripcionService,private authService:AuthService,private detalleVentaService:DetalleVentaService){}
  ngOnInit():void{this.cargarDatos();}

  cargarDatos():void{
    this.service.listar().subscribe({next:r=>{this.pagos=[...r].sort((a,b)=>(b.idPago||0)-(a.idPago||0));this.filtrarPagos()},error:e=>console.error('Error cargando pagos:',e)});
    this.detalleVentaService.listar().subscribe({next:r=>this.detalles=r,error:e=>console.error('Error cargando detalles de venta:',e)});
    this.inscripcionService.listar().subscribe({next:r=>this.inscripciones=this.filtrarInscripciones(r),error:e=>console.error('Error cargando inscripciones:',e)});
  }
  esAdmin():boolean{return this.authService.obtenerRol()==='ADMIN';}
  private esClientePropio(i:Inscripcion):boolean{
    return true;
  }
  private filtrarInscripciones(items:Inscripcion[]):Inscripcion[]{return items;}
  cambiarFiltroTipo(t:'TODOS'|'MEMBRESIA'|'PRODUCTO'):void{this.filtroTipo=t;this.filtrarPagos();}
  contarPorTipo(t:'MEMBRESIA'|'PRODUCTO'):number{return this.pagos.filter(p=>this.obtenerTipoPago(p)===t).length;}
  filtrarPagos():void{
    const q=this.filtroBusqueda.toLowerCase().trim();
    this.pagosFiltrados=this.pagos.filter(p=>{
      if(this.filtroTipo!=='TODOS'&&this.obtenerTipoPago(p)!==this.filtroTipo)return false;
      return !q||`${this.obtenerTipoPago(p)} ${this.obtenerClientePago(p)} ${this.obtenerDetallePago(p)} ${p.metodoPago} ${p.estado}`.toLowerCase().includes(q);
    });
  }
  nuevoPago():Pago{return{tipoPago:'MEMBRESIA',monto:0,fechaPago:new Date().toISOString().substring(0,10),metodoPago:'Efectivo',estado:'Completado'};}
  abrirModalAdicion():void{this.model=this.nuevoPago();this.referenciaTransferencia='';this.tarjeta=null;this.mostrarModalForm=true;}
  cerrarModalForm():void{this.mostrarModalForm=false;}
  onInscripcionChange():void{const i=this.inscripciones.find(x=>x.idInscripcion===Number(this.model.inscripcion?.idInscripcion));if(i?.membresia)this.model.monto=i.membresia.precio;}
  tarjeta: TarjetaEstado | null = null;
  esTarjeta():boolean{return (this.model.metodoPago||'').startsWith('Tarjeta');}
  onMetodoPagoChange():void{this.referenciaTransferencia='';this.tarjeta=null;}
  formularioValido():boolean{return !!this.model.inscripcion?.idInscripcion&&this.model.monto>0&&!!this.model.fechaPago&&!!this.model.metodoPago&&(this.model.metodoPago!=='Transferencia Bancaria'||!!this.referenciaTransferencia.trim())&&(!this.esTarjeta()||!!this.tarjeta?.valido);}
  guardarPago():void{
    if(!this.formularioValido())return;
    const ins=this.inscripciones.find(i=>i.idInscripcion===Number(this.model.inscripcion?.idInscripcion));if(!ins)return;
    this.model.tipoPago='MEMBRESIA';this.model.inscripcion=ins;this.model.venta=undefined;
    this.service.guardarMembresia({
      inscripcionId: ins.idInscripcion!,
      monto: this.model.monto,
      fechaPago: this.model.fechaPago,
      metodoPago: this.model.metodoPago,
      estado: this.model.estado,
      referenciaPago: this.esTarjeta() ? `Tarjeta •••• ${this.tarjeta?.ultimos4}` : (this.model.metodoPago==='Transferencia Bancaria' ? `Transferencia ref. ${this.referenciaTransferencia.trim()}` : undefined)
    }).subscribe({next:p=>{this.cargarDatos();this.cerrarModalForm();this.imprimirRecibo(p)},error:e=>console.error('Error guardando pago:',e)});
  }
  confirmarEliminar(p:Pago):void{this.pagoAEliminar=p;this.mostrarModalEliminar=true;}
  eliminarPago():void{if(this.pagoAEliminar?.idPago===undefined)return;this.service.eliminar(this.pagoAEliminar.idPago).subscribe({next:()=>{this.cargarDatos();this.mostrarModalEliminar=false;this.pagoAEliminar=null},error:e=>console.error('Error eliminando pago:',e)});}
  obtenerTipoPago(p:Pago):string{return p.tipoPago||'MEMBRESIA';}
  obtenerClientePago(p:Pago):string{return p.inscripcion?.cliente?`${p.inscripcion.cliente.nombre} ${p.inscripcion.cliente.apellido}`:p.venta?.cliente?`${p.venta.cliente.nombre} ${p.venta.cliente.apellido}`:'Cliente desconocido';}
  esProducto(p:Pago):boolean{return this.obtenerTipoPago(p)==='PRODUCTO';}
  detallesDeVenta(p:Pago):DetalleVenta[]{const id=p.venta?.idVenta;return id===undefined?[]:this.detalles.filter(d=>d.venta?.idVenta===id);}
  obtenerDetallePago(p:Pago):string{
    if(this.esProducto(p)){
      const items=this.detallesDeVenta(p);
      if(!items.length)return 'Venta de productos';
      return items.map(d=>`${d.producto?.nombre||'Producto'} ×${d.cantidad}`).join(', ');
    }
    return p.inscripcion?.membresia?.nombre||'Membresía';
  }
  obtenerReferenciaPago(p:Pago):string{return this.esProducto(p)?`Venta POS #${p.venta?.idVenta||'N/A'}`:`Ref. Inscripción #${p.inscripcion?.idInscripcion||'N/A'}`;}
  obtenerClaseEstado(estado:string):string{switch((estado||'').toLowerCase()){case'completado':return'badge-success';case'pendiente':return'badge-warning';case'reembolsado':return'badge-danger';default:return'badge-info';}}
  imprimirRecibo(p:Pago):void{imprimirReciboPago(p,this.detalles);}
  private escapar(v:string):string{return String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
}
