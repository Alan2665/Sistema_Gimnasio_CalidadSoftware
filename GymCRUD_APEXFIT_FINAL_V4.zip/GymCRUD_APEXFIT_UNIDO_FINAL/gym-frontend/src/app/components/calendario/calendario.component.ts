import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ClaseService } from '../../services/gym.service';
import { AuthService } from '../../services/auth.service';
import { Clase } from '../../models/gym.models';

interface Dia { indice: number; nombre: string; clases: Clase[]; }

const DIAS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
const CODIGOS = ['LUN', 'MAR', 'MIE', 'JUE', 'VIE', 'SAB', 'DOM'];

function normalizar(t: string): string {
  return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

/** Extrae los días de la semana (0 = lunes) que menciona el horario libre de una clase. */
export function diasDeHorario(horario: string): number[] {
  const txt = normalizar(horario || '');
  const nombres = DIAS.map(normalizar);
  const dias = new Set<number>();

  // Rangos: "lunes a viernes"
  for (const m of txt.matchAll(/([a-z]+)\s+a\s+([a-z]+)/g)) {
    const a = nombres.indexOf(m[1]);
    const b = nombres.indexOf(m[2]);
    if (a >= 0 && b >= 0) {
      for (let i = a; ; i = (i + 1) % 7) {
        dias.add(i);
        if (i === b) break;
      }
    }
  }
  // Días sueltos: "lunes y miercoles"
  nombres.forEach((n, i) => { if (txt.includes(n)) dias.add(i); });
  return [...dias].sort((x, y) => x - y);
}

function minutosInicio(clase: Clase): number {
  const m = /(\d{1,2}):(\d{2})/.exec(clase.horas || clase.horario || '');
  return m ? Number(m[1]) * 60 + Number(m[2]) : 24 * 60;
}

/** Vista semanal de las clases del gimnasio, ordenadas por día y hora. */
@Component({
  selector: 'app-calendario',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="animate-fade-in">
      <div style="margin-bottom: 1.5rem;">
        <h1 style="font-size: 2.25rem;">Calendario semanal</h1>
        <p style="color: var(--text-secondary);">Horario de clases del gimnasio{{ esEntrenador ? ' (tus clases)' : '' }}</p>
      </div>

      <div class="semana">
        <div class="dia" *ngFor="let d of semana" [class.hoy]="d.indice === hoy">
          <div class="dia-cab">{{ d.nombre }} <span *ngIf="d.indice === hoy" class="chip">Hoy</span></div>
          <div class="clase" *ngFor="let c of d.clases">
            <div class="horas" *ngIf="franjas(c).length">
              <span class="hora" *ngFor="let f of franjas(c)">{{ f }}</span>
            </div>
            <div class="nombre">{{ c.nombre }}</div>
            <div class="meta" *ngIf="c.entrenador">🏋️ {{ c.entrenador.nombre }} {{ c.entrenador.apellido }}</div>
            <div class="meta" *ngIf="c.aula">📍 {{ c.aula }}</div>
            <div class="meta" *ngIf="c.cupoMaximo">👥 Cupo {{ c.cupoMaximo }}</div>
          </div>
          <div class="libre" *ngIf="d.clases.length === 0">Sin clases</div>
        </div>
      </div>

      <div class="glass-card" *ngIf="sinDia.length" style="margin-top: 1.5rem;">
        <h2 style="font-size: 1.05rem; margin-bottom: .75rem;">Clases sin día definido</h2>
        <div class="clase" *ngFor="let c of sinDia" style="margin-bottom:.6rem;">
          <div class="nombre">{{ c.nombre }}</div>
          <div class="meta">{{ c.horario }}</div>
        </div>
      </div>

      <div style="margin-top: 1.5rem;" *ngIf="esCliente">
        <button type="button" class="btn btn-primary" (click)="irAInscribirse()">Inscribirme a una clase</button>
      </div>
    </div>
  `,
  styles: `
    .semana { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: .75rem; }
    @media (max-width: 1300px) { .semana { grid-template-columns: repeat(4, minmax(0, 1fr)); } }
    @media (max-width: 800px) { .semana { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 480px) { .semana { grid-template-columns: 1fr; } }
    .dia { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: .75rem; min-height: 160px; }
    .dia.hoy { border-color: var(--accent-primary); box-shadow: 0 0 0 1px var(--accent-primary); }
    .dia-cab { font-weight: 700; margin-bottom: .6rem; display: flex; align-items: center; gap: .4rem; }
    .chip { font-size: .65rem; background: var(--accent-gradient); color: #fff; padding: 2px 7px; border-radius: 999px; }
    .clase { background: var(--accent-glow); border-left: 3px solid var(--accent-primary); border-radius: var(--radius-sm); padding: .5rem .6rem; margin-bottom: .5rem; }
    .horas { display: flex; flex-wrap: wrap; gap: .25rem .5rem; }
    .hora { font-size: .72rem; color: var(--accent-secondary); font-weight: 700; }
    .nombre { font-weight: 700; font-size: .92rem; }
    .meta { font-size: .75rem; color: var(--text-secondary); margin-top: 2px; }
    .libre { color: var(--text-muted); font-size: .82rem; text-align: center; padding: 1rem 0; }
  `
})
export class CalendarioComponent implements OnInit {
  semana: Dia[] = DIAS.map((nombre, indice) => ({ indice, nombre, clases: [] }));
  sinDia: Clase[] = [];
  /** 0 = lunes ... 6 = domingo */
  hoy = (new Date().getDay() + 6) % 7;

  constructor(private claseService: ClaseService, private authService: AuthService, private router: Router) {}

  get esCliente(): boolean { return this.authService.obtenerRol() === 'CLIENTE'; }
  get esEntrenador(): boolean { return this.authService.obtenerRol() === 'ENTRENADOR'; }

  ngOnInit(): void {
    this.claseService.listar().subscribe({ next: (clases) => this.armar(clases) });
  }

  private armar(clases: Clase[]): void {
    const semana: Dia[] = DIAS.map((nombre, indice) => ({ indice, nombre, clases: [] }));
    const sinDia: Clase[] = [];

    for (const c of clases) {
      const estructurados = (c.dias || '').split(',').map(d => CODIGOS.indexOf(d.trim())).filter(i => i >= 0);
      const dias = estructurados.length ? estructurados : diasDeHorario(c.horario);
      if (dias.length === 0) sinDia.push(c);
      else dias.forEach(i => semana[i].clases.push(c));
    }
    semana.forEach(d => d.clases.sort((a, b) => minutosInicio(a) - minutosInicio(b)));
    this.semana = semana;
    this.sinDia = sinDia;
  }

  /** Franjas horarias de la clase (estructuradas, o deducidas del texto libre si es una clase antigua). */
  franjas(c: Clase): string[] {
    const lista = (c.horas || '').split(',').map(h => h.trim()).filter(Boolean);
    if (lista.length) return lista;
    const m = /(\d{1,2}:\d{2}\s*(?:-|a)\s*\d{1,2}:\d{2})/.exec(c.horario || '');
    return m ? [m[1]] : [];
  }

  irAInscribirse(): void {
    this.router.navigate(['/asistencias']);
  }
}
