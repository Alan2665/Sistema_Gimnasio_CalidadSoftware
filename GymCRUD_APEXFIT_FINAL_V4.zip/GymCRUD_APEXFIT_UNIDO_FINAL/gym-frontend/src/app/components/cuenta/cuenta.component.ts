import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as QRCode from 'qrcode';
import { AuthService } from '../../services/auth.service';
import { CuentaService } from '../../services/cuenta.service';
import { DetalleVentaService, PagoService } from '../../services/gym.service';
import { ToastService } from '../../services/toast.service';
import { DetalleVenta, Pago, Perfil } from '../../models/gym.models';
import { PaginarPipe } from '../../shared/paginar.pipe';
import { PaginadorComponent } from '../../shared/paginador.component';
import { clienteDelPago, esPagoProducto, imprimirReciboPago, referenciaDelPago } from '../../utils/recibo.util';

type Pestana = 'perfil' | 'clave' | 'qr' | 'pagos';

@Component({
  selector: 'app-cuenta',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginarPipe, PaginadorComponent],
  template: `
    <div class="animate-fade-in">
      <div style="margin-bottom: 1.5rem;">
        <h1 style="font-size: 2.25rem;">Mi Cuenta</h1>
        <p style="color: var(--text-secondary);">Tu perfil, seguridad, código QR e historial de pagos</p>
      </div>

      <div class="tabs">
        <button type="button" [class.activa]="pestana === 'perfil'" (click)="pestana = 'perfil'">Perfil</button>
        <button type="button" [class.activa]="pestana === 'clave'" (click)="pestana = 'clave'">Contraseña</button>
        <button type="button" *ngIf="esCliente" [class.activa]="pestana === 'qr'" (click)="abrirQr()">Mi QR</button>
        <button type="button" *ngIf="esCliente" [class.activa]="pestana === 'pagos'" (click)="abrirPagos()">Mis pagos</button>
      </div>

      <!-- PERFIL -->
      <div class="glass-card panel" *ngIf="pestana === 'perfil'">
        <div class="cabecera">
          <div class="avatar">{{ inicial }}</div>
          <div>
            <div style="font-weight:700; font-size:1.1rem;">{{ perfil?.nombre ? (perfil?.nombre + ' ' + perfil?.apellido) : usuario }}</div>
            <span class="badge badge-info">{{ rol }}</span>
            <span style="color: var(--text-muted); font-size: .85rem; margin-left: .5rem;">&#64;{{ usuario }}</span>
          </div>
        </div>

        <ng-container *ngIf="perfil?.cedula !== undefined && perfil?.cedula !== null; else sinPerfil">
          <div class="form-group">
            <label class="form-label">Cédula</label>
            <input class="form-control" [value]="perfil?.cedula" disabled>
          </div>
          <form (ngSubmit)="guardarPerfil()">
            <div class="form-group">
              <label class="form-label">Teléfono</label>
              <input class="form-control" name="telefono" [(ngModel)]="telefono" autocomplete="tel">
            </div>
            <div class="form-group">
              <label class="form-label">Correo electrónico (se usa para recuperar tu contraseña)</label>
              <input class="form-control" type="email" name="correo" [(ngModel)]="correo" autocomplete="email">
            </div>
            <button type="submit" class="btn btn-primary" [disabled]="guardandoPerfil">
              {{ guardandoPerfil ? 'Guardando...' : 'Guardar cambios' }}
            </button>
          </form>
        </ng-container>
        <ng-template #sinPerfil>
          <p style="color: var(--text-secondary);">Esta cuenta no tiene datos de perfil editables.</p>
        </ng-template>
      </div>

      <!-- CONTRASEÑA -->
      <div class="glass-card panel" *ngIf="pestana === 'clave'">
        <h2 style="font-size: 1.15rem; margin-bottom: 1rem;">Cambiar contraseña</h2>
        <form (ngSubmit)="guardarClave()">
          <div class="form-group">
            <label class="form-label">Contraseña actual</label>
            <input [type]="ver ? 'text' : 'password'" class="form-control" name="actual" [(ngModel)]="claveActual" autocomplete="current-password" required>
          </div>
          <div class="form-group">
            <label class="form-label">Nueva contraseña (mínimo 6 caracteres)</label>
            <input [type]="ver ? 'text' : 'password'" class="form-control" name="nueva" [(ngModel)]="nuevaClave" autocomplete="new-password" required>
          </div>
          <div class="form-group">
            <label class="form-label">Confirmar nueva contraseña</label>
            <input [type]="ver ? 'text' : 'password'" class="form-control" name="confirmar" [(ngModel)]="confirmar" autocomplete="new-password" required>
          </div>
          <label style="display:flex; align-items:center; gap:0.5rem; color: var(--text-secondary); font-size:0.85rem; margin-bottom:1rem; cursor:pointer;">
            <input type="checkbox" [(ngModel)]="ver" name="ver"> Mostrar contraseñas
          </label>
          <div *ngIf="mensajeClave" class="badge" style="display:block; padding:0.75rem 1rem; margin-bottom:1rem; white-space: normal;"
               [ngClass]="exitoClave ? 'badge-success' : 'badge-danger'">{{ mensajeClave }}</div>
          <button type="submit" class="btn btn-primary" style="width:100%;" [disabled]="guardandoClave">
            {{ guardandoClave ? 'Guardando...' : 'Actualizar contraseña' }}
          </button>
        </form>
      </div>

      <!-- MI QR -->
      <div class="glass-card panel" *ngIf="pestana === 'qr' && esCliente" style="text-align:center;">
        <h2 style="font-size: 1.15rem; margin-bottom: .5rem;">Tu código de acceso</h2>
        <p style="color: var(--text-secondary); margin-bottom: 1rem; font-size: .9rem;">
          Muéstralo al entrenador o en recepción para confirmar que asististe a la clase en la que estás inscrito. Primero debes inscribirte en Asistencias. Es personal: no lo compartas.
        </p>
        <div class="qr-box" *ngIf="qrImagen; else cargandoQr"><img [src]="qrImagen" alt="Código QR personal" width="240" height="240"></div>
        <ng-template #cargandoQr><p style="color: var(--text-muted);">Generando código...</p></ng-template>
        <div style="margin-top: 1rem; display:flex; gap:.5rem; justify-content:center; flex-wrap: wrap;">
          <button type="button" class="btn btn-secondary" (click)="imprimirQr()" [disabled]="!qrImagen">🖨 Imprimir / guardar PDF</button>
        </div>
      </div>

      <!-- MIS PAGOS -->
      <div class="glass-card" style="padding:0;" *ngIf="pestana === 'pagos' && esCliente">
        <div class="table-container">
          <table class="custom-table">
            <thead><tr><th>Fecha</th><th>Tipo</th><th>Detalle</th><th>Método</th><th>Monto</th><th></th></tr></thead>
            <tbody>
              <tr *ngFor="let p of pagos | paginar:paginaPagos">
                <td>{{ p.fechaPago }}</td>
                <td><span class="badge" [ngClass]="esProducto(p) ? 'badge-success' : 'badge-warning'">{{ esProducto(p) ? 'Producto' : 'Membresía' }}</span></td>
                <td>{{ referencia(p) }}</td>
                <td>{{ p.metodoPago }}</td>
                <td style="color: var(--success); font-weight: 700;">\${{ p.monto | number:'1.2-2' }}</td>
                <td style="text-align:right;"><button type="button" class="btn btn-secondary" (click)="imprimirRecibo(p)">🖨 Recibo</button></td>
              </tr>
              <tr *ngIf="pagos.length === 0"><td colspan="6" style="text-align:center; color: var(--text-muted); padding: 2rem;">Aún no tienes pagos registrados.</td></tr>
            </tbody>
          </table>
          <div class="paginador-wrap"><app-paginador [total]="pagos.length" [(pagina)]="paginaPagos"></app-paginador></div>
        </div>
      </div>
    </div>
  `,
  styles: `
    .tabs { display: flex; gap: .5rem; flex-wrap: wrap; margin-bottom: 1.25rem; }
    .tabs button {
      padding: .6rem 1.1rem; border-radius: 999px; border: 1px solid var(--border-color-hover); background: transparent;
      color: var(--text-secondary); font-family: var(--font-sans); font-weight: 600; cursor: pointer; transition: var(--transition-smooth);
    }
    .tabs button:hover { color: var(--text-primary); border-color: var(--accent-primary); }
    .tabs button.activa { background: var(--accent-gradient); color: #fff; border-color: transparent; }
    .panel { max-width: 560px; }
    .cabecera { display:flex; align-items:center; gap: 1rem; margin-bottom: 1.5rem; }
    .avatar { width:3.2rem; height:3.2rem; border-radius:50%; background: var(--accent-gradient); color:#fff; display:flex; align-items:center; justify-content:center; font-size:1.4rem; font-weight:700; }
    .qr-box { display: inline-block; background: #fff; padding: 14px; border-radius: 16px; }
    .qr-box img { display: block; }
  `
})
export class CuentaComponent implements OnInit {
  pestana: Pestana = 'perfil';
  perfil: Perfil | null = null;

  // Perfil
  telefono = '';
  correo = '';
  guardandoPerfil = false;

  // Contraseña
  claveActual = '';
  nuevaClave = '';
  confirmar = '';
  ver = false;
  guardandoClave = false;
  mensajeClave = '';
  exitoClave = true;

  // QR
  qrImagen = '';

  // Pagos
  pagos: Pago[] = [];
  detalles: DetalleVenta[] = [];
  paginaPagos = 1;
  private pagosCargados = false;

  constructor(
    private authService: AuthService,
    private cuentaService: CuentaService,
    private pagoService: PagoService,
    private detalleService: DetalleVentaService,
    private toast: ToastService
  ) {}

  get usuario(): string { return this.authService.obtenerUsuario(); }
  get rol(): string { return this.authService.obtenerRol() || ''; }
  get esCliente(): boolean { return this.rol === 'CLIENTE'; }
  get inicial(): string { return (this.usuario || '?').charAt(0).toUpperCase(); }

  ngOnInit(): void {
    this.cuentaService.perfil().subscribe({
      next: (p) => {
        this.perfil = p;
        this.telefono = p.telefono || '';
        this.correo = p.correo || '';
      }
    });
  }

  // ---------------------------------------------------------------- perfil
  guardarPerfil(): void {
    this.guardandoPerfil = true;
    this.cuentaService.actualizarPerfil(this.telefono, this.correo).subscribe({
      next: (p) => {
        this.guardandoPerfil = false;
        this.perfil = p;
        this.toast.exito('Perfil actualizado correctamente.');
      },
      error: () => { this.guardandoPerfil = false; }
    });
  }

  // ---------------------------------------------------------------- contraseña
  guardarClave(): void {
    this.mensajeClave = '';
    if (!this.claveActual || !this.nuevaClave || !this.confirmar) return this.avisoClave('Completa todos los campos.', false);
    if (this.nuevaClave.length < 6) return this.avisoClave('La nueva contraseña debe tener al menos 6 caracteres.', false);
    if (this.nuevaClave !== this.confirmar) return this.avisoClave('La confirmación no coincide con la nueva contraseña.', false);
    if (this.nuevaClave === this.claveActual) return this.avisoClave('La nueva contraseña debe ser diferente a la actual.', false);

    this.guardandoClave = true;
    this.authService.cambiarClave(this.claveActual, this.nuevaClave).subscribe({
      next: (res) => {
        this.guardandoClave = false;
        this.claveActual = this.nuevaClave = this.confirmar = '';
        this.avisoClave(res?.message || 'Contraseña actualizada correctamente.', true);
      },
      error: (err) => {
        this.guardandoClave = false;
        this.avisoClave(err?.error?.message || 'No se pudo cambiar la contraseña.', false);
      }
    });
  }

  private avisoClave(texto: string, exito: boolean): void {
    this.mensajeClave = texto;
    this.exitoClave = exito;
  }

  // ---------------------------------------------------------------- QR
  abrirQr(): void {
    this.pestana = 'qr';
    if (this.qrImagen || !this.perfil?.qrCodigo) return;
    QRCode.toDataURL(this.perfil.qrCodigo, { width: 240, margin: 1, errorCorrectionLevel: 'M' })
      .then((url: string) => this.qrImagen = url)
      .catch(() => this.toast.error('No se pudo generar el código QR.'));
  }

  imprimirQr(): void {
    if (!this.qrImagen) return;
    const nombre = this.perfil?.nombre ? `${this.perfil.nombre} ${this.perfil.apellido}` : this.usuario;
    const w = window.open('', '_blank', 'width=520,height=640');
    if (!w) return;
    w.document.open();
    w.document.write(`<html><head><meta charset="utf-8"><title>QR APEXFIT</title><style>
      body{font-family:Arial,sans-serif;text-align:center;padding:40px;color:#111827}
      h1{margin:0;font-size:30px}h1 span{color:#6366f1}.n{margin:18px 0 6px;font-size:20px;font-weight:700}
      .c{color:#6b7280;font-size:13px;margin-top:14px}img{margin-top:10px}</style></head><body>
      <h1>APEX<span>FIT</span></h1><div class="n">${nombre.replace(/[<>&]/g, '')}</div>
      <img src="${this.qrImagen}" width="280" height="280"><div class="c">Código personal de acceso — no lo compartas</div>
      <script>window.onload=function(){window.print()}</script></body></html>`);
    w.document.close();
  }

  // ---------------------------------------------------------------- pagos
  abrirPagos(): void {
    this.pestana = 'pagos';
    if (this.pagosCargados) return;
    this.pagosCargados = true;
    this.pagoService.listar().subscribe({
      next: (r) => this.pagos = [...r].sort((a, b) => (b.idPago || 0) - (a.idPago || 0))
    });
    this.detalleService.listar().subscribe({ next: (r) => this.detalles = r });
  }

  esProducto(p: Pago): boolean { return esPagoProducto(p); }
  referencia(p: Pago): string { return referenciaDelPago(p); }
  imprimirRecibo(p: Pago): void { imprimirReciboPago(p, this.detalles); }
  clienteDe(p: Pago): string { return clienteDelPago(p); }
}
