// Tipos mínimos para la librería "qrcode" (no incluye definiciones propias).
declare module 'qrcode' {
  export interface QRCodeOptions {
    width?: number;
    margin?: number;
    errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
    color?: { dark?: string; light?: string };
  }
  export function toDataURL(text: string, options?: QRCodeOptions): Promise<string>;
}
